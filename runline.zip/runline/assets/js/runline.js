/**
 * Runline – the bars on the site (and in the editor previews):
 * - scrolling: as many copies as the screen needs, speed in pixels per second (the same for short and long texts);
 * - vertical ticker: the same, upwards, at a third of the speed;
 * - one by one (fade, slide up, typewriter): a message every few seconds;
 * - close button, pause on touch, countdown timers (a date, every day until a time, a personal timer for each visitor),
 *   coupon "Copy" button (with confetti), free shipping progress and {cart_total} / {cart_count} (WooCommerce cart),
 *   {visitor_country}, {open_now}, messages with dates, bars that come in after some seconds or some scrolling,
 *   events for Google Analytics / Tag Manager / Meta Pixel, moving the fixed header of the theme below the bars;
 * - visitors who asked for less motion see one message at a time, without animation.
 * No jQuery. window.runlineInit( root ) sets up the bars inside root (used by the previews).
 */
( function () {
	'use strict';

	var phone = window.matchMedia( '(max-width: 767px)' );
	var calm = window.matchMedia( '(prefers-reduced-motion: reduce)' );
	var CYCLE = [ 'fade', 'slide', 'typewriter' ];

	function closeKey( bar ) {
		return 'runline-closed-' + bar.getAttribute( 'data-key' );
	}

	function isPreview( bar ) {
		return !! bar.closest( '.runline-preview, .runline-block, .runline-design__thumb' );
	}

	function isPhone( bar ) {
		return phone.matches || !! bar.closest( '.runline-preview--phone' );
	}

	function modeOf( bar ) {
		var m = /runline--mode-([a-z]+)/.exec( bar.className );
		return m ? m[ 1 ] : 'marquee';
	}

	function hideBar( bar ) {
		bar.hidden = true;
		var spacer = bar.ownerDocument.getElementById( bar.id + '-spacer' );
		if ( spacer ) {
			spacer.hidden = true;
		}
	}

	function makeCopy( group ) {
		var copy = group.cloneNode( true );
		copy.setAttribute( 'aria-hidden', 'true' );
		copy.querySelectorAll( 'a' ).forEach( function ( link ) {
			link.setAttribute( 'tabindex', '-1' );
		} );
		return copy;
	}

	function paused( bar ) {
		return bar.matches( ':hover' ) || bar.contains( bar.ownerDocument.activeElement ) || bar.classList.contains( 'is-paused' );
	}

	/* One by one: one message at a time, the next one every few seconds (fade, slide up, typewriter, calm). */
	function stopCycle( bar ) {
		if ( bar.runlineTimer ) {
			clearInterval( bar.runlineTimer );
			bar.runlineTimer = null;
		}
		bar.classList.remove( 'runline--cycle' );
	}

	function typeIn( item ) {
		var text = item.querySelector( '.runline__text' );
		if ( ! text || calm.matches ) {
			return;
		}
		if ( undefined === text.runlineHtml ) {
			text.runlineHtml = text.innerHTML;
		}
		var full = text.textContent;
		var shown = 0;
		clearInterval( text.runlineTyping );
		text.textContent = '';
		item.classList.add( 'is-typing' );
		text.runlineTyping = setInterval( function () {
			shown++;
			text.textContent = full.slice( 0, shown );
			if ( shown >= full.length ) {
				clearInterval( text.runlineTyping );
				// Links and formatting come back when the whole text is there.
				text.innerHTML = text.runlineHtml;
				item.classList.remove( 'is-typing' );
			}
		}, 45 );
	}

	function show( bar, items, index ) {
		items.forEach( function ( item, i ) {
			item.classList.toggle( 'is-current', i === index );
		} );
		// Start the entrance animation again.
		var item = items[ index ];
		item.classList.remove( 'is-in' );
		void item.offsetWidth;
		item.classList.add( 'is-in' );
		if ( 'typewriter' === modeOf( bar ) ) {
			typeIn( item );
		}
	}

	function startCycle( bar, group ) {
		var items = Array.prototype.slice.call( group.querySelectorAll( '.runline__item' ) );
		if ( ! items.length ) {
			return;
		}
		bar.classList.add( 'runline--cycle' );
		if ( bar.runlineTimer ) {
			return;
		}
		var index = 0;
		show( bar, items, 0 );
		if ( items.length < 2 ) {
			return;
		}
		var seconds = parseFloat( bar.getAttribute( 'data-interval' ) ) || 4;
		bar.runlineTimer = setInterval( function () {
			if ( paused( bar ) ) {
				return;
			}
			index = ( index + 1 ) % items.length;
			show( bar, items, index );
		}, seconds * 1000 );
	}

	function layout( bar ) {
		var track = bar.querySelector( '.runline__track' );
		var viewport = bar.querySelector( '.runline__viewport' );
		if ( ! track || ! viewport || bar.hidden ) {
			return;
		}
		var groups = track.querySelectorAll( '.runline__group' );
		var first = groups[ 0 ];
		var mode = modeOf( bar );

		if ( 'static' === mode ) {
			return;
		}
		if ( calm.matches || -1 !== CYCLE.indexOf( mode ) ) {
			startCycle( bar, first );
			return;
		}
		stopCycle( bar );

		var vertical = 'vertical' === mode;
		var box = first.getBoundingClientRect();
		var size = vertical ? box.height : box.width;
		if ( ! size ) {
			return;
		}
		// Enough copies to cover the place plus one that slides in.
		var room = vertical ? viewport.getBoundingClientRect().height : viewport.getBoundingClientRect().width;
		var need = Math.max( 2, Math.ceil( room / size ) + 1 );
		for ( var i = groups.length; i < need; i++ ) {
			track.appendChild( makeCopy( first ) );
		}
		for ( var j = groups.length - 1; j >= need; j-- ) {
			track.removeChild( groups[ j ] );
		}

		var speed = parseFloat( bar.getAttribute( isPhone( bar ) ? 'data-speed-m' : 'data-speed' ) ) || 60;
		if ( vertical ) {
			speed = speed / 3;
		}
		var shift = -Math.round( size * 100 ) / 100 + 'px';
		var duration = ( size / speed ).toFixed( 2 ) + 's';
		if ( bar.style.getPropertyValue( '--rl-shift' ) === shift && bar.style.getPropertyValue( '--rl-dur' ) === duration ) {
			return;
		}
		bar.style.setProperty( '--rl-shift', shift );
		bar.style.setProperty( '--rl-dur', duration );
		// Some browsers keep the old values in a running animation: start it again.
		track.style.animation = 'none';
		void track.offsetWidth;
		track.style.animation = '';
	}

	/* Coupon: copy the code. */
	function copyText( text, done ) {
		if ( navigator.clipboard && window.isSecureContext ) {
			navigator.clipboard.writeText( text ).then( done, done );
			return;
		}
		var area = document.createElement( 'textarea' );
		area.value = text;
		area.setAttribute( 'readonly', '' );
		area.style.position = 'fixed';
		area.style.opacity = '0';
		document.body.appendChild( area );
		area.select();
		try {
			document.execCommand( 'copy' );
		} catch ( e ) {}
		document.body.removeChild( area );
		done();
	}

	function bindCopy( copy ) {
		copy.addEventListener( 'click', function () {
			var label = copy.textContent;
			copyText( copy.getAttribute( 'data-code' ), function () {
				copy.textContent = copy.getAttribute( 'data-copied' ) || label;
				copy.classList.add( 'is-copied' );
				if ( copy.getAttribute( 'data-confetti' ) && ! isPreview( copy.closest( '.runline' ) ) ) {
					confetti( copy );
				}
				setTimeout( function () {
					copy.textContent = label;
					copy.classList.remove( 'is-copied' );
				}, 2000 );
			} );
		} );
	}

	/* Free shipping: how much is left, from the WooCommerce cart (Store API). One request per page. */
	var cartRequest = null;
	function cart( url, fresh ) {
		if ( ! cartRequest || fresh ) {
			cartRequest = window.fetch ? fetch( url, { credentials: 'same-origin' } ).then( function ( r ) {
				return r.json();
			} ) : Promise.reject();
		}
		return cartRequest;
	}

	function money( amount, fmt ) {
		if ( ! fmt ) {
			return String( Math.round( amount * 100 ) / 100 );
		}
		var parts = Math.abs( amount ).toFixed( fmt.decimals ).split( '.' );
		parts[ 0 ] = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, fmt.thou );
		var number = parts.join( fmt.dec );
		return fmt.format.replace( '%1$s', fmt.symbol ).replace( '%2$s', number );
	}

	function shipping( bar, fresh ) {
		var data;
		try {
			data = JSON.parse( bar.getAttribute( 'data-ship' ) || 'null' );
		} catch ( e ) {}
		if ( ! data || isPreview( bar ) ) {
			return;
		}
		cart( data.cart, fresh )
			.then( function ( c ) {
				var t = c.totals;
				var total = ( parseInt( t.total_items, 10 ) + parseInt( t.total_items_tax || 0, 10 ) ) / Math.pow( 10, t.currency_minor_unit );
				var left = Math.max( 0, data.t - total );
				var leftText = money( left, data.fmt );
				var block = bar.querySelector( '.runline__ship-text' );
				if ( block ) {
					var parts = ( left > 0 ? data.before : data.after ).split( '{free_shipping_left}' );
					block.textContent = '';
					parts.forEach( function ( part, i ) {
						if ( i ) {
							var span = document.createElement( 'span' );
							span.className = 'runline__fsleft';
							span.textContent = leftText;
							block.appendChild( span );
						}
						block.appendChild( document.createTextNode( part ) );
					} );
				}
				bar.querySelectorAll( '.runline__fsleft' ).forEach( function ( span ) {
					span.textContent = leftText;
				} );
				bar.classList.toggle( 'is-free-shipping', ! left );
				var line = bar.querySelector( '.runline__progress i' );
				if ( line ) {
					line.style.width = Math.min( 100, Math.round( ( 100 * total ) / data.t ) ) + '%';
				}
			} )
			.catch( function () {} );
	}

	function refreshShipping() {
		var fresh = true;
		document.querySelectorAll( '.runline[data-ship], .runline[data-cart]' ).forEach( function ( bar ) {
			if ( bar.hasAttribute( 'data-ship' ) ) {
				shipping( bar, fresh );
				fresh = false;
			}
			if ( bar.hasAttribute( 'data-cart' ) ) {
				fillVars( bar, fresh );
				fresh = false;
			}
		} );
	}

	/* The fixed header of the theme goes below the top bars (Settings → "Move the fixed header"). */
	var headers = null;
	var scanned = 0;
	// Many headers (Elementor "Sticky", themes) become fixed only after some scrolling, so the page is looked at
	// again from time to time; headers found once stay in the list.
	function findHeaders() {
		headers = headers || [];
		scanned = Date.now();
		document.querySelectorAll( 'header, [class*="header"], [class*="sticky"], [id*="header"], nav' ).forEach( function ( el ) {
			if ( el.closest( '.runline-stack' ) || el.closest( '#wpadminbar' ) || headers.some( function ( h ) {
				return h.contains( el ) || el.contains( h );
			} ) ) {
				return;
			}
			var style = getComputedStyle( el );
			if ( 'fixed' === style.position || 'sticky' === style.position ) {
				var rect = el.getBoundingClientRect();
				if ( rect.width >= window.innerWidth * 0.6 && rect.height < 250 ) {
					headers.push( el );
				}
			}
		} );
	}

	function pushHeaders() {
		var stack = document.querySelector( '.runline-stack--push' );
		if ( ! stack ) {
			return;
		}
		if ( null === headers || Date.now() - scanned > 500 ) {
			findHeaders();
		}
		var bar = document.getElementById( 'wpadminbar' );
		var adminBar = bar && 'fixed' === getComputedStyle( bar ).position ? bar.offsetHeight : 0;
		var rect = stack.getBoundingClientRect();
		var below = Math.max( adminBar, Math.round( rect.bottom ) );
		headers.forEach( function ( el ) {
			var style = getComputedStyle( el );
			if ( 'fixed' !== style.position && 'sticky' !== style.position ) {
				el.style.removeProperty( 'top' );
				return;
			}
			el.style.setProperty( 'top', below + 'px', 'important' );
		} );
	}

	/* "Keep at the top while scrolling" uses position: sticky. Themes that hide overflow on both <html> and <body>
	   (common with Elementor) turn <body> into a scroll box, and sticky stops working there. Then the stack becomes
	   fixed, with a placeholder of its height left in the page. */
	function stickyBroken( stack ) {
		var root = document.documentElement;
		var visible = function ( style ) {
			return /^(visible|clip)$/.test( style.overflowX ) && /^(visible|clip)$/.test( style.overflowY );
		};
		for ( var el = stack.parentElement; el && el !== root; el = el.parentElement ) {
			var style = getComputedStyle( el );
			// <body> only passes its overflow to the window while <html> keeps the default.
			if ( ! visible( style ) && ! ( el === document.body && visible( getComputedStyle( root ) ) ) ) {
				return true;
			}
		}
		return false;
	}

	/* A header of the theme with a higher z-index (Elementor uses 9999) would slide over the bar kept at the top while
	   the page scrolls. The bar is lifted just above such a header — only on those sites, and below the admin bar. */
	function liftSticky() {
		var stack = document.querySelector( '.runline-stack--sticky' );
		if ( ! stack ) {
			return;
		}
		var own = parseInt( getComputedStyle( stack ).zIndex, 10 ) || 0;
		var top = 0;
		document.querySelectorAll( 'header, [class*="header"], [class*="sticky"], [id*="header"], nav' ).forEach( function ( el ) {
			if ( el.closest( '.runline-stack' ) || el.closest( '#wpadminbar' ) ) {
				return;
			}
			var style = getComputedStyle( el );
			var z = parseInt( style.zIndex, 10 );
			if ( 'static' === style.position || ! ( z >= own ) ) {
				return;
			}
			var rect = el.getBoundingClientRect();
			if ( rect.width >= window.innerWidth * 0.6 && rect.top + window.scrollY < 400 ) {
				top = Math.max( top, z );
			}
		} );
		if ( top ) {
			stack.style.zIndex = String( Math.min( 99990, top + 1 ) );
		}
	}

	function fixSticky() {
		var stack = document.querySelector( '.runline-stack--sticky' );
		if ( ! stack || stack.classList.contains( 'runline-stack--fixed' ) || ! stickyBroken( stack ) ) {
			return;
		}
		var place = document.createElement( 'div' );
		place.className = 'runline-stack-place';
		place.setAttribute( 'aria-hidden', 'true' );
		stack.parentNode.insertBefore( place, stack );
		stack.classList.add( 'runline-stack--fixed' );
		var size = function () {
			place.style.height = stack.offsetHeight + 'px';
		};
		size();
		if ( window.ResizeObserver ) {
			new ResizeObserver( size ).observe( stack );
		} else {
			window.addEventListener( 'resize', size );
		}
	}

	/* Statistics: a note to the site when a link, the button or the coupon is clicked, and — once per browser session
	   for each bar — when a bar is shown. The views of all bars of a page go in one request. */
	var views = [];
	var viewsUrl = '';
	var viewsTimer = 0;

	function send( url, data ) {
		var body = JSON.stringify( data );
		if ( navigator.sendBeacon && navigator.sendBeacon( url, new Blob( [ body ], { type: 'application/json' } ) ) ) {
			return;
		}
		if ( window.fetch ) {
			fetch( url, { method: 'POST', body: body, keepalive: true, headers: { 'Content-Type': 'application/json' } } ).catch( function () {} );
		}
	}

	function note( bar, type ) {
		var url = bar.getAttribute( 'data-track' );
		if ( ! url || isPreview( bar ) ) {
			return;
		}
		var id = parseInt( bar.getAttribute( 'data-bar' ), 10 );
		var variant = bar.getAttribute( 'data-variant' ) || 'a';
		if ( 'click' === type ) {
			send( url, { bar: id, type: 'click', variant: variant } );
			return;
		}
		// No session storage (private mode, blocked): no view note at all rather than one on every page.
		try {
			if ( sessionStorage.getItem( 'runline-seen-' + id ) ) {
				return;
			}
			sessionStorage.setItem( 'runline-seen-' + id, '1' );
		} catch ( e ) {
			return;
		}
		views.push( { bar: id, variant: variant } );
		viewsUrl = url;
		clearTimeout( viewsTimer );
		viewsTimer = setTimeout( function () {
			while ( views.length ) {
				send( viewsUrl, { type: 'view', bars: views.splice( 0, 10 ) } );
			}
		}, 300 );
	}

	/* Events for Google Analytics 4 (gtag), Google Tag Manager (dataLayer) and Meta Pixel, when the site has them. */
	function gaEvent( bar, name ) {
		var id = bar.getAttribute( 'data-ga' );
		if ( ! id || isPreview( bar ) ) {
			return;
		}
		var params = { bar_id: parseInt( id, 10 ), variant: bar.getAttribute( 'data-variant' ) || 'a' };
		try {
			if ( 'function' === typeof window.gtag ) {
				window.gtag( 'event', name, params );
			} else if ( window.dataLayer && window.dataLayer.push ) {
				window.dataLayer.push( Object.assign( { event: name }, params ) );
			}
			if ( 'function' === typeof window.fbq ) {
				window.fbq( 'trackCustom', name, params );
			}
		} catch ( e ) {}
	}

	function viewEvent( bar ) {
		try {
			var key = 'runline-ga-' + bar.getAttribute( 'data-ga' );
			if ( sessionStorage.getItem( key ) ) {
				return;
			}
			sessionStorage.setItem( key, '1' );
		} catch ( e ) {
			return;
		}
		gaEvent( bar, 'runline_view' );
	}

	/* A little confetti from the Copy button (not for visitors who asked for less motion). */
	function confetti( from ) {
		if ( calm.matches ) {
			return;
		}
		var box = from.getBoundingClientRect();
		var colors = [ '#f43f5e', '#f59e0b', '#22c55e', '#3b82f6', '#a855f7', '#facc15' ];
		for ( var i = 0; i < 28; i++ ) {
			var bit = document.createElement( 'span' );
			bit.className = 'runline-confetti';
			bit.style.left = box.left + box.width / 2 + 'px';
			bit.style.top = box.top + box.height / 2 + 'px';
			bit.style.background = colors[ i % colors.length ];
			bit.style.setProperty( '--x', Math.round( ( Math.random() - 0.5 ) * 260 ) + 'px' );
			bit.style.setProperty( '--y', Math.round( 60 + Math.random() * 140 ) + 'px' );
			bit.style.setProperty( '--r', Math.round( Math.random() * 720 - 360 ) + 'deg' );
			document.body.appendChild( bit );
			setTimeout( bit.remove.bind( bit ), 1300 );
		}
	}

	/* Messages with dates: on cached pages the site may still show yesterday's list. */
	function dropOldItems( bar ) {
		var d = new Date();
		var pad = function ( n ) {
			return ( n < 10 ? '0' : '' ) + n;
		};
		var today = d.getFullYear() + '-' + pad( d.getMonth() + 1 ) + '-' + pad( d.getDate() );
		var dropped = false;
		bar.querySelectorAll( '.runline__item[data-from], .runline__item[data-to]' ).forEach( function ( item ) {
			var from = item.getAttribute( 'data-from' );
			var to = item.getAttribute( 'data-to' );
			if ( ( from && from > today ) || ( to && to < today ) ) {
				var sep = item.nextElementSibling;
				if ( sep && sep.classList.contains( 'runline__sep' ) ) {
					sep.remove();
				}
				item.remove();
				dropped = true;
			}
		} );
		dropped = dayslotDates( bar ) || dropped;
		if ( dropped && ! bar.querySelector( '.runline__track .runline__item' ) ) {
			hideBar( bar );
		}
	}

	/*
	 * Dates of Dayslot ({delivery_date}, {pickup_date}, {places_left}) on cached pages: "today" / "tomorrow" again
	 * for the day of the visit (site time zone), and messages whose date has passed are dropped. True = dropped one.
	 */
	function dayslotDates( bar ) {
		var dropped = false;
		var pad = function ( n ) {
			return ( n < 10 ? '0' : '' ) + n;
		};
		var day = function ( offset, plus ) {
			var d = new Date( Date.now() + offset * 60000 + plus * 864e5 );
			return d.getUTCFullYear() + '-' + pad( d.getUTCMonth() + 1 ) + '-' + pad( d.getUTCDate() );
		};
		bar.querySelectorAll( '.runline__ds, .runline__ds-places' ).forEach( function ( el ) {
			var date = el.getAttribute( 'data-ds' );
			var offset = parseInt( el.getAttribute( 'data-o' ), 10 ) || 0;
			var today = day( offset, 0 );
			var item = el.closest( '.runline__item' );
			if ( date && date < today && item && item.parentNode ) {
				var sep = item.nextElementSibling;
				if ( sep && sep.classList.contains( 'runline__sep' ) ) {
					sep.remove();
				}
				item.remove();
				dropped = true;
				return;
			}
			if ( el.classList.contains( 'runline__ds' ) ) {
				if ( date === today ) {
					el.textContent = el.getAttribute( 'data-today' );
				} else if ( date === day( offset, 1 ) ) {
					el.textContent = el.getAttribute( 'data-tomorrow' );
				} else {
					el.textContent = el.getAttribute( 'data-full' );
				}
			}
		} );
		return dropped;
	}

	/* {cart_total}, {cart_count} from the WooCommerce cart and {visitor_country} from the site. */
	function fillVars( bar, fresh ) {
		var url = bar.getAttribute( 'data-cart' );
		if ( url ) {
			cart( url, fresh )
				.then( function ( c ) {
					var t = c.totals;
					var minor = t.currency_minor_unit;
					var amount = ( parseInt( t.total_items, 10 ) + parseInt( t.total_items_tax || 0, 10 ) ) / Math.pow( 10, minor );
					var text = money( amount, {
						decimals: minor,
						dec: t.currency_decimal_separator,
						thou: t.currency_thousand_separator,
						symbol: '',
						format: ( t.currency_prefix || '' ) + '%2$s' + ( t.currency_suffix || '' ),
					} );
					bar.querySelectorAll( '.runline__cart-total' ).forEach( function ( span ) {
						span.textContent = text;
					} );
					bar.querySelectorAll( '.runline__cart-count' ).forEach( function ( span ) {
						span.textContent = String( c.items_count || 0 );
					} );
				} )
				.catch( function () {} );
		}
		var countryUrl = bar.getAttribute( 'data-country' );
		if ( countryUrl && window.fetch && ! fresh ) {
			fetch( countryUrl, { credentials: 'same-origin' } )
				.then( function ( r ) {
					return r.json();
				} )
				.then( function ( data ) {
					var code = data && data.country;
					var name = code || '';
					try {
						if ( code && window.Intl && Intl.DisplayNames ) {
							name = new Intl.DisplayNames( [ document.documentElement.lang || 'en' ], { type: 'region' } ).of( code ) || code;
						}
					} catch ( e ) {}
					// Unknown country: the words "your country" stay.
					if ( name ) {
						bar.querySelectorAll( '.runline__country' ).forEach( function ( span ) {
							span.textContent = name;
						} );
					}
				} )
				.catch( function () {} );
		}
	}

	/* "Comes in after N seconds and / or after scrolling N % of the page" (the gate added .is-waiting). */
	function appear( bar ) {
		var c = {};
		try {
			c = JSON.parse( bar.getAttribute( 'data-gate' ) || '{}' );
		} catch ( e ) {}
		var wait = c.appear || [ 0, 0 ];
		var timeOk = ! wait[ 0 ];
		var scrollOk = ! wait[ 1 ];
		var done = false;
		var reveal = function () {
			if ( done || ! timeOk || ! scrollOk ) {
				return;
			}
			done = true;
			window.removeEventListener( 'scroll', onScroll );
			bar.classList.remove( 'is-waiting' );
			bar.classList.add( 'is-appearing' );
			var spacer = document.getElementById( bar.id + '-spacer' );
			if ( spacer ) {
				spacer.hidden = bar.hidden;
			}
			layout( bar );
			if ( ! bar.hidden ) {
				note( bar, 'view' );
				viewEvent( bar );
			}
			pushHeaders();
		};
		var onScroll = function () {
			var room = document.documentElement.scrollHeight - window.innerHeight;
			if ( room <= 0 || ( 100 * window.scrollY ) / room >= wait[ 1 ] ) {
				scrollOk = true;
				reveal();
			}
		};
		if ( ! scrollOk ) {
			window.addEventListener( 'scroll', onScroll, { passive: true } );
			onScroll();
		}
		if ( ! timeOk ) {
			setTimeout( function () {
				timeOk = true;
				reveal();
			}, wait[ 0 ] * 1000 );
		}
		reveal();
	}

	function setup( bar ) {
		if ( bar.runlineReady ) {
			layout( bar );
			return;
		}
		bar.runlineReady = true;
		if ( ! isPreview( bar ) ) {
			dropOldItems( bar );
		}
		if ( bar.classList.contains( 'is-waiting' ) && ! isPreview( bar ) ) {
			appear( bar );
		} else if ( ! bar.hidden ) {
			note( bar, 'view' );
			viewEvent( bar );
		}
		bar.addEventListener( 'click', function ( e ) {
			if ( e.target.closest( 'a, .runline__copy' ) ) {
				note( bar, 'click' );
				gaEvent( bar, e.target.closest( '.runline__copy' ) ? 'runline_coupon_copy' : 'runline_click' );
			}
		} );

		var close = bar.querySelector( '.runline__close' );
		if ( close ) {
			close.addEventListener( 'click', function () {
				if ( isPreview( bar ) ) {
					return;
				}
				hideBar( bar );
				try {
					// The time of closing: the bar comes back after the "hide for … days" of its settings.
					localStorage.setItem( closeKey( bar ), String( Date.now() ) );
				} catch ( e ) {}
				pushHeaders();
			} );
		}

		var form = bar.querySelector( '.runline__signup' );
		if ( form ) {
			form.addEventListener( 'submit', function ( event ) {
				event.preventDefault();
				var msg = form.querySelector( '.runline__signup-msg' );
				var email = form.querySelector( 'input[type="email"]' );
				var consent = form.querySelector( 'input[name="consent"]' );
				var url = form.getAttribute( 'data-url' );
				if ( ! url ) {
					return; // Editor preview.
				}
				if ( ! email.checkValidity() || ( consent && ! consent.checked ) ) {
					( consent && ! consent.checked && email.checkValidity() ? consent : email ).reportValidity();
					return;
				}
				form.classList.add( 'is-busy' );
				fetch( url, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify( {
						bar: parseInt( form.getAttribute( 'data-bar' ), 10 ),
						email: email.value,
						consent: !! ( consent && consent.checked ),
						website: form.querySelector( '.runline__hp' ).value,
					} ),
				} )
					.then( function ( r ) {
						return r.json().then(
							function ( data ) {
								return { ok: r.ok, data: data };
							},
							function () {
								return { ok: false, data: null };
							}
						);
					} )
					.then( function ( res ) {
						form.classList.remove( 'is-busy' );
						// Success only with the site's confirmation (ok: true); anything else is an error, without coupon.
						if ( ! res.ok || ! res.data || true !== res.data.ok ) {
							msg.textContent = ( res.data && res.data.message ) || form.getAttribute( 'data-err' ) || '';
							return;
						}
						msg.textContent = msg.getAttribute( 'data-ok' );
						var code = res.data && res.data.coupon;
						if ( code ) {
							// The coupon for subscribing, with its own Copy button.
							var codeEl = document.createElement( 'span' );
							codeEl.className = 'runline__cp-code';
							codeEl.textContent = code;
							var btn = document.createElement( 'button' );
							btn.type = 'button';
							btn.className = 'runline__copy';
							btn.textContent = msg.getAttribute( 'data-copy' ) || 'Copy';
							btn.setAttribute( 'data-code', code );
							btn.setAttribute( 'data-copied', msg.getAttribute( 'data-copied' ) || '' );
							msg.appendChild( document.createTextNode( ' ' ) );
							msg.appendChild( codeEl );
							msg.appendChild( document.createTextNode( ' ' ) );
							msg.appendChild( btn );
							bindCopy( btn );
							form.classList.add( 'has-coupon' );
						}
						form.classList.add( 'is-done' );
						note( bar, 'click' );
						gaEvent( bar, 'runline_signup' );
						try {
							localStorage.setItem( 'runline-subscribed-' + form.getAttribute( 'data-bar' ), '1' );
						} catch ( e ) {}
					} )
					.catch( function () {
						form.classList.remove( 'is-busy' );
						msg.textContent = form.getAttribute( 'data-err' ) || '';
					} );
			} );
		}

		var copy = bar.querySelector( '.runline__coupon .runline__copy' );
		if ( copy ) {
			bindCopy( copy );
		}

		// Touch screens have no hover: a tap on the bar (not on a link or button) stops and starts it.
		bar.addEventListener( 'pointerup', function ( event ) {
			if ( 'touch' === event.pointerType && ! event.target.closest( 'a, button' ) ) {
				bar.classList.toggle( 'is-paused' );
			}
		} );

		if ( window.ResizeObserver ) {
			var frame = 0;
			bar.runlineObserver = new ResizeObserver( function () {
				cancelAnimationFrame( frame );
				frame = requestAnimationFrame( function () {
					layout( bar );
				} );
			} );
			bar.runlineObserver.observe( bar );
			var viewport = bar.querySelector( '.runline__viewport' );
			if ( viewport ) {
				bar.runlineObserver.observe( viewport );
			}
		}
		layout( bar );
		shipping( bar, false );
		if ( ! isPreview( bar ) ) {
			fillVars( bar, false );
		}
	}

	function init( root ) {
		root = root || document;
		// Bars printed before the checker was on the page (found late): check them now.
		if ( window.runlineGate ) {
			root.querySelectorAll( '.runline[data-gate]' ).forEach( function ( bar ) {
				window.runlineGate( bar.id );
			} );
		}
		root.querySelectorAll( '.runline' ).forEach( setup );
		startTimers( root );
	}

	function relayout() {
		document.querySelectorAll( '.runline' ).forEach( function ( bar ) {
			stopCycle( bar );
			layout( bar );
		} );
	}

	/* Countdown: every second, all timers of the page. */
	function countdownText( seconds, daysFormat ) {
		var pad = function ( n ) {
			return ( n < 10 ? '0' : '' ) + n;
		};
		var days = Math.floor( seconds / 86400 );
		var time = pad( Math.floor( ( seconds % 86400 ) / 3600 ) ) + ':' + pad( Math.floor( ( seconds % 3600 ) / 60 ) ) + ':' + pad( seconds % 60 );
		return days ? ( daysFormat || '%dd' ).replace( '%d', days ) + ' ' + time : time;
	}

	// Documents with timers: this page, and the block editor's frame when a preview is set up there.
	var docs = [ document ];
	var timer = 0;

	/* Next "HH:MM" on one of the days (1 = Monday … 7 = Sunday, none = every day), like runline_daily_end(). */
	function dailyEnd( time, days, now, tzo ) {
		var parts = time.split( ':' );
		var local = now + tzo * 60000;
		var midnight = local - ( local % 864e5 );
		for ( var i = 0; i < 8; i++ ) {
			var at = midnight + i * 864e5 + ( parseInt( parts[ 0 ], 10 ) * 60 + parseInt( parts[ 1 ], 10 ) ) * 60000;
			var day = new Date( at ).getUTCDay() || 7;
			if ( at > local && ( ! days.length || -1 !== days.indexOf( day ) ) ) {
				return at - tzo * 60000;
			}
		}
		return 0;
	}

	function dayList( text ) {
		return ( text || '' ).split( ',' ).filter( Boolean ).map( Number );
	}

	/* {open_now}: like runline_is_open(). */
	function isOpen( el, now ) {
		var local = new Date( now + parseInt( el.getAttribute( 'data-tzo' ), 10 ) * 60000 );
		var day = local.getUTCDay() || 7;
		var minutes = local.getUTCHours() * 60 + local.getUTCMinutes();
		var mins = function ( t, fallback ) {
			return t ? parseInt( t.slice( 0, 2 ), 10 ) * 60 + parseInt( t.slice( 3 ), 10 ) : fallback;
		};
		var days = dayList( el.getAttribute( 'data-days' ) );
		return ( ! days.length || -1 !== days.indexOf( day ) ) && minutes >= mins( el.getAttribute( 'data-from' ), 0 ) && minutes < mins( el.getAttribute( 'data-to' ), 1440 );
	}

	function tick() {
		var now = Date.now();
		var timers = [];
		var opens = [];
		docs.forEach( function ( doc ) {
			timers = timers.concat( Array.prototype.slice.call( doc.querySelectorAll( '.runline__cd[data-end]' ) ) );
			opens = opens.concat( Array.prototype.slice.call( doc.querySelectorAll( '.runline__open' ) ) );
		} );
		opens.forEach( function ( el ) {
			var text = el.getAttribute( isOpen( el, now ) ? 'data-open' : 'data-closed' );
			el.classList.toggle( 'is-open', isOpen( el, now ) );
			if ( el.textContent !== text ) {
				el.textContent = text;
			}
		} );
		timers.forEach( function ( cd ) {
			var bar = cd.closest( '.runline' );
			var preview = ! bar || isPreview( bar );
			if ( cd.hasAttribute( 'data-daily' ) && parseInt( cd.getAttribute( 'data-end' ), 10 ) <= now ) {
				// Every day: the next time (cached pages show the server's one first).
				cd.setAttribute( 'data-end', dailyEnd( cd.getAttribute( 'data-daily' ), dayList( cd.getAttribute( 'data-days' ) ), now, parseInt( cd.getAttribute( 'data-tzo' ), 10 ) || 0 ) );
			}
			if ( cd.hasAttribute( 'data-visitor' ) && ! preview && ! cd.runlineStart ) {
				// Personal timer: from the first time this visitor saw the bar (the gate wrote it).
				var key = 'runline-cd-' + bar.getAttribute( 'data-key' );
				var start = now;
				try {
					start = parseInt( localStorage.getItem( key ), 10 ) || now;
					localStorage.setItem( key, String( start ) );
				} catch ( e ) {}
				cd.runlineStart = start;
				cd.setAttribute( 'data-end', start + parseInt( cd.getAttribute( 'data-visitor' ), 10 ) * 60000 );
			}
			var left = Math.max( 0, Math.floor( ( parseInt( cd.getAttribute( 'data-end' ), 10 ) - now ) / 1000 ) );
			var after = cd.getAttribute( 'data-after' );
			var text = left > 0 || ! after ? countdownText( left, cd.getAttribute( 'data-d' ) ) : after;
			if ( cd.textContent !== text ) {
				cd.textContent = text;
			}
			if ( ! left && ! after && ! cd.hasAttribute( 'data-daily' ) && ! preview ) {
				// Ended and "hide the bar" chosen (never in the previews).
				hideBar( bar );
			}
		} );
	}

	function startTimers( root ) {
		var doc = root.ownerDocument || root;
		if ( -1 === docs.indexOf( doc ) ) {
			docs.push( doc );
		}
		if ( ! timer && root.querySelector( '.runline__cd, .runline__open' ) ) {
			tick();
			timer = setInterval( tick, 1000 );
		}
	}

	window.runlineInit = init;

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', function () {
			init();
			fixSticky();
			liftSticky();
			pushHeaders();
		} );
	} else {
		init();
		fixSticky();
		liftSticky();
		pushHeaders();
	}
	// Web fonts change the width of the text.
	if ( document.fonts && document.fonts.ready ) {
		document.fonts.ready.then( relayout );
	}
	[ phone, calm ].forEach( function ( query ) {
		if ( query.addEventListener ) {
			query.addEventListener( 'change', relayout );
		}
	} );
	if ( document.querySelector( '.runline-stack--push' ) ) {
		var ticking = false;
		var onScroll = function () {
			if ( ! ticking ) {
				ticking = true;
				requestAnimationFrame( function () {
					ticking = false;
					pushHeaders();
				} );
			}
		};
		window.addEventListener( 'scroll', onScroll, { passive: true } );
		window.addEventListener( 'resize', function () {
			headers = null;
			onScroll();
		} );
	}
	// The cart changed (classic and block themes): recount free shipping.
	if ( window.jQuery ) {
		window.jQuery( document.body ).on( 'added_to_cart removed_from_cart updated_cart_totals updated_checkout wc_fragments_refreshed', refreshShipping );
	}
	document.addEventListener( 'wc-blocks_added_to_cart', refreshShipping );
	document.addEventListener( 'wc-blocks_removed_from_cart', refreshShipping );
}() );
