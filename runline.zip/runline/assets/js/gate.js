/**
 * Runline gate — printed inline once per page (in <head>, or before runline.js in the footer) and called right after
 * each bar: runlineGate( id ). The bar's data-gate attribute holds what to check. It decides before the first paint whether this visitor sees the bar, so cached pages
 * stay right: closed by the visitor (for closeDays, 0 = until the texts change), visitor rules (UTM tag, referrer,
 * cart total, first or returning visit, pages seen), schedule in the site time zone, ended countdown (also the
 * personal timer of each visitor), "comes in later" (appear), and "one bar per place" (group).
 * No dependencies; old browsers without these APIs simply see the bar.
 */
window.runlineGate = function ( id ) {
	'use strict';
	var bar = document.getElementById( id );
	if ( ! bar || bar.runlineGated ) {
		return;
	}
	bar.runlineGated = true;
	var c;
	try {
		c = JSON.parse( bar.getAttribute( 'data-gate' ) || '{}' );
	} catch ( e ) {
		return;
	}
	var spacer = document.getElementById( id + '-spacer' );
	var now = Date.now();

	function set( on ) {
		bar.hidden = ! on;
		if ( spacer ) {
			spacer.hidden = ! on || bar.classList.contains( 'is-waiting' );
		}
		bar.classList.toggle( 'is-on', on );
	}

	// UTM tag and referrer of the first page of the visit are remembered for the whole visit.
	function remember( key, value ) {
		try {
			if ( value ) {
				sessionStorage.setItem( key, value );
				return value;
			}
			return sessionStorage.getItem( key ) || '';
		} catch ( e ) {
			return value || '';
		}
	}
	function utm() {
		var values = [];
		location.search
			.replace( /^\?/, '' )
			.split( '&' )
			.forEach( function ( pair ) {
				var kv = pair.split( '=' );
				if ( /^utm_/i.test( kv[ 0 ] ) && kv[ 1 ] ) {
					values.push( decodeURIComponent( kv[ 1 ].replace( /\+/g, ' ' ) ) );
				}
			} );
		return remember( 'runline-utm', values.join( ' ' ) );
	}
	function referrer() {
		var ref = document.referrer;
		if ( ref ) {
			try {
				if ( new URL( ref ).host === location.host ) {
					ref = '';
				}
			} catch ( e ) {}
		}
		return remember( 'runline-ref', ref );
	}
	// This visit: first visit to the site or a returning visitor, and pages seen so far (counted once per page).
	function visit() {
		if ( window.runlineVisit ) {
			return window.runlineVisit;
		}
		var v = { returning: false, pages: 1 };
		try {
			if ( ! sessionStorage.getItem( 'runline-visit' ) ) {
				v.returning = !! localStorage.getItem( 'runline-first' );
				sessionStorage.setItem( 'runline-visit', v.returning ? 'r' : 'n' );
				if ( ! v.returning ) {
					localStorage.setItem( 'runline-first', String( now ) );
				}
			}
			v.returning = 'r' === sessionStorage.getItem( 'runline-visit' );
			v.pages = ( parseInt( sessionStorage.getItem( 'runline-pages' ), 10 ) || 0 ) + 1;
			sessionStorage.setItem( 'runline-pages', String( v.pages ) );
		} catch ( e ) {}
		window.runlineVisit = v;
		return v;
	}
	function has( text, part ) {
		return !! part && -1 !== text.toLowerCase().indexOf( String( part ).toLowerCase() );
	}

	// One rule: true / false, or null while the cart total or the country is not known yet.
	function test( rule, data ) {
		var total = data.total;
		var v = rule.value;
		if ( 'utm' === rule.type ) {
			return has( utm(), v );
		}
		if ( 'referrer' === rule.type ) {
			return has( referrer(), v );
		}
		if ( 'new_visit' === rule.type ) {
			return ! visit().returning;
		}
		if ( 'returning' === rule.type ) {
			return visit().returning;
		}
		if ( 'ds_off_today' === rule.type || 'ds_off_tomorrow' === rule.type ) {
			// Days without delivery of Dayslot, in the site time zone.
			if ( ! c.dsOff || ! c.dsOff.d ) {
				return false;
			}
			var day = new Date( now + c.dsOff.o * 60000 + ( 'ds_off_tomorrow' === rule.type ? 864e5 : 0 ) );
			var two = function ( n ) {
				return ( n < 10 ? '0' : '' ) + n;
			};
			return -1 !== c.dsOff.d.indexOf( day.getUTCFullYear() + '-' + two( day.getUTCMonth() + 1 ) + '-' + two( day.getUTCDate() ) );
		}
		if ( 'pages_seen' === rule.type ) {
			return visit().pages >= ( parseInt( v, 10 ) || 1 );
		}
		if ( 'country' === rule.type ) {
			if ( undefined === data.country ) {
				return null;
			}
			return !! data.country && -1 !== ( ', ' + v + ',' ).indexOf( ' ' + data.country + ',' );
		}
		if ( 'cart_total' === rule.type ) {
			if ( undefined === total ) {
				return null;
			}
			return ( '' === v.min || total >= v.min ) && ( '' === v.max || total <= v.max );
		}
		return false;
	}
	// Any rule of a list: true if one is true, null if one is unknown, else false.
	function any( rules, data ) {
		var result = false;
		for ( var i = 0; i < rules.length; i++ ) {
			var r = test( rules[ i ], data );
			if ( r ) {
				return true;
			}
			if ( null === r ) {
				result = null;
			}
		}
		return result;
	}

	function inSchedule( s ) {
		if ( ( s.start && now < s.start ) || ( s.end && now >= s.end ) ) {
			return false;
		}
		var day;
		var minutes;
		if ( s.tz && window.Intl ) {
			try {
				var parts = {};
				new Intl.DateTimeFormat( 'en-US', { timeZone: s.tz, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' } )
					.formatToParts( new Date( now ) )
					.forEach( function ( p ) {
						parts[ p.type ] = p.value;
					} );
				day = [ 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun' ].indexOf( parts.weekday ) + 1;
				minutes = ( parseInt( parts.hour, 10 ) % 24 ) * 60 + parseInt( parts.minute, 10 );
			} catch ( e ) {}
		}
		if ( ! day ) {
			var local = new Date( now + s.off * 60000 );
			day = local.getUTCDay() || 7;
			minutes = local.getUTCHours() * 60 + local.getUTCMinutes();
		}
		if ( s.days && s.days.length && -1 === s.days.indexOf( day ) ) {
			return false;
		}
		if ( s.from >= 0 && s.to >= 0 ) {
			return s.from <= s.to ? minutes >= s.from && minutes < s.to : minutes >= s.from || minutes < s.to;
		}
		if ( s.from >= 0 ) {
			return minutes >= s.from;
		}
		if ( s.to >= 0 ) {
			return minutes < s.to;
		}
		return true;
	}

	if ( c.signup ) {
		try {
			if ( localStorage.getItem( 'runline-subscribed-' + String( c.key ).split( '-' )[ 0 ] ) ) {
				return set( false );
			}
		} catch ( e ) {}
	}
	if ( c.closable ) {
		try {
			var closed = localStorage.getItem( 'runline-closed-' + c.key );
			if ( closed ) {
				// Old versions stored "1": closed until the texts change.
				if ( ! c.closeDays || closed.length < 5 || now - closed < c.closeDays * 864e5 ) {
					return set( false );
				}
				localStorage.removeItem( 'runline-closed-' + c.key );
			}
		} catch ( e ) {}
	}
	// A/B test: each visitor keeps one variant (c.ab = % of visitors who see A).
	if ( c.ab ) {
		var variant;
		try {
			variant = localStorage.getItem( 'runline-ab-' + c.key );
		} catch ( e ) {}
		if ( 'a' !== variant && 'b' !== variant ) {
			variant = Math.random() * 100 < c.ab ? 'a' : 'b';
			try {
				localStorage.setItem( 'runline-ab-' + c.key, variant );
			} catch ( e ) {}
		}
		bar.setAttribute( 'data-variant', variant );
		var tracks = bar.querySelectorAll( '.runline__track' );
		if ( tracks.length > 1 ) {
			tracks[ 'a' === variant ? 1 : 0 ].remove();
		}
	}
	// Personal timer: minutes from the first time this visitor saw the bar.
	if ( c.cdVisitor ) {
		var start = 0;
		try {
			start = parseInt( localStorage.getItem( 'runline-cd-' + c.key ), 10 ) || 0;
			if ( ! start ) {
				start = now;
				localStorage.setItem( 'runline-cd-' + c.key, String( now ) );
			}
		} catch ( e ) {}
		if ( start && now >= start + c.cdVisitor * 60000 ) {
			return set( false );
		}
	}
	if ( ( c.cdEnd && now >= c.cdEnd ) || ( c.sched && ! inSchedule( c.sched ) ) ) {
		return set( false );
	}
	// "Comes in after N seconds / after scrolling": runline.js shows it then.
	if ( c.appear ) {
		bar.classList.add( 'is-waiting' );
	}

	function decide( data ) {
		var hide = c.hide ? any( c.hide, data ) : false;
		var show = c.show ? any( c.show, data ) : true;
		if ( true === hide || false === show ) {
			return false;
		}
		return null === hide || null === show ? null : true;
	}
	function apply( on ) {
		if ( on && c.group && document.querySelector( '.runline.is-on[data-group="' + c.group + '"]' ) ) {
			on = false;
		}
		set( on );
	}

	var result = decide( {} );
	if ( null !== result ) {
		return apply( result );
	}
	// The cart total or the country decides: hidden until the site answers.
	set( false );
	if ( ! window.fetch || ! window.Promise ) {
		return;
	}
	var json = function ( url ) {
		return fetch( url, { credentials: 'same-origin' } ).then( function ( r ) {
			return r.json();
		} );
	};
	Promise.all( [
		c.cartUrl ? json( c.cartUrl ).catch( function () {} ) : null,
		c.countryUrl ? json( c.countryUrl ).catch( function () {} ) : null,
	] ).then( function ( answers ) {
		var data = {};
		var cart = answers[ 0 ];
		if ( cart && cart.totals ) {
			var t = cart.totals;
			data.total = ( parseInt( t.total_items, 10 ) + parseInt( t.total_items_tax || 0, 10 ) ) / Math.pow( 10, t.currency_minor_unit );
		} else if ( c.cartUrl ) {
			data.total = 0;
		}
		if ( c.countryUrl ) {
			data.country = answers[ 1 ] && answers[ 1 ].country ? answers[ 1 ].country : '';
		}
		apply( !! decide( data ) );
	} );
};
