/**
 * Two bundles: the admin app (src/index.js → build/index.js) and the block editor script
 * (src/block/index.js → build/block/index.js). Build: npm install && npm run build
 */
const path = require( 'path' );
const defaultConfig = require( '@wordpress/scripts/config/webpack.config' );

module.exports = {
	...defaultConfig,
	entry: {
		index: path.resolve( __dirname, 'src/index.js' ),
		'block/index': path.resolve( __dirname, 'src/block/index.js' ),
	},
	output: {
		...defaultConfig.output,
		path: path.resolve( __dirname, 'build' ),
	},
};
