=== Runline – Marquee, News Ticker & Announcement Bar ===
Contributors: creonix
Tags: marquee, news ticker, announcement bar, countdown, scrolling text
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.2.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

100% free scrolling bar & news ticker: countdowns, e-mail signup, click stats, A/B tests, 100+ designs. No Pro version, nothing locked.

== Description ==

[//]: # (VIDEO: the YouTube link of wporg-assets/video/runline-overview-1080p.mp4 goes here, on its own line)

Runline adds scrolling text bars to your site in two minutes: free shipping, sales with a countdown, news, opening hours, a new collection — anything your visitors should not miss.

= 100% free. Every feature. =

Most announcement bar plugins keep the countdown, the e-mail signup, the statistics or the A/B tests for a paid Pro version. Runline does not have one:

* **No Pro version**, no trial, no license key, no "upgrade" buttons, no ads in your dashboard.
* **Every feature on this page is in the free plugin** — countdown, signup, recent sales, click stats, A/B tests, display rules, schedule, all 100+ designs.
* **Unlimited bars**, unlimited messages, on unlimited sites.
* No account with us, nothing sent to our servers.

Pick one of 100+ ready designs — Black Friday, free shipping, Christmas, newsletter, reviews, breaking news, tilted landing-page ribbons and more — or start from scratch. Type your messages, pick colours and watch the live preview change with every key you press — on a computer or phone screen, on a light or dark page. Save without reloading, and the bar is on your site.

= Light and fast =

* Pure CSS animation, no jQuery. Pages without a bar load no Runline files at all.
* The bar reserves its height at once, so the page does not jump (no layout shift).
* Smooth endless loop without gaps, on any screen width.
* Speed in pixels per second: short and long texts move at the same, readable pace.

= Countdown timer =

Three kinds of timers, all free:

* **To a date**: the end of a sale or the start of an event — "Ends in 2d 14:05:33".
* **Every day until a time**: "Order in 02:15:30 — we ship today". It starts again every day by itself, and you choose the days (for example Monday to Friday).
* **Personal timer for each visitor**: "Your offer ends in 14:59" — it starts when a visitor sees the bar for the first time and runs out for that visitor alone.

The timer can stand still on the left or the right while the text moves, or sit right inside a message with `{countdown}`. When the time is over, the bar hides itself or shows your text.

= More than text =

* **Button** on the right ("Shop now"), with a soft pulse if you like, and a **coupon code with a Copy button** (with a little confetti when copied).
* **Contact buttons**: WhatsApp, call and Messenger, right in the bar.
* **Messages with their own dates**: "Order before Christmas" shows from December 1 to 20 and disappears by itself, while the other messages keep running.
* **Images and logos** in messages — make a scrolling **logo strip** of your clients or partners.
* **Review cards**: a photo, the review and the name ("Anna, Kraków").
* **Modes**: endless scrolling, one by one (fade, slide up, typewriter), vertical ticker, or still.
* **Automatic messages** from your latest posts, your WooCommerce products (newest, on sale, featured, best selling, or exactly the products you pick — with prices and your own text like "🔥 {product} — only {price}") or any RSS feed. Your own messages can run between them.
* **Variables** in texts: {date}, {site_name}, {coupon}, {countdown}, {free_shipping_left}, {cart_total}, {cart_count}, {visitor_country}, {open_now} ("Open now" / "Closed now" by your opening hours), and {delivery_date}, {pickup_date} and {places_left} with the free plugin Dayslot.
* **WPML and Polylang**: the texts of the bars are translated with your multilingual plugin.

= Grow your list, prove your sales =

* **E-mail signup right in the bar**: a field and a Subscribe button. Addresses are kept on your site (Runline → Subscribers, CSV export) and can also go to **Mailchimp, MailerLite, Brevo, Kit (ConvertKit), Klaviyo, Omnisend, FluentCRM, MailPoet** or any **webhook** (Zapier, Make, n8n). Optional consent check box, spam protection, and the bar can hide itself for visitors who subscribed.
* **A coupon for subscribing**: the visitor gets the code with a Copy button right after subscribing — it is not in the page before that.
* **Recent sales** (WooCommerce): "A. bought Red balloons 5 minutes ago" — real orders as social proof. By default only the first letter of the name and no city; you choose what to show.
* **Click statistics**: views, clicks and click rate per day for every bar, with charts. No cookies, no IP addresses stored; fake views and clicks are filtered out on the server.
* **A/B test**: show a second set of messages to part of the visitors and see which one gets more clicks.
* **Google Analytics 4, Google Tag Manager and Meta Pixel**: views, clicks, coupon copies and signups of the bars go to your analytics as events (runline_view, runline_click, runline_coupon_copy, runline_signup) — when these tools are already on your site.

= Make it look your way =

* Gradients, borders, shadows, rounded corners.
* **Tilted and crossed ribbons** like on landing pages.
* 20 **Google Fonts** that are saved on your own site (nothing is loaded from Google when visitors view the page), or the font of your theme.
* An extra CSS class for developers; every bar has its own ID (e.g. `#runline-12`) for your styles in Additional CSS.

= For WooCommerce shops (optional) =

Runline works on any WordPress site. When WooCommerce is active, you also get:

* **Free shipping progress**: "Add 37,00 zł more for free shipping" with a progress line, from the visitor's cart, updated when products are added.
* **Countdown to the end of a product sale** — taken from the product itself, nothing to type twice.
* Products as messages, and display rules for the shop, product pages, cart, checkout and cart total.
* **Delivery dates** with Dayslot, our free plugin for WooCommerce delivery dates: "Next delivery: tomorrow", "Order in 02:15:30 — delivery tomorrow", "Delivery places left for Saturday: 3", the next pickup day, a bar that shows only before a day without delivery, and its free delivery amount for the free shipping progress.

= Show it exactly where you want =

* **Any number of bars** at the same time, each with its own place and priority — two at the top stand one under another, or let only the most important one show.
* **Display rules**: "Show on…" and "Do not show on…" — home page, chosen pages, posts and products, post types, categories and tags, search, 404, addresses containing a text; WooCommerce shop, product pages, cart, checkout, my account, cart total; logged-in visitors, guests, user roles, site language (WPML, Polylang); visitors who came with a UTM tag or from a certain site (Google, Facebook, Instagram…); first visit or returning visitor; visitors who have seen at least a number of pages; country of the visitor (with Cloudflare or a hosting that tells the country).
* **When it comes in**: at once, after some seconds, or after the visitor scrolls part of the page — with a short slide.
* **Schedule**: from / until a date and time, days of the week, hours of the day — in the time zone of your site.
* **Any container**: top of the site, bottom of the screen, or any place with the block, the Elementor widget or the shortcode — a column, a sidebar, a small box. The bar takes the width of that place; "limited width", alignment and rounded corners for more.
* Works with page caching: rules about the visitor and the time are checked in the browser.

= Features =

* 100+ free ready designs in eight groups: shop, marketing, coupons & signups, reviews & trust, holidays (also Grandparents' Day, Women's Day, Children's Day, Advent), news, landing pages, minimal, and trades — balloons and parties, flowers, cafés, gyms, salons, real estate, schools — all with readable colours (WCAG AA contrast)
* "Change design" takes the look of another design and keeps your texts
* Top of the site, bottom of the screen, or anywhere with the Runline block (Gutenberg), the Runline Elementor widget or the `[runline]` shortcode
* Up to 50 messages per bar, each with an emoji (quick picker) and an optional link (same or new tab); drag to reorder
* Separator of your choice between messages: • ★ | / or anything else
* Fixed label on the left, e.g. "NEW" or "SALE"
* Colours of the background, text, links and label; font, size, weight, capital letters
* Bar height and space between messages
* Direction, separate speed for phones, pause when the mouse is over the bar, tap to pause on phones
* Keep at the top while scrolling
* Close button: a closed bar stays hidden for that visitor for the number of days you choose, or until you change its texts
* On computers, tablets and phones separately
* Works with page caching (WP Rocket, LiteSpeed Cache, W3 Total Cache): devices are handled in CSS
* Accessible: respects "reduce motion" (one message at a time instead of moving text), stops on keyboard focus, copies of the text are hidden from screen readers
* Modern editor built with the WordPress design system: settings in four tabs, live preview, save with Ctrl+S
* Switch bars on and off, duplicate and delete them right in the list
* Export all bars to a file and import them on another site
* Translated into Czech, Dutch, French, German, Italian, Polish, Portuguese (Brazil), Russian, Spanish and Ukrainian; ready for more
* Choose the language of Runline by hand (Runline → Settings), independent of the language of WordPress

= More from Creonix =

* [Dayslot](https://wordpress.org/plugins/dayslot/) — customers choose the delivery or pickup date and time (or the date of an event) right in the WooCommerce checkout. Free; with it, Runline can show the next delivery date, a timer until it changes and the places left.

== Installation ==

1. Install and activate the plugin from Plugins → Add New.
2. Go to Runline → Add bar.
3. Write your messages, choose the colours and where the bar shows.
4. Click Save. The bar is on your site.

== Frequently Asked Questions ==

= Is Runline really free? Is there a Pro version? =

Yes, it is completely free, and there is no Pro version. All features — the three kinds of timers, e-mail signup with nine e-mail services, a coupon for subscribing, contact buttons, recent sales, click statistics, A/B tests, Google Analytics events, display rules, schedule and all 100+ designs — are in the plugin you download from WordPress.org. No license key, no limits on bars or sites, no upgrade notices.

= Why is it free? =

Runline is made by Creonix, a small studio that builds WordPress and WooCommerce plugins. We use it on our own shops and share it as it is. If it helps you, a short review on WordPress.org is the best way to say thank you.

= The bar does not show at the top of my theme =

Runline puts the bar right after the opening `<body>` tag. Themes that do not support that get the bar moved to the top with a line of JavaScript. If your theme has its own sticky header, use the shortcode inside the header (for example in Elementor) instead.

= How do I put the bar into a page? =

Set Display → Where to "Only where I put the shortcode". Then add the "Runline bar" block in the block editor, the "Runline bar" widget in Elementor, or paste `[runline id="123"]` anywhere else (the ID is shown in the list of bars).

= Can I show several bars? =

Yes, as many as you like. Bars in the same place stand one under another, in the order of their priority. In Runline → Settings you can choose to show only the most important one per place.

= Can I put a bar into a narrow column or a small box? =

Yes. With the block, the Elementor widget or the shortcode the bar takes the width of the place you put it in. The shortcode also takes options for one place: `[runline id="123" width="320" radius="8" size="13"]`.

= Do I need WooCommerce? =

No. Runline is for any WordPress site. The shop features (free shipping progress, products, sale countdown) appear only when WooCommerce is active.

= The bar is under the fixed header of my theme =

Switch on Runline → Settings → "Move a fixed (sticky) header of the theme below the top bars", or put the bar into the header with the block or the Elementor widget.

= How does the "every day until 14:00" timer work? =

Choose Offers → Countdown timer → "Every day until a time", set the time and, if you like, the days. The timer always counts to the next such time in the time zone of your site; after 14:00 it counts to 14:00 of the next chosen day. Write `{countdown}` in a message, e.g. "Order in {countdown} — we ship today".

= How do I send bar clicks to Google Analytics? =

If Google Analytics 4 (gtag.js), Google Tag Manager or Meta Pixel is on your site, it already works: Runline sends the events runline_view, runline_click, runline_coupon_copy and runline_signup with the bar ID. You can switch this off in Runline → Settings. Runline adds no tracking code of its own.

= Does it work with page caching? =

Yes. Rules about pages are decided by the page; rules about the visitor (UTM tag, referrer, cart total, first or returning visit, pages seen), the schedule, the daily and personal timers and messages with dates are checked in the browser before the page is shown.

= Do the statistics use cookies or personal data? =

No cookies. Runline adds up numbers per bar and per day. The browser sends a small note when a bar is shown and when it is clicked. Against fake views and clicks, the site keeps for one day a scrambled code (a keyed hash) of the visitor's IP address and browser name — not the address itself — so a view counts once per visitor in 30 minutes, a click counts only after a view, and one visitor cannot send hundreds of notes. You can switch the statistics off in Runline → Settings.

= Where do the e-mail addresses go? =

Into a table on your own site (Runline → Subscribers), with a CSV export. If you choose an e-mail service for a bar (Mailchimp, MailerLite, Brevo, Kit, Klaviyo, Omnisend or a webhook), the address is also sent to that service; FluentCRM and MailPoet are plugins on your own site. Runline adds the subscribers to the WordPress tools for exporting and erasing personal data.

= My site is behind Cloudflare or another proxy. Does the signup form still work? =

Yes. Against spam the form allows 5 tries per e-mail address and 30 tries per IP address in 10 minutes. Runline finds the real visitor behind Cloudflare (by its official address ranges) and behind a proxy on your own server or network, and reads only the part of X-Forwarded-For that your proxy wrote, so a visitor cannot fake it. The same rules count views and clicks in the statistics. Another proxy of yours: list it in `define( 'RUNLINE_TRUSTED_PROXIES', '203.0.113.5, 2001:db8::/32' );` in wp-config.php or with the `runline_trusted_proxies` filter.

These limits slow down bots without a cache server; with Redis or Memcached they are exact. Against big floods of requests, a limit on the server is stronger: a rate limiting rule of Cloudflare or of your hosting for `/wp-json/runline/v1/subscribe` and `/wp-json/runline/v1/track`.

= Will it slow down my site? =

No. The bar is a few kilobytes of CSS and JavaScript, loaded only on pages that show a bar.

== Screenshots ==

1. A sale bar with a countdown and a button at the top of a shop, the free shipping progress at the bottom.
2. 100+ ready designs in eight groups, with live thumbnails.
3. The bar editor with the live preview: your messages.
4. Appearance: tilted and crossed ribbons, gradients, borders, shadows and fonts.
5. Display rules and schedule: where, when and for whom the bar shows.
6. Offers: countdown timer, button, coupon, e-mail signup and free shipping progress.
7. Statistics: views, clicks and click rate per day, and the result of the A/B test.
8. The list of bars with 30-day statistics, export and import.
9. On phones: the sale bar, ribbons, reviews and a signup form in a page, free shipping progress in the cart.
10. The Runline block in the block editor.
11. New in 1.1: a timer every day until a time ("order by 14:00") and WhatsApp, call and Messenger buttons.
12. New designs for the holidays of the year: Grandparents' Day, Women's Day, Children's Day, Advent and more.

== Source code / Build ==

Runline ships its readable sources. The admin app and the block are written in modern JavaScript (React) in `src/` and built into `build/` with the official WordPress tools ([@wordpress/scripts](https://www.npmjs.com/package/@wordpress/scripts)):

1. `cd wp-content/plugins/runline`
2. `npm install`
3. `npm run build` (or `npm run start` while you change the code)

The scripts and styles of the bar on the site (`assets/js/*.js`, `assets/css/runline.css`) are plain files; the `.min` versions next to them are minified copies of the same code.

== External services ==

Runline works without any external service. Two optional features connect to one:

* **E-mail services** — only when you choose one in the signup form of a bar and add its API key (or webhook address) in Runline → Settings. When a visitor subscribes, their e-mail address is sent from your server to that service to add them to your list. Mailchimp (us*.api.mailchimp.com): [terms](https://mailchimp.com/legal/terms/), [privacy](https://www.intuit.com/privacy/statement/). MailerLite (connect.mailerlite.com): [terms](https://www.mailerlite.com/legal/terms-of-service), [privacy](https://www.mailerlite.com/legal/privacy-policy). Brevo (api.brevo.com): [terms](https://www.brevo.com/legal/termsofuse/), [privacy](https://www.brevo.com/legal/privacypolicy/). Kit (api.kit.com): [terms](https://kit.com/terms), [privacy](https://kit.com/privacy). Klaviyo (a.klaviyo.com): [terms](https://www.klaviyo.com/legal/terms-of-service), [privacy](https://www.klaviyo.com/legal/privacy-notice). Omnisend (api.omnisend.com): [terms](https://www.omnisend.com/terms/), [privacy](https://www.omnisend.com/privacy-policy/). Webhook: the e-mail address, the optional text of the bar, your site address and the date go to the address you enter (for example Zapier, Make or n8n) under that service's terms. FluentCRM and MailPoet are plugins on your own site: nothing leaves it.
* **Google Analytics, Google Tag Manager, Meta Pixel** — Runline loads none of them. When your site already has them, the bars pass their events to them in the browser (they then send them to Google or Meta under their terms). Switch it off in Runline → Settings.
* **Google Fonts** — only when you choose a Google font for a bar. Your server downloads the font once from fonts.googleapis.com and fonts.gstatic.com and keeps it in your uploads folder; visitors get it from your site, so no visitor data goes to Google. [Google Fonts terms](https://developers.google.com/fonts/terms), [privacy](https://policies.google.com/privacy).

== Changelog ==

= 1.2.1 =
Safer e-mail signup and more exact limits against bots.

* Signup: when the e-mail service (Mailchimp…) is down, the address is kept in Runline → Subscribers and sent again every hour (6 tries, or "Send them now"). The list shows which addresses are still waiting, and says so when WP-Cron of the site seems to be off.
* Signup: if the address could be kept nowhere, the visitor sees an error and gets no coupon (before, "Thank you" always showed).
* Signup: the text of the consent box and the time it was ticked are kept with the address (also in the CSV and in Tools → Export Personal Data).
* Limits per visitor: the real address behind Cloudflare and behind a proxy of the host, which a visitor can no longer fake with a header. Own proxies: the constant RUNLINE_TRUSTED_PROXIES or the filter runline_trusted_proxies. The same on every PHP version (IPv4 and IPv6).
* Limits are exact with an object cache (Redis, Memcached).
* Webhook: no addresses of the server or the local network (filter runline_webhook_local to allow them).
* More than 100 bars switched on: all of them count, in the order of their priority. Faster with many bars.
* Deleting the plugin (with "Also delete all bars and settings") also removes its counters and planned tasks.
* Google Fonts: a font is marked as ready only when all its files were saved; a failed download (full disk…) is cleaned up and tried again on the next save. Downloads have a size limit.

= 1.2.0 =
Delivery dates in the bar, with Dayslot — our free plugin for WooCommerce delivery dates. Without Dayslot nothing changes.

* New variables: {delivery_date} ("Next delivery: tomorrow"), {pickup_date} and {places_left} ("Delivery places left for Saturday: 3", shown only when 5 or fewer are left).
* New timer: "until the next delivery date changes" — "Order in 02:15:30 — delivery tomorrow".
* New display rules: "No delivery today" and "No delivery tomorrow", from the days off in Dayslot.
* The free shipping progress also takes the "free delivery from" amount of Dayslot.
* The dates stay right on cached pages: "today" and "tomorrow" are written again in the browser.
* 5 new designs for deliveries, 116 in all.
* Fix: a still bar no longer shows a separator after its last message.

= 1.1.0 =
A big update: 11 new features and 39 new designs. Everything is still free.

* Security: limits on the server for the click statistics, so views and clicks cannot be inflated by calling the site directly. Thanks to Ali Attia for the private report.
* Timers: "every day until a time" ("Order in 02:15:30 — we ship today") and a personal timer for each visitor ("Your offer ends in 14:59").
* Signup: a coupon shown right after subscribing; new e-mail services Kit, Klaviyo, Omnisend, FluentCRM, MailPoet and webhooks (Zapier, Make, n8n).
* Display: the bar can come in after some seconds or after scrolling; new rules "First visit", "Returning visitor" and "Viewed at least N pages".
* Messages: each message can have its own dates and shows and hides by itself.
* Contact buttons: WhatsApp, call and Messenger.
* Variables: {cart_total}, {cart_count}, {visitor_country} and {open_now} with your opening hours.
* Analytics: events for Google Analytics 4, Google Tag Manager and Meta Pixel.
* Effects: a soft pulse for the button, confetti when the coupon is copied.
* Designs: 39 new, 111 in all — holidays of the year (Grandparents' Day, Women's Day, Children's Day, Advent…), parties, trades, new styles, and a ready design for every new feature.

= 1.0.2 =
* Fix: "Keep at the top while scrolling" now also works in themes that hide overflow on the whole page (common with Elementor and Hello Elementor).
* Fix: a bar kept at the top now always moves a fixed theme header below it, also headers that become fixed only after scrolling (Elementor "Sticky"). Before, such a header covered the bar.
* Fix: a theme header with a higher layer (z-index) no longer slides over the bar kept at the top while the page scrolls.
* Fix: notices of other plugins no longer squeeze the buttons at the top of the Runline screen.
* Fix: the "Shadow", "Ribbon" and "Send addresses to" lists in the editor were empty.
* Better on phones and laptops: the list of bars keeps the switch and the buttons on phones, names are not cut, the editor's Save button stays in reach.
* New: 12 ready designs — Black Friday gold, winter sale, order before Christmas, free gift, back in stock, loyalty club, refer a friend, we are hiring, same-day delivery, opening hours, aurora and minimal pastel.

= 1.0.0 =
* First public release.
