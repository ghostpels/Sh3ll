/**
 * Design gallery: live thumbnails of the ready designs, filtered by category.
 * mode "new"   — a page: pick a design (or start from scratch) for a new bar.
 * mode "apply" — inside a modal of the editor: take the look of a design.
 */
import { useEffect, useRef, useState, useMemo } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Button } from '@wordpress/components';
import { renderBar } from './render';
import { config, fromServer } from './api';
import { loadGoogleFont } from './fonts';

export function designById( id ) {
	return ( config.designs || [] ).find( ( design ) => design.id === id );
}

export default function Gallery( { mode, onPick } ) {
	const [ category, setCategory ] = useState( 'all' );
	const grid = useRef( null );
	const designs = useMemo(
		() =>
			( config.designs || [] ).filter(
				( design ) => 'all' === category || design.category === category
			),
		[ category ]
	);

	// Fonts of the designs (downloaded to the site once).
	useEffect( () => {
		( config.designs || [] ).forEach( ( design ) =>
			loadGoogleFont( design.settings.font )
		);
	}, [] );

	// Thumbnails are real bars: let runline.js set their speed.
	useEffect( () => {
		if ( ! grid.current ) {
			return;
		}
		// Thumbnails are pictures: nothing inside them can be clicked or focused.
		grid.current
			.querySelectorAll( '.runline-design__thumb' )
			.forEach( ( thumb ) => ( thumb.inert = true ) );
		if ( window.runlineInit ) {
			window.runlineInit( grid.current );
		}
	}, [ designs ] );

	const thumb = ( design ) =>
		renderBar( fromServer( design.settings ), {
			id: 'runline-design-' + design.id,
			fonts: config.fonts,
			maxItems: config.maxItems,
			announcements: design.name,
			close: __( 'Close', 'runline' ),
			tzOffset: config.tzOffset,
			daysFormat: config.daysFormat,
			vars: config.vars,
		} );

	const categories = Object.entries( config.categories || {} );

	return (
		<div className={ 'runline-gallery runline-gallery--' + mode }>
			<div
				className="runline-gallery__filter"
				role="group"
				aria-label={ __( 'Category', 'runline' ) }
			>
				{ [ [ 'all', __( 'All', 'runline' ) ], ...categories ].map(
					( [ key, label ] ) => (
						<Button
							key={ key }
							className={ category === key ? 'is-active' : '' }
							aria-pressed={ category === key }
							onClick={ () => setCategory( key ) }
						>
							{ label }
						</Button>
					)
				) }
			</div>
			<div className="runline-gallery__grid" ref={ grid }>
				{ 'new' === mode && 'all' === category && (
					<div className="runline-design runline-design--blank">
						<div
							className="runline-design__thumb"
							aria-hidden="true"
						>
							<span className="dashicons dashicons-plus-alt2" />
						</div>
						<button
							type="button"
							className="runline-design__pick"
							onClick={ () => onPick( null ) }
						>
							{ __( 'Start from scratch', 'runline' ) }
						</button>
						<span className="runline-design__cat">
							{ __( 'Simple dark bar', 'runline' ) }
						</span>
					</div>
				) }
				{ designs.map( ( design ) => (
					<div className="runline-design" key={ design.id }>
						<div
							className="runline-design__thumb"
							aria-hidden="true"
							dangerouslySetInnerHTML={ {
								__html: thumb( design ),
							} }
						/>
						<button
							type="button"
							className="runline-design__pick"
							onClick={ () => onPick( design ) }
						>
							{ design.name }
						</button>
						<span className="runline-design__cat">
							{ ( config.categories || {} )[ design.category ] }
						</span>
					</div>
				) ) }
			</div>
		</div>
	);
}
