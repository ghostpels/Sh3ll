/**
 * The HTML of a bar for the live preview — the same markup as runline_render_bar() in includes/render.php with
 * $place = "preview", made in the browser so every change shows at once. tests/render-parity.mjs compares the two.
 * No imports: the test loads this file in Node.
 */

const ALLOWED_TAGS = [ 'strong', 'b', 'em', 'i', 'u', 's', 'br', 'span' ];
const SAFE_SCHEMES = [
	'http',
	'https',
	'mailto',
	'tel',
	'ftp',
	'ftps',
	'sms',
	'news',
	'irc',
	'irc6',
	'ircs',
	'gopher',
	'nntp',
	'feed',
	'telnet',
	'mms',
	'rtsp',
	'svn',
	'xmpp',
	'webcal',
	'urn',
];

/**
 * Like esc_html() / esc_attr().
 */
export function esc( value ) {
	return String( value )
		.replace( /&/g, '&amp;' )
		.replace( /</g, '&lt;' )
		.replace( />/g, '&gt;' )
		.replace( /"/g, '&quot;' )
		.replace( /'/g, '&#039;' );
}

function escText( value ) {
	return String( value )
		.replace( /&/g, '&amp;' )
		.replace( /</g, '&lt;' )
		.replace( />/g, '&gt;' );
}

/**
 * Like sanitize_text_field(): no tags, no line breaks, single spaces.
 */
export function plainText( value ) {
	return String( value )
		.replace( /<[^>]*>/g, '' )
		.replace( /\s+/g, ' ' )
		.trim();
}

/**
 * Saved texts come with &amp; etc. (like wp_specialchars_decode()); the editor works with plain characters.
 */
export function decodeText( value ) {
	return String( value )
		.replace( /&lt;/g, '<' )
		.replace( /&gt;/g, '>' )
		.replace( /&quot;/g, '"' )
		.replace( /&#0?39;/g, "'" )
		.replace( /&amp;/g, '&' );
}

/**
 * Item text: simple formatting tags stay, every other tag goes, its words stay (like wp_kses()).
 */
export function cleanText( value ) {
	return String( value )
		.split( /(<[^<>]*>)/ )
		.map( ( part ) => {
			const tag = /^<(\/?)([a-zA-Z][a-zA-Z0-9]*)\b([^>]*?)\/?>$/.exec(
				part
			);
			if ( ! tag ) {
				return escText( part );
			}
			const name = tag[ 2 ].toLowerCase();
			if ( ! ALLOWED_TAGS.includes( name ) ) {
				return '';
			}
			if ( tag[ 1 ] ) {
				return '</' + name + '>';
			}
			const cls =
				'span' === name
					? /\bclass\s*=\s*("([^"]*)"|'([^']*)')/i.exec( tag[ 3 ] )
					: null;
			return cls
				? '<span class="' + esc( cls[ 2 ] ?? cls[ 3 ] ) + '">'
				: '<' + name + '>';
		} )
		.join( '' )
		.trim();
}

/**
 * Like esc_url(): unsafe schemes give "", a bare domain gets http://.
 */
export function cleanUrl( value ) {
	let url = String( value ).trim().replace( / /g, '%20' );
	if ( ! url ) {
		return '';
	}
	const scheme = /^([a-z][a-z0-9+.-]*):/i.exec( url );
	if ( scheme ) {
		if ( ! SAFE_SCHEMES.includes( scheme[ 1 ].toLowerCase() ) ) {
			return '';
		}
	} else if ( ! /^[/#?]/.test( url ) && ! /^[a-z0-9-]+\.php/i.test( url ) ) {
		url = 'http://' + url;
	}
	return url
		.replace( /&/g, '&#038;' )
		.replace( /'/g, '&#039;' )
		.replace( /["<>]/g, '' );
}

/**
 * Items the site would show: empty ones dropped, at most maxItems.
 */
export function visibleItems( items, maxItems ) {
	return ( items || [] )
		.map( ( item ) => ( {
			...item,
			html: cleanText( item.text || '' ),
			icon: plainText( item.icon || '' ),
			image: cleanUrl( item.image || '' ),
			author: plainText( item.author || '' ),
		} ) )
		.filter(
			( item ) =>
				'' !== item.html || '' !== item.icon || '' !== item.image
		)
		.slice( 0, maxItems || 10 );
}

/** Like runline_shipping_price(): a price in the format of the shop. */
export function money( amount, fmt ) {
	const f = fmt || {
		symbol: '',
		format: '%2$s',
		decimals: 2,
		dec: '.',
		thou: ',',
	};
	const parts = Math.abs( amount ).toFixed( f.decimals ).split( '.' );
	parts[ 0 ] = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, f.thou );
	return f.format
		.replace( '%1$s', f.symbol )
		.replace( '%2$s', parts.join( f.dec ) );
}

/** "2d 03:04:05" or "03:04:05" (like runline_countdown_text()). */
export function countdownText( seconds, daysFormat ) {
	const pad = ( n ) => ( n < 10 ? '0' : '' ) + n;
	seconds = Math.max( 0, Math.floor( seconds ) );
	const days = Math.floor( seconds / 86400 );
	const time =
		pad( Math.floor( ( seconds % 86400 ) / 3600 ) ) +
		':' +
		pad( Math.floor( ( seconds % 3600 ) / 60 ) ) +
		':' +
		pad( seconds % 60 );
	return days
		? ( daysFormat || '%dd' ).replace( '%d', days ) + ' ' + time
		: time;
}

/** Next "HH:MM" on one of the days (1 = Monday … 7 = Sunday, none = every day), in ms; like runline_daily_end(). */
export function dailyEnd( time, days, now, tzOffset ) {
	const parts = String( time || '00:00' ).split( ':' );
	const local = Math.floor( now / 1000 ) * 1000 + tzOffset * 60000;
	const midnight = local - ( local % 86400000 );
	for ( let i = 0; i < 8; i++ ) {
		const at =
			midnight +
			i * 86400000 +
			( parseInt( parts[ 0 ], 10 ) * 60 + parseInt( parts[ 1 ], 10 ) ) *
				60000;
		const day = new Date( at ).getUTCDay() || 7;
		if ( at > local && ( ! days.length || days.includes( day ) ) ) {
			return at - tzOffset * 60000;
		}
	}
	return 0;
}

/** {open_now}: like runline_is_open(). */
export function isOpen( hours, now, tzOffset ) {
	const local = new Date( now + tzOffset * 60000 );
	const day = local.getUTCDay() || 7;
	const minutes = local.getUTCHours() * 60 + local.getUTCMinutes();
	const mins = ( t, fallback ) =>
		t
			? parseInt( t.slice( 0, 2 ), 10 ) * 60 +
				parseInt( t.slice( 3 ), 10 )
			: fallback;
	const days = hours.days || [];
	return (
		( ! days.length || days.includes( day ) ) &&
		minutes >= mins( hours.from, 0 ) &&
		minutes < mins( hours.to, 1440 )
	);
}

/** End of the countdown in ms; "YYYY-MM-DDTHH:MM" is in the site time zone (offset in minutes). 0 = none. */
export function countdownEnd( countdown, tzOffset, saleEnd, now ) {
	const source = ( countdown && countdown.source ) || 'date';
	const at = now || Date.now();
	if ( countdown && countdown.on && 'daily' === source ) {
		return dailyEnd(
			countdown.daily,
			countdown.daily_days || [],
			at,
			tzOffset || 0
		);
	}
	if ( countdown && countdown.on && 'visitor' === source ) {
		return (
			Math.floor( at / 1000 ) * 1000 + ( countdown.minutes || 15 ) * 60000
		);
	}
	if ( countdown && countdown.on && 'date' !== source ) {
		return saleEnd || 0;
	}
	const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(
		( countdown && countdown.on && countdown.end ) || ''
	);
	if ( ! m ) {
		return 0;
	}
	return (
		Date.UTC( +m[ 1 ], m[ 2 ] - 1, +m[ 3 ], +m[ 4 ], +m[ 5 ] ) -
		( tzOffset || 0 ) * 60000
	);
}

function countdownSpan( s, end, options ) {
	const cd = s.countdown;
	const left = Math.floor( ( end - ( options.now || Date.now() ) ) / 1000 );
	const after = 'text' === cd.after ? plainText( cd.after_text || '' ) : '';
	const text =
		left > 0 || '' === after
			? countdownText( left, options.daysFormat )
			: after;
	let extra = '';
	if ( 'daily' === cd.source ) {
		extra =
			' data-daily="' +
			esc( cd.daily ) +
			'" data-days="' +
			esc( ( cd.daily_days || [] ).join( ',' ) ) +
			'" data-tzo="' +
			( options.tzOffset || 0 ) +
			'"';
	} else if ( 'visitor' === cd.source ) {
		extra = ' data-visitor="' + parseInt( cd.minutes, 10 ) + '"';
	}
	return (
		'<span class="runline__cd" data-end="' +
		end +
		'" data-d="' +
		esc( options.daysFormat || '%dd' ) +
		'" data-after="' +
		esc( after ) +
		'"' +
		extra +
		'>' +
		esc( text ) +
		'</span>'
	);
}

function openSpan( hours, options ) {
	const h = hours || {};
	const tzo = options.tzOffset || 0;
	const open = isOpen( h, options.now || Date.now(), tzo );
	return (
		'<span class="runline__open" data-days="' +
		esc( ( h.days || [] ).join( ',' ) ) +
		'" data-from="' +
		esc( h.from || '' ) +
		'" data-to="' +
		esc( h.to || '' ) +
		'" data-tzo="' +
		tzo +
		'" data-open="' +
		esc( plainText( h.open || '' ) ) +
		'" data-closed="' +
		esc( plainText( h.closed || '' ) ) +
		'">' +
		esc( plainText( ( open ? h.open : h.closed ) || '' ) ) +
		'</span>'
	);
}

const CONTACT_ICONS = {
	whatsapp:
		'M12 2a10 10 0 0 0-8.7 14.9L2 22l5.3-1.4A10 10 0 1 0 12 2zm5.3 14c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.8s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.4 0 .5l-.3.5-.4.4c-.1.1-.3.3-.1.6.1.3.7 1.1 1.4 1.8 1 .9 1.8 1.1 2.1 1.3.3.1.4.1.6-.1l.8-1c.2-.3.4-.2.6-.1l1.9.9c.3.1.5.2.5.3.1.2.1.8-.2 1.4z',
	phone: 'M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1z',
	messenger:
		'M12 2C6.5 2 2 6.1 2 11.3c0 2.9 1.4 5.5 3.7 7.2V22l3.4-1.9c.9.3 1.9.4 2.9.4 5.5 0 10-4.1 10-9.2S17.5 2 12 2zm1 12.4-2.6-2.7-5 2.7 5.5-5.8 2.6 2.7 4.9-2.7z',
};

/** Contact settings with only the characters the site keeps (like the "phone" schema in PHP). */
function contactParts( c ) {
	const phone = ( v ) =>
		String( v || '' )
			.replace( /[^\d+]/g, '' )
			.replace( /(?!^)\+/g, '' )
			.slice( 0, 20 );
	const links = [];
	if ( ! c || ! c.on ) {
		return links;
	}
	const wa = phone( c.whatsapp );
	const tel = phone( c.phone );
	const ms = String( c.messenger || '' ).replace( /[^A-Za-z0-9.]/g, '' );
	if ( wa ) {
		links.push( [
			'whatsapp',
			'https://wa.me/' + wa.replace( /^\+/, '' ),
			'WhatsApp',
		] );
	}
	if ( tel ) {
		links.push( [ 'phone', 'tel:' + tel, null ] );
	}
	if ( ms ) {
		links.push( [ 'messenger', 'https://m.me/' + ms, 'Messenger' ] );
	}
	return links;
}

/** Like runline_contact_html(). */
function contactHtml( c, options ) {
	const links = contactParts( c );
	if ( ! links.length ) {
		return '';
	}
	return (
		'<div class="runline__contact">' +
		links
			.map(
				( [ type, url, name ] ) =>
					'<a class="runline__ct runline__ct--' +
					type +
					'" href="' +
					esc( url ) +
					'"' +
					( 'phone' === type
						? ''
						: ' target="_blank" rel="noopener"' ) +
					'><svg class="runline__ct-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path fill="currentColor" d="' +
					CONTACT_ICONS[ type ] +
					'"/></svg><span class="runline__ct-name">' +
					esc( name || options.call || 'Call' ) +
					'</span></a>'
			)
			.join( '' ) +
		'</div>'
	);
}

function group( items, separator, copy, vars ) {
	let html = copy
		? '<ul class="runline__group" aria-hidden="true">'
		: '<ul class="runline__group">';
	items.forEach( ( item ) => {
		let inner = '';
		if ( '' !== item.icon ) {
			inner +=
				'<span class="runline__icon" aria-hidden="true">' +
				esc( item.icon ) +
				'</span>';
		}
		let text = Object.keys( vars ).reduce(
			( acc, name ) => acc.split( name ).join( vars[ name ] ),
			item.html
		);
		if ( '' !== item.image ) {
			const alt = '' !== text ? '' : plainText( item.author || '' );
			text =
				'<img class="runline__img" src="' +
				item.image +
				'" alt="' +
				esc( alt ) +
				'" decoding="async">' +
				text;
		}
		const url = cleanUrl( item.url || '' );
		if ( '' !== url ) {
			let attrs = ' href="' + url + '"';
			if ( item.new_tab ) {
				attrs += ' target="_blank" rel="noopener"';
			}
			if ( copy ) {
				attrs += ' tabindex="-1"';
			}
			text = '<a' + attrs + '>' + text + '</a>';
		}
		text = '<span class="runline__text">' + text + '</span>';
		if ( '' !== item.author ) {
			text =
				'<span class="runline__body">' +
				text +
				'<span class="runline__author">' +
				esc( item.author ) +
				'</span></span>';
		}
		const date = ( v ) =>
			/^\d{4}-\d{2}-\d{2}$/.test( v || '' ) ? v : '';
		const dates =
			( date( item.from ) ? ' data-from="' + item.from + '"' : '' ) +
			( date( item.to ) ? ' data-to="' + item.to + '"' : '' );
		html +=
			'<li class="runline__item"' + dates + '>' + inner + text + '</li>';
		if ( '' !== separator ) {
			html +=
				'<li class="runline__sep" aria-hidden="true">' +
				esc( separator ) +
				'</li>';
		}
	} );
	return html + '</ul>';
}

const chars = ( text ) => [ ...plainText( text || '' ) ].length;

function mobileCrowded( s, end, hasButton, hasCoupon ) {
	if ( s.signup && s.signup.on ) {
		return true;
	}
	const char = s.font_size_mobile * ( s.uppercase ? 0.72 : 0.6 );
	const timer = end && 'text' !== s.countdown.place;
	let width = 0;
	if ( '' !== plainText( s.label || '' ) && ! timer ) {
		width += chars( s.label ) * char + 32;
	}
	if ( timer ) {
		width += 11 * char + 20;
	}
	if ( hasCoupon ) {
		width +=
			( chars( s.coupon.code ) + chars( s.coupon.copy ) ) * char + 56;
	}
	if ( hasButton ) {
		width += chars( s.button.text ) * char + 32;
	}
	if ( s.closable ) {
		width += 40;
	}
	width += 40 * contactParts( s.contact ).length;
	return width > 390 - 120;
}

/**
 * @param {Object} s       Settings (texts as plain characters).
 * @param {Object} options { id, fonts: { key: stack }, maxItems, announcements, close (translated), tzOffset,
 *                         daysFormat, now }.
 * @return {string} HTML, or "" when the bar has no items.
 */
export function renderBar( s, options ) {
	// Automatic messages (options.items), and the written ones after them with "also my own messages".
	let list = options.items || s.items;
	if ( options.items && s.source && s.source.mix ) {
		list = options.items.concat( s.items );
	}
	const items = visibleItems( list, options.maxItems );
	if ( ! items.length ) {
		return '';
	}
	const label = plainText( s.label || '' );
	const separator = plainText( s.separator || '' );
	const classes = [
		'runline',
		'runline--preview',
		'runline--' + s.direction,
		'runline--mode-' + ( s.mode || 'marquee' ),
	];
	if ( 'cards' === s.style ) {
		classes.push( 'runline--cards' );
	}
	if ( s.shadow && 'none' !== s.shadow ) {
		classes.push( 'runline--shadow-' + s.shadow );
	}
	String( s.css_class || '' )
		.split( /\s+/ )
		.map( ( name ) => name.replace( /[^A-Za-z0-9_-]/g, '' ) )
		.filter( Boolean )
		.forEach( ( name ) => classes.push( name ) );
	if ( s.pause_hover ) {
		classes.push( 'runline--pause-hover' );
	}
	if ( s.uppercase ) {
		classes.push( 'runline--upper' );
	}
	if ( 'boxed' === s.width ) {
		classes.push( 'runline--boxed', 'runline--align-' + s.align );
	}
	const end = countdownEnd(
		s.countdown,
		options.tzOffset,
		options.saleEnd,
		options.now
	);
	// Phones: the same rough measure as runline_mobile_crowded() in render.php.
	const mobile = s.mobile_layout || 'stack';
	const btn = s.button || {};
	const cp = s.coupon || {};
	const hasButton =
		btn.on &&
		'' !== plainText( btn.text || '' ) &&
		'' !== cleanUrl( btn.url || '' );
	const hasCoupon = cp.on && '' !== plainText( cp.code || '' );
	const hasForm = !! ( s.signup && s.signup.on );
	const crowded =
		( hasForm ||
			hasButton ||
			hasCoupon ||
			contactParts( s.contact ).length > 0 ) &&
		'inline' !== mobile &&
		mobileCrowded( s, end, hasButton, hasCoupon );
	if ( crowded ) {
		classes.push( 'runline--m-' + mobile );
	}
	const link = s.link_color || s.color;
	const vars = [
		[ '--rl-bg', s.bg ],
		[ '--rl-color', s.color ],
		[ '--rl-link', link ],
		[ '--rl-link-hover', s.link_hover || link ],
		[ '--rl-label-bg', s.label_bg ],
		[ '--rl-label-color', s.label_color ],
		[ '--rl-font', ( options.fonts || {} )[ s.font ] || 'inherit' ],
		[ '--rl-fs', s.font_size + 'px' ],
		[ '--rl-fs-m', s.font_size_mobile + 'px' ],
		[ '--rl-weight', s.font_weight ],
		[ '--rl-h', s.height + 'px' ],
		[ '--rl-gap', s.gap + 'px' ],
		[
			'--rl-dur',
			Math.max( 8, Math.round( ( items.length * 300 ) / s.speed ) ) + 's',
		],
	];
	if ( 'boxed' === s.width ) {
		vars.push( [ '--rl-max', s.max_width + 'px' ] );
	}
	if ( s.radius ) {
		vars.push( [ '--rl-radius', s.radius + 'px' ] );
	}
	if ( s.bg2 ) {
		vars.push( [
			'--rl-bg-image',
			'linear-gradient(' + s.bg_angle + 'deg,' + s.bg + ',' + s.bg2 + ')',
		] );
	}
	if ( s.border_width ) {
		vars.push( [
			'--rl-border',
			s.border_width + 'px solid ' + s.border_color,
		] );
	}
	if ( end ) {
		vars.push( [ '--rl-cd-bg', s.countdown.bg ] );
		vars.push( [ '--rl-cd-color', s.countdown.color ] );
	}
	if ( items.some( ( item ) => '' !== item.image ) ) {
		vars.push( [
			'--rl-img-h',
			Math.round( ( s.height * s.image_height ) / 100 ) + 'px',
		] );
	}
	const button = s.button || {};
	const coupon = s.coupon || {};
	if ( button.on ) {
		vars.push( [ '--rl-btn-bg', button.bg ] );
		vars.push( [ '--rl-btn-color', button.color ] );
		vars.push( [ '--rl-btn-radius', button.radius + 'px' ] );
	}
	if ( coupon.on ) {
		vars.push( [ '--rl-cp-bg', coupon.bg ] );
		vars.push( [ '--rl-cp-color', coupon.color ] );
	}
	// Free shipping (the preview pretends a third of the threshold is in the cart).
	const shipping = s.shipping || {};
	const threshold =
		shipping.threshold > 0 ? shipping.threshold : options.shippingAuto || 0;
	let ship = null;
	if ( shipping.on && threshold > 0 ) {
		const inCart = Math.round( ( threshold / 3 ) * 100 ) / 100;
		const left =
			'<span class="runline__fsleft">' +
			esc( money( threshold - inCart, options.shippingFmt ) ) +
			'</span>';
		ship = {
			left,
			percent: Math.round( ( 100 * inCart ) / threshold ),
			block:
				'<div class="runline__shipping" aria-live="polite"><span class="runline__ship-text">' +
				esc( plainText( shipping.before || '' ) )
					.split( '{free_shipping_left}' )
					.join( left ) +
				'</span></div>',
		};
		vars.push( [ '--rl-ship', shipping.color ] );
	}
	const style = vars
		.map( ( pair ) => pair[ 0 ] + ':' + pair[ 1 ] + ';' )
		.join( '' );

	let html =
		'<div id="' +
		esc( options.id ) +
		'" class="' +
		esc( classes.join( ' ' ) ) +
		'" style="' +
		esc( style ) +
		'"' +
		' data-speed="' +
		parseInt( s.speed, 10 ) +
		'" data-speed-m="' +
		parseInt( s.speed_mobile, 10 ) +
		'" data-interval="' +
		parseInt( s.interval || 4, 10 ) +
		'"' +
		' data-key="preview" role="region" aria-label="' +
		esc( label || options.announcements ) +
		'">';
	if ( '' !== label ) {
		html += '<div class="runline__label">' + esc( label ) + '</div>';
	}
	const cd = end ? countdownSpan( s, end, options ) : '';
	const ab = s.ab || {};
	const itemsB = visibleItems( ab.items, options.maxItems );
	const textVars = {
		...( options.vars || {} ),
		'{countdown}': cd,
		'{coupon}': coupon.on
			? '<span class="runline__cp-code">' +
				esc( plainText( coupon.code || '' ) ) +
				'</span>'
			: '',
		'{free_shipping_left}': ship ? ship.left : '',
		'{cart_total}': '<span class="runline__cart-total"></span>',
		'{cart_count}': '<span class="runline__cart-count"></span>',
		'{visitor_country}':
			'<span class="runline__country">' +
			esc( options.yourCountry || 'your country' ) +
			'</span>',
		'{open_now}': openSpan( s.hours, options ),
	};
	const trackB =
		ab.on &&
		itemsB.length &&
		'manual' === ( ( s.source || {} ).type || 'manual' )
			? '<div class="runline__track" data-variant="b">' +
				group( itemsB, separator, false, textVars ) +
				group( itemsB, separator, true, textVars ) +
				'</div>'
			: '';
	const prefix = end ? plainText( s.countdown.prefix || '' ) : '';
	const fixedCd =
		end && 'text' !== s.countdown.place
			? '<div class="runline__countdown">' +
				( '' !== prefix
					? '<span class="runline__cd-prefix">' +
						esc( prefix ) +
						'</span> '
					: '' ) +
				cd +
				'</div>'
			: '';
	if ( 'left' === s.countdown.place ) {
		html += fixedCd;
	}
	if ( ship ) {
		html += ship.block;
	}
	html +=
		'<div class="runline__viewport"><div class="runline__track">' +
		group( items, separator, false, textVars ) +
		group( items, separator, true, textVars ) +
		'</div>' +
		trackB +
		'</div>';
	if ( crowded && 'stack' === mobile ) {
		html += '<span class="runline__break" aria-hidden="true"></span>';
	}
	if ( 'right' === s.countdown.place ) {
		html += fixedCd;
	}
	const code = plainText( coupon.code || '' );
	if ( coupon.on && '' !== code ) {
		const cpPrefix = plainText( coupon.prefix || '' );
		html +=
			'<div class="runline__coupon">' +
			( '' !== cpPrefix
				? '<span class="runline__cp-prefix">' +
					esc( cpPrefix ) +
					'</span> '
				: '' ) +
			'<span class="runline__cp-code">' +
			esc( code ) +
			'</span> <button type="button" class="runline__copy" data-code="' +
			esc( code ) +
			'" data-copied="' +
			esc( plainText( coupon.copied || '' ) ) +
			'"' +
			( coupon.confetti ? ' data-confetti="1"' : '' ) +
			'>' +
			esc( plainText( coupon.copy || '' ) ) +
			'</button></div>';
	}
	const signup = s.signup || {};
	if ( signup.on ) {
		const consent = plainText( signup.consent || '' );
		const ph = plainText( signup.placeholder || '' );
		html +=
			'<form class="runline__signup" novalidate>' +
			'<input type="email" name="email" required placeholder="' +
			esc( ph ) +
			'" aria-label="' +
			esc( ph ) +
			'" autocomplete="email">' +
			( '' !== consent
				? '<label class="runline__consent"><input type="checkbox" name="consent" value="1" required> <span>' +
					esc( consent ) +
					'</span></label>'
				: '' ) +
			'<input type="text" name="website" class="runline__hp" tabindex="-1" autocomplete="off" aria-hidden="true">' +
			'<button type="submit">' +
			esc( plainText( signup.button || '' ) ) +
			'</button>' +
			'<span class="runline__signup-msg" aria-live="polite" data-ok="' +
			esc( plainText( signup.success || '' ) ) +
			'"' +
			( '' !== plainText( signup.coupon || '' )
				? ' data-copy="' +
					esc( plainText( coupon.copy || '' ) ) +
					'" data-copied="' +
					esc( plainText( coupon.copied || '' ) ) +
					'"'
				: '' ) +
			'></span></form>';
	}
	const buttonText = plainText( button.text || '' );
	const buttonUrl = cleanUrl( button.url || '' );
	if ( button.on && '' !== buttonText && '' !== buttonUrl ) {
		html +=
			'<a class="runline__button' +
			( button.pulse ? ' runline__button--pulse' : '' ) +
			'" href="' +
			buttonUrl +
			'"' +
			( button.new_tab ? ' target="_blank" rel="noopener"' : '' ) +
			'>' +
			esc( buttonText ) +
			'</a>';
	}
	html += contactHtml( s.contact, options );
	if ( ship && shipping.progress ) {
		html +=
			'<span class="runline__progress" aria-hidden="true"><i style="width:' +
			ship.percent +
			'%"></i></span>';
	}
	if ( s.closable ) {
		html +=
			'<button type="button" class="runline__close" aria-label="' +
			esc( options.close ) +
			'"><span aria-hidden="true">&times;</span></button>';
	}
	html += '</div>';
	if ( s.ribbon && 'none' !== s.ribbon ) {
		html =
			'<div class="runline-ribbon runline-ribbon--' +
			esc( s.ribbon ) +
			'" style="' +
			esc(
				'--rl-h:' +
					s.height +
					'px;--rl-tilt:' +
					s.tilt +
					'deg;--rl-ribbon2:' +
					s.ribbon2 +
					';'
			) +
			'">' +
			( 'crossed' === s.ribbon
				? '<span class="runline-ribbon__band" aria-hidden="true"></span>'
				: '' ) +
			html +
			'</div>';
	}
	return html;
}
