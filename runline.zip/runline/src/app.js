/**
 * Switches between screens without reloading the page:
 * ?page=runline (list) · &bar=new (design gallery) · &bar=new&design=<id|blank> · &bar=<id> (editor).
 */
import { useState, useEffect, useCallback } from '@wordpress/element';
import { SnackbarList } from '@wordpress/components';
import BarList from './list';
import Editor from './editor';
import GalleryPage from './gallery-page';

function fromUrl( key ) {
	return new URLSearchParams( window.location.search ).get( key ) || '';
}

let nextNotice = 1;

export default function App() {
	const [ bar, setBar ] = useState( () => fromUrl( 'bar' ) );
	const [ design, setDesign ] = useState( () => fromUrl( 'design' ) );
	const [ notices, setNotices ] = useState( [] );
	// The editor sets this while it has unsaved changes.
	const [ guard, setGuard ] = useState( null );

	useEffect( () => {
		const onPop = () => {
			setBar( fromUrl( 'bar' ) );
			setDesign( fromUrl( 'design' ) );
		};
		window.addEventListener( 'popstate', onPop );
		return () => window.removeEventListener( 'popstate', onPop );
	}, [] );

	/**
	 * Go to a screen. target: bar ID, "new" or "" (list); force: skip the unsaved-changes question;
	 * designId: design of a new bar ("blank" = from scratch).
	 */
	const go = useCallback(
		( target, replace, force, designId ) => {
			if ( ! force && guard && ! guard() ) {
				return;
			}
			const url = new URL( window.location.href );
			url.searchParams.delete( 'bar' );
			url.searchParams.delete( 'design' );
			if ( target ) {
				url.searchParams.set( 'bar', target );
			}
			if ( designId ) {
				url.searchParams.set( 'design', designId );
			}
			window.history[ replace ? 'replaceState' : 'pushState' ](
				{},
				'',
				url
			);
			setBar( target ? String( target ) : '' );
			setDesign( designId || '' );
			window.scrollTo( 0, 0 );
		},
		[ guard ]
	);

	const notify = useCallback( ( content ) => {
		const id = 'n' + nextNotice++;
		setNotices( ( list ) => [ ...list.slice( -2 ), { id, content } ] );
	}, [] );

	let screen;
	if ( ! bar ) {
		screen = <BarList go={ go } notify={ notify } />;
	} else if ( 'new' === bar && ! design ) {
		screen = <GalleryPage go={ go } />;
	} else {
		screen = (
			<Editor
				barId={ bar }
				designId={ design }
				go={ go }
				notify={ notify }
				setGuard={ setGuard }
			/>
		);
	}

	return (
		<>
			{ screen }
			<SnackbarList
				className="runline-snackbars"
				notices={ notices }
				onRemove={ ( id ) =>
					setNotices( ( list ) =>
						list.filter( ( notice ) => notice.id !== id )
					)
				}
			/>
		</>
	);
}
