/**
 * Google fonts in the admin: asks the site to download a font (once) and loads its local CSS into the page —
 * or into another document, like the canvas of the block editor (an iframe).
 */
import apiFetch from '@wordpress/api-fetch';

const urls = {};

function addLink( doc, family, url ) {
	const id = 'runline-font-' + family.replace( /\W+/g, '-' ).toLowerCase();
	if ( doc.getElementById( id ) ) {
		return;
	}
	const link = doc.createElement( 'link' );
	link.id = id;
	link.rel = 'stylesheet';
	link.href = url;
	doc.head.appendChild( link );
}

export function loadGoogleFont( font, doc = document ) {
	if ( ! font || 0 !== font.indexOf( 'g:' ) || ! doc ) {
		return;
	}
	const family = font.slice( 2 );
	if ( ! urls[ family ] ) {
		urls[ family ] = apiFetch( {
			path: '/runline/v1/font',
			method: 'POST',
			data: { family },
		} )
			.then( ( res ) => res.url )
			.catch( () => {
				delete urls[ family ];
				return '';
			} );
	}
	urls[ family ].then( ( url ) => url && addLink( doc, family, url ) );
}
