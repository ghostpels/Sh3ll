/**
 * Runline admin app: the list of bars and the bar editor on one page (admin.php?page=runline).
 */
import { createRoot } from '@wordpress/element';
import App from './app';
import './style.css';

const root = document.getElementById( 'runline-app' );
if ( root ) {
	createRoot( root ).render( <App /> );
}
