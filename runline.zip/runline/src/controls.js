/**
 * Small controls of the editor: colour field, segmented buttons, copy button, the list of items.
 */
import { useState, useRef } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { newKey } from './api';
import {
	BaseControl,
	Button,
	ColorIndicator,
	ColorPicker,
	Dropdown,
	TextControl,
	CheckboxControl,
} from '@wordpress/components';

const EMOJI = [
	'🚚',
	'🔥',
	'✨',
	'🎁',
	'⚡',
	'📣',
	'⭐',
	'🎉',
	'💥',
	'❤️',
	'🛍️',
	'⏰',
	'🎈',
	'✅',
	'📦',
	'💳',
	'🌸',
	'☕',
	'🏷️',
	'👉',
];
const SEPARATORS = [ '•', '★', '|', '/', '—', '✦', '·', '◆' ];

let uid = 0;
const useId = ( prefix ) => {
	const ref = useRef( null );
	if ( ! ref.current ) {
		ref.current = prefix + '-' + ++uid;
	}
	return ref.current;
};

/**
 * A colour: swatch button that opens a picker. allowEmpty = "use the text colour" option.
 */
export function ColorField( {
	label,
	value,
	onChange,
	allowEmpty,
	emptyLabel,
} ) {
	const id = useId( 'runline-color' );
	return (
		<BaseControl
			id={ id }
			label={ label }
			className="runline-color"
			__nextHasNoMarginBottom
		>
			<Dropdown
				popoverProps={ { placement: 'bottom-start' } }
				renderToggle={ ( { isOpen, onToggle } ) => (
					<Button
						id={ id }
						className="runline-color__toggle"
						onClick={ onToggle }
						aria-expanded={ isOpen }
						variant="secondary"
					>
						<ColorIndicator
							colorValue={ value || 'transparent' }
							className={ value ? '' : 'is-empty' }
						/>
						<span>{ value || emptyLabel }</span>
					</Button>
				) }
				renderContent={ () => (
					<div className="runline-color__popover">
						<ColorPicker
							color={ value || '#000000' }
							onChange={ onChange }
							enableAlpha={ false }
						/>
						{ allowEmpty && (
							<Button
								variant="tertiary"
								onClick={ () => onChange( '' ) }
							>
								{ emptyLabel }
							</Button>
						) }
					</div>
				) }
			/>
		</BaseControl>
	);
}

/**
 * Two or three choices as joined buttons.
 */
export function Segmented( { label, value, options, onChange } ) {
	return (
		<BaseControl __nextHasNoMarginBottom>
			<BaseControl.VisualLabel>{ label }</BaseControl.VisualLabel>
			<div
				className="runline-segmented"
				role="radiogroup"
				aria-label={ label }
			>
				{ options.map( ( option ) => (
					<Button
						key={ option.value }
						role="radio"
						aria-checked={ value === option.value }
						className={ value === option.value ? 'is-active' : '' }
						icon={ option.icon }
						onClick={ () => onChange( option.value ) }
					>
						{ option.label }
					</Button>
				) ) }
			</div>
		</BaseControl>
	);
}

export function CopyButton( { text, notify } ) {
	return (
		<Button
			size="small"
			icon="admin-page"
			label={ __( 'Copy', 'runline' ) }
			onClick={ () => {
				const done = () =>
					notify && notify( __( 'Copied.', 'runline' ) );
				if ( window.navigator.clipboard ) {
					window.navigator.clipboard.writeText( text ).then( done );
				}
			} }
		/>
	);
}

export function SeparatorField( { value, onChange } ) {
	return (
		<BaseControl __nextHasNoMarginBottom>
			<BaseControl.VisualLabel>
				{ __( 'Separator between items', 'runline' ) }
			</BaseControl.VisualLabel>
			<div
				className="runline-picks"
				role="group"
				aria-label={ __( 'Separator between items', 'runline' ) }
			>
				{ SEPARATORS.map( ( sep ) => (
					<Button
						key={ sep }
						className={ value === sep ? 'is-active' : '' }
						onClick={ () => onChange( sep ) }
					>
						{ sep }
					</Button>
				) ) }
				<Button
					className={ '' === value ? 'is-active' : '' }
					onClick={ () => onChange( '' ) }
				>
					{ __( 'None', 'runline' ) }
				</Button>
				<TextControl
					className="runline-picks__own"
					value={ value }
					onChange={ onChange }
					maxLength={ 8 }
					aria-label={ __( 'Own separator', 'runline' ) }
					placeholder={ __( 'Own', 'runline' ) }
					__nextHasNoMarginBottom
				/>
			</div>
		</BaseControl>
	);
}

function EmojiPicker( { value, onChange } ) {
	return (
		<Dropdown
			popoverProps={ { placement: 'bottom-start' } }
			renderToggle={ ( { isOpen, onToggle } ) => (
				<Button
					className="runline-item__emoji"
					onClick={ onToggle }
					aria-expanded={ isOpen }
					label={ __( 'Emoji or icon', 'runline' ) }
					showTooltip
				>
					{ value || (
						<span className="runline-item__emoji-empty">☺</span>
					) }
				</Button>
			) }
			renderContent={ ( { onClose } ) => (
				<div className="runline-emoji">
					<div className="runline-emoji__grid">
						{ EMOJI.map( ( emoji ) => (
							<Button
								key={ emoji }
								onClick={ () => {
									onChange( emoji );
									onClose();
								} }
							>
								{ emoji }
							</Button>
						) ) }
					</div>
					<TextControl
						label={ __( 'Or type your own', 'runline' ) }
						value={ value }
						onChange={ onChange }
						maxLength={ 8 }
						__nextHasNoMarginBottom
					/>
					<Button
						variant="tertiary"
						onClick={ () => {
							onChange( '' );
							onClose();
						} }
					>
						{ __( 'No icon', 'runline' ) }
					</Button>
				</div>
			) }
		/>
	);
}

/**
 * An image from the Media Library (logo, product photo, avatar).
 */
export function ImagePicker( { value, onChange } ) {
	const open = () => {
		const media = window.wp && window.wp.media;
		if ( ! media ) {
			return;
		}
		const frame = media( {
			title: __( 'Choose an image', 'runline' ),
			button: { text: __( 'Use this image', 'runline' ) },
			library: { type: 'image' },
			multiple: false,
		} );
		frame.on( 'select', () => {
			const file = frame.state().get( 'selection' ).first().toJSON();
			const sizes = file.sizes || {};
			onChange(
				( sizes.medium && sizes.medium.url ) ||
					( sizes.thumbnail && sizes.thumbnail.url ) ||
					file.url
			);
		} );
		frame.open();
	};
	if ( value ) {
		return (
			<span className="runline-item__image">
				<button
					type="button"
					className="runline-item__image-pick"
					onClick={ open }
					aria-label={ __( 'Change image', 'runline' ) }
				>
					<img src={ value } alt="" />
				</button>
				<Button
					size="small"
					icon="no-alt"
					label={ __( 'Remove image', 'runline' ) }
					onClick={ () => onChange( '' ) }
				/>
			</span>
		);
	}
	return (
		<Button
			className="runline-item__emoji"
			icon="format-image"
			label={ __( 'Image or logo', 'runline' ) }
			showTooltip
			onClick={ open }
		/>
	);
}

/**
 * The messages of the bar: add, remove, drag or move up/down.
 */
export function ItemsEditor( { items, onChange, max } ) {
	const [ dragging, setDragging ] = useState( null );
	const [ dated, setDated ] = useState( [] );
	const [ over, setOver ] = useState( null );
	const listId = useId( 'runline-items' );
	const update = ( index, changes ) =>
		onChange(
			items.map( ( item, i ) =>
				i === index ? { ...item, ...changes } : item
			)
		);
	const move = ( from, to ) => {
		if ( to < 0 || to >= items.length || from === to ) {
			return;
		}
		const next = [ ...items ];
		next.splice( to, 0, next.splice( from, 1 )[ 0 ] );
		onChange( next );
	};
	const add = () => {
		onChange( [
			...items,
			{
				text: '',
				url: '',
				new_tab: false,
				icon: '',
				image: '',
				author: '',
				_key: newKey(),
			},
		] );
		window.setTimeout( () => {
			const inputs = document.querySelectorAll(
				'#' + listId + ' .runline-item__text input'
			);
			if ( inputs.length ) {
				inputs[ inputs.length - 1 ].focus();
			}
		}, 50 );
	};

	return (
		<div className="runline-items-editor">
			<ol className="runline-items" id={ listId }>
				{ items.map( ( item, index ) => (
					<li
						key={ item._key || index }
						className={
							'runline-item' +
							( dragging === index ? ' is-dragging' : '' ) +
							( over === index && dragging !== null
								? ' is-over'
								: '' )
						}
						onDragOver={ ( event ) => {
							event.preventDefault();
							setOver( index );
						} }
						onDrop={ ( event ) => {
							event.preventDefault();
							move( dragging, index );
							setDragging( null );
							setOver( null );
						} }
					>
						<span
							className="runline-item__handle dashicons dashicons-menu"
							draggable
							onDragStart={ ( event ) => {
								event.dataTransfer.effectAllowed = 'move';
								event.dataTransfer.setData(
									'text/plain',
									String( index )
								);
								setDragging( index );
							} }
							onDragEnd={ () => {
								setDragging( null );
								setOver( null );
							} }
							title={ __( 'Drag to reorder', 'runline' ) }
							aria-hidden="true"
						/>
						<div className="runline-item__media">
							<EmojiPicker
								value={ item.icon }
								onChange={ ( icon ) =>
									update( index, { icon } )
								}
							/>
							<ImagePicker
								value={ item.image || '' }
								onChange={ ( image ) =>
									update( index, { image } )
								}
							/>
						</div>
						<div className="runline-item__fields">
							<TextControl
								className="runline-item__text"
								value={ item.text }
								onChange={ ( text ) =>
									update( index, { text } )
								}
								placeholder={ __( 'Your message', 'runline' ) }
								aria-label={ sprintf(
									/* translators: %d: item number. */ __(
										'Text of item %d',
										'runline'
									),
									index + 1
								) }
								__nextHasNoMarginBottom
							/>
							<div className="runline-item__link">
								<TextControl
									type="url"
									value={ item.url }
									onChange={ ( url ) =>
										update( index, { url } )
									}
									placeholder={ __(
										'Link (optional), e.g. https://…',
										'runline'
									) }
									aria-label={ sprintf(
										/* translators: %d: item number. */ __(
											'Link of item %d',
											'runline'
										),
										index + 1
									) }
									__nextHasNoMarginBottom
								/>
								{ item.url && (
									<CheckboxControl
										label={ __( 'New tab', 'runline' ) }
										checked={ !! item.new_tab }
										onChange={ ( checked ) =>
											update( index, {
												new_tab: checked,
											} )
										}
										__nextHasNoMarginBottom
									/>
								) }
							</div>
							<TextControl
								className="runline-item__author"
								value={ item.author || '' }
								onChange={ ( author ) =>
									update( index, { author } )
								}
								placeholder={ __(
									'Caption or author (optional), e.g. Anna, Kraków',
									'runline'
								) }
								aria-label={ sprintf(
									/* translators: %d: item number. */ __(
										'Caption of item %d',
										'runline'
									),
									index + 1
								) }
								maxLength={ 80 }
								__nextHasNoMarginBottom
							/>
							{ ( item.from ||
								item.to ||
								dated.includes( index ) ) && (
								<div className="runline-item__dates">
									<TextControl
										type="date"
										label={ __( 'Show from', 'runline' ) }
										value={ item.from || '' }
										onChange={ ( from ) =>
											update( index, { from } )
										}
										__nextHasNoMarginBottom
									/>
									<TextControl
										type="date"
										label={ __(
											'Until (including)',
											'runline'
										) }
										value={ item.to || '' }
										onChange={ ( to ) =>
											update( index, { to } )
										}
										__nextHasNoMarginBottom
									/>
								</div>
							) }
						</div>
						<div className="runline-item__actions">
							<Button
								size="small"
								icon="calendar-alt"
								label={ __(
									'Dates of this message',
									'runline'
								) }
								isPressed={ !! ( item.from || item.to ) }
								onClick={ () =>
									setDated(
										dated.includes( index )
											? dated.filter(
													( i ) => i !== index
												)
											: [ ...dated, index ]
									)
								}
							/>
							<Button
								size="small"
								icon="arrow-up-alt2"
								label={ __( 'Move up', 'runline' ) }
								disabled={ 0 === index }
								onClick={ () => move( index, index - 1 ) }
							/>
							<Button
								size="small"
								icon="arrow-down-alt2"
								label={ __( 'Move down', 'runline' ) }
								disabled={ index === items.length - 1 }
								onClick={ () => move( index, index + 1 ) }
							/>
							<Button
								size="small"
								icon="trash"
								label={ __( 'Remove item', 'runline' ) }
								isDestructive
								onClick={ () =>
									onChange(
										items.filter( ( _, i ) => i !== index )
									)
								}
							/>
						</div>
					</li>
				) ) }
			</ol>
			<div className="runline-items__add">
				<Button
					variant="secondary"
					icon="plus-alt2"
					onClick={ add }
					disabled={ items.length >= max }
				>
					{ __( 'Add item', 'runline' ) }
				</Button>
				<span className="runline-muted">
					{ sprintf(
						/* translators: 1: items now, 2: most items. */ __(
							'%1$d of %2$d',
							'runline'
						),
						items.length,
						max
					) }
				</span>
			</div>
		</div>
	);
}
