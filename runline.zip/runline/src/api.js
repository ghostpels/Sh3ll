/**
 * Calls to the plugin REST API (includes/rest.php) and the data the PHP page passes in window.runlineAdmin.
 */
import apiFetch from '@wordpress/api-fetch';
import { decodeText } from './render';

export const config = window.runlineAdmin || {};

const BASE = '/runline/v1';

let keys = 0;
/** A stable React key for an item (not sent to the server's settings). */
export const newKey = () => 'i' + ++keys;

/**
 * Settings from the server → editor state (texts as plain characters).
 */
export function fromServer( settings ) {
	return {
		...settings,
		items: ( settings.items || [] ).map( ( item ) => ( {
			...item,
			text: decodeText( item.text ),
			_key: newKey(),
		} ) ),
		ab: settings.ab
			? {
					...settings.ab,
					items: ( settings.ab.items || [] ).map( ( item ) => ( {
						...item,
						text: decodeText( item.text ),
						_key: newKey(),
					} ) ),
				}
			: settings.ab,
	};
}

/**
 * Editor state → what is saved (and compared to see unsaved changes).
 */
export function toServer( settings ) {
	return {
		...settings,
		items: settings.items.map( ( { _key, ...item } ) => item ),
		ab: settings.ab
			? {
					...settings.ab,
					items: ( settings.ab.items || [] ).map(
						( { _key, ...item } ) => item
					),
				}
			: settings.ab,
	};
}

function bar( data ) {
	return { ...data, settings: fromServer( data.settings ) };
}

function result( data ) {
	return { ...data, bar: bar( data.bar ) };
}

export const api = {
	list: () =>
		apiFetch( { path: BASE + '/bars' } ).then( ( bars ) =>
			bars.map( bar )
		),
	get: ( id ) => apiFetch( { path: BASE + '/bars/' + id } ).then( bar ),
	create: ( title, settings ) =>
		apiFetch( {
			path: BASE + '/bars',
			method: 'POST',
			data: { title, settings },
		} ).then( result ),
	save: ( id, title, settings ) =>
		apiFetch( {
			path: BASE + '/bars/' + id,
			method: 'POST',
			data: { title, settings },
		} ).then( result ),
	remove: ( id ) =>
		apiFetch( { path: BASE + '/bars/' + id, method: 'DELETE' } ),
	duplicate: ( id ) =>
		apiFetch( {
			path: BASE + '/bars/' + id + '/duplicate',
			method: 'POST',
		} ).then( bar ),
	setActive: ( id, active ) =>
		apiFetch( {
			path: BASE + '/bars/' + id + '/active',
			method: 'POST',
			data: { active },
		} ).then( result ),
};

export function errorText( error ) {
	return ( error && error.message ) || String( error );
}
