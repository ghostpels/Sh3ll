/**
 * "Add bar" screen: the design gallery as a page.
 */
import { __ } from '@wordpress/i18n';
import { Button } from '@wordpress/components';
import Gallery from './gallery';
import { config } from './api';

export default function GalleryPage( { go } ) {
	return (
		<div className="runline-gallery-page">
			<Button
				variant="tertiary"
				icon="arrow-left-alt2"
				className="runline-editor__back"
				href={ config.adminUrl }
				onClick={ ( event ) => {
					event.preventDefault();
					go( '' );
				} }
			>
				{ __( 'All bars', 'runline' ) }
			</Button>
			<h1>{ __( 'Choose a design', 'runline' ) }</h1>
			<p className="runline-intro">
				{ __(
					'Start from a ready design: change the texts, colours and anything else in the next step.',
					'runline'
				) }
			</p>
			<Gallery
				mode="new"
				onPick={ ( design ) =>
					go( 'new', false, true, design ? design.id : 'blank' )
				}
			/>
		</div>
	);
}
