/**
 * Block "Runline bar": shows a bar inside the content, with a live preview in the editor.
 * The site gets the same HTML as the [runline id=""] shortcode (runline_render_block() in includes/block.php).
 */
import { registerBlockType } from '@wordpress/blocks';
import metadata from '../../blocks/bar/block.json';
import Edit from './edit';
import './editor.css';

registerBlockType( metadata.name, {
	...metadata,
	edit: Edit,
	save: () => null,
} );
