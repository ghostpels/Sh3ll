/**
 * Editor of the block: choose a bar in the sidebar, see it moving in the content.
 */
import { useEffect, useRef, useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { useBlockProps, InspectorControls } from '@wordpress/block-editor';
import {
	PanelBody,
	SelectControl,
	Placeholder,
	Spinner,
	ExternalLink,
} from '@wordpress/components';
import apiFetch from '@wordpress/api-fetch';
import { renderBar, decodeText } from '../render';
import { loadGoogleFont } from '../fonts';

const config = window.runlineBlock || {};

function editorSettings( settings ) {
	return {
		...settings,
		items: ( settings.items || [] ).map( ( item ) => ( {
			...item,
			text: decodeText( item.text ),
		} ) ),
	};
}

export default function Edit( { attributes, setAttributes, clientId } ) {
	const { barId } = attributes;
	const [ bars, setBars ] = useState( null );
	const [ failed, setFailed ] = useState( false );
	const host = useRef( null );
	const blockProps = useBlockProps( { className: 'runline-block' } );

	useEffect( () => {
		if ( ! config.canManage ) {
			return;
		}
		apiFetch( { path: '/runline/v1/bars' } )
			.then( setBars )
			.catch( () => setFailed( true ) );
	}, [] );

	const [ sourceItems, setSourceItems ] = useState( null );
	const bar =
		bars &&
		( barId
			? bars.find( ( b ) => b.id === barId )
			: bars.find( ( b ) => b.active ) );
	const source = bar ? bar.settings.source : null;
	const sourceKey = source ? JSON.stringify( source ) : '';
	useEffect( () => {
		if ( ! source || 'manual' === source.type ) {
			setSourceItems( null );
			return;
		}
		apiFetch( {
			path: '/runline/v1/source-items',
			method: 'POST',
			data: { source },
		} )
			.then( ( list ) =>
				setSourceItems(
					list.map( ( item ) => ( {
						...item,
						text: decodeText( item.text ),
					} ) )
				)
			)
			.catch( () => setSourceItems( [] ) );
	}, [ sourceKey ] ); // eslint-disable-line react-hooks/exhaustive-deps

	const html = bar
		? renderBar( editorSettings( bar.settings ), {
				id: 'runline-block-' + clientId,
				fonts: config.fonts,
				maxItems: config.maxItems,
				announcements: __( 'Announcements', 'runline' ),
				close: __( 'Close', 'runline' ),
				tzOffset: config.tzOffset,
				daysFormat: config.daysFormat,
				vars: config.vars,
				shippingAuto: ( config.shipping || {} ).auto,
				shippingFmt: ( config.shipping || {} ).fmt,
				items: sourceItems || undefined,
			} )
		: '';

	useEffect( () => {
		const node = host.current;
		if ( ! node ) {
			return;
		}
		node.querySelectorAll( '.runline' ).forEach(
			( el ) => el.runlineObserver && el.runlineObserver.disconnect()
		);
		node.innerHTML = html;
		if ( bar ) {
			// The canvas of the block editor is an iframe: the font goes into its document.
			loadGoogleFont( bar.settings.font, node.ownerDocument );
		}
		if ( html && window.runlineInit ) {
			window.runlineInit( node );
		}
	}, [ html ] ); // eslint-disable-line react-hooks/exhaustive-deps

	const options = [
		{ value: '0', label: __( 'The bar that is switched on', 'runline' ) },
		...( bars || [] ).map( ( b ) => ( {
			value: String( b.id ),
			label: b.active
				? b.title
				: sprintf(
						/* translators: %s: bar name. */
						__( '%s (off)', 'runline' ),
						b.title
					),
		} ) ),
	];

	const sidebar = (
		<InspectorControls>
			<PanelBody title={ __( 'Bar', 'runline' ) }>
				{ config.canManage ? (
					<>
						<SelectControl
							label={ __( 'Which bar', 'runline' ) }
							value={ String( barId ) }
							options={ options }
							onChange={ ( value ) =>
								setAttributes( {
									barId: parseInt( value, 10 ),
								} )
							}
							__nextHasNoMarginBottom
						/>
						<p>
							{ bar ? (
								<ExternalLink
									href={ config.adminUrl + '&bar=' + bar.id }
								>
									{ __( 'Edit this bar', 'runline' ) }
								</ExternalLink>
							) : (
								<ExternalLink
									href={ config.adminUrl + '&bar=new' }
								>
									{ __( 'Create a bar', 'runline' ) }
								</ExternalLink>
							) }
						</p>
					</>
				) : (
					<p>
						{ __(
							'Only administrators can choose and change bars.',
							'runline'
						) }
					</p>
				) }
			</PanelBody>
		</InspectorControls>
	);

	let message = '';
	if ( ! config.canManage ) {
		message = barId
			? sprintf(
					/* translators: %d: bar ID. */
					__( 'Runline bar #%d', 'runline' ),
					barId
				)
			: __( 'The Runline bar that is switched on', 'runline' );
	} else if ( failed ) {
		message = __( 'The bars could not be loaded.', 'runline' );
	} else if ( bars && ! bar ) {
		message = bars.length
			? __(
					'No bar is switched on. Choose a bar in the block settings or switch one on in Runline.',
					'runline'
				)
			: __( 'You have no bars yet.', 'runline' );
	}

	return (
		<div { ...blockProps }>
			{ sidebar }
			{ config.canManage && ! bars && ! failed && <Spinner /> }
			{ message && (
				<Placeholder
					icon="megaphone"
					label={ __( 'Runline bar', 'runline' ) }
					instructions={ message }
				>
					{ config.canManage && bars && ! bars.length && (
						<ExternalLink href={ config.adminUrl + '&bar=new' }>
							{ __( 'Create a bar', 'runline' ) }
						</ExternalLink>
					) }
				</Placeholder>
			) }
			<div className="runline-block__preview" ref={ host } />
			{ bar && ! bar.active && (
				<p className="runline-block__note">
					{ __(
						'This bar is switched off, so the site does not show it. Switch it on in Runline.',
						'runline'
					) }
				</p>
			) }
		</div>
	);
}
