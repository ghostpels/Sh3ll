/**
 * Stats tab of the editor: views, clicks and click rate of the last 30 days, a bar chart per day for each
 * (two charts, one scale each), and the A/B test result.
 */
import { useEffect, useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { Button, Spinner } from '@wordpress/components';
import apiFetch from '@wordpress/api-fetch';
import { config } from './api';

function rate( clicks, views ) {
	return views ? ( ( 100 * clicks ) / views ).toFixed( 1 ) + '%' : '—';
}

function shortDay( day ) {
	const d = new Date( day + 'T12:00:00' );
	return d.toLocaleDateString( undefined, {
		day: 'numeric',
		month: 'short',
	} );
}

/** One bar per day; the tallest day sets the scale. Hover a bar for its date and number. */
function DayBars( { days, field, label } ) {
	const max = Math.max( 1, ...days.map( ( d ) => d[ field ] ) );
	const width = 600;
	const height = 90;
	const step = width / days.length;
	const bar = Math.max( 2, step - 3 );
	return (
		<figure className="runline-chart">
			<figcaption>
				{ label }
				<span>
					{ sprintf(
						/* translators: %s: highest number of a day. */ __(
							'top day: %s',
							'runline'
						),
						max
					) }
				</span>
			</figcaption>
			<svg
				viewBox={ `0 0 ${ width } ${ height + 18 }` }
				role="img"
				aria-label={ label }
			>
				<line
					x1="0"
					y1={ height }
					x2={ width }
					y2={ height }
					className="runline-chart__base"
				/>
				{ days.map( ( d, i ) => {
					const h = Math.round(
						( d[ field ] / max ) * ( height - 4 )
					);
					return (
						<g key={ d.day } className="runline-chart__day">
							<rect
								x={ i * step }
								y="0"
								width={ step }
								height={ height }
								className="runline-chart__hit"
							>
								<title>
									{ shortDay( d.day ) + ': ' + d[ field ] }
								</title>
							</rect>
							{ h > 0 && (
								<rect
									x={ i * step + 1.5 }
									y={ height - h }
									width={ bar }
									height={ h }
									rx="2"
									className="runline-chart__bar"
								>
									<title>
										{ shortDay( d.day ) +
											': ' +
											d[ field ] }
									</title>
								</rect>
							) }
						</g>
					);
				} ) }
				<text x="0" y={ height + 14 } className="runline-chart__axis">
					{ shortDay( days[ 0 ].day ) }
				</text>
				<text
					x={ width }
					y={ height + 14 }
					textAnchor="end"
					className="runline-chart__axis"
				>
					{ shortDay( days[ days.length - 1 ].day ) }
				</text>
			</svg>
		</figure>
	);
}

export default function StatsTab( { id, settings, notify } ) {
	const [ stats, setStats ] = useState( null );
	const [ failed, setFailed ] = useState( false );
	const load = () =>
		apiFetch( { path: '/runline/v1/stats?bar=' + id } )
			.then( setStats )
			.catch( () => setFailed( true ) );
	useEffect( () => {
		if ( id ) {
			load();
		}
	}, [ id ] ); // eslint-disable-line react-hooks/exhaustive-deps

	if ( ! id ) {
		return (
			<p className="runline-help">
				{ __(
					'Save the bar to start counting its views and clicks.',
					'runline'
				) }
			</p>
		);
	}
	if ( ! config.stats ) {
		return (
			<p className="runline-help">
				{ __(
					'Statistics are switched off in the plugin settings.',
					'runline'
				) }{ ' ' }
				<a href={ config.settingsUrl }>
					{ __( 'Plugin settings', 'runline' ) }
				</a>
			</p>
		);
	}
	if ( failed ) {
		return (
			<p className="runline-warning">
				{ __( 'The statistics could not be loaded.', 'runline' ) }
			</p>
		);
	}
	if ( ! stats ) {
		return <Spinner />;
	}
	const views = stats.days.reduce( ( sum, d ) => sum + d.views, 0 );
	const clicks = stats.days.reduce( ( sum, d ) => sum + d.clicks, 0 );
	const a = stats.variants.a;
	const b = stats.variants.b;
	const abOn = settings.ab && settings.ab.on;
	const rateA = a.views ? a.clicks / a.views : 0;
	const rateB = b.views ? b.clicks / b.views : 0;
	let leader = '';
	if ( abOn && a.views >= 100 && b.views >= 100 && rateA !== rateB ) {
		leader = rateA > rateB ? 'a' : 'b';
	}

	return (
		<>
			<h2>{ __( 'Last 30 days', 'runline' ) }</h2>
			<div className="runline-tiles">
				<div className="runline-tile">
					<span>{ __( 'Views', 'runline' ) }</span>
					<strong>{ views.toLocaleString() }</strong>
				</div>
				<div className="runline-tile">
					<span>{ __( 'Clicks', 'runline' ) }</span>
					<strong>{ clicks.toLocaleString() }</strong>
				</div>
				<div className="runline-tile">
					<span>{ __( 'Click rate', 'runline' ) }</span>
					<strong>{ rate( clicks, views ) }</strong>
				</div>
			</div>
			<DayBars
				days={ stats.days }
				field="views"
				label={ __( 'Views per day', 'runline' ) }
			/>
			<DayBars
				days={ stats.days }
				field="clicks"
				label={ __( 'Clicks per day', 'runline' ) }
			/>
			<p className="runline-help">
				{ __(
					'A view is counted when the bar is shown on a page; a click when a link, the button or the coupon in it is clicked. No cookies and nothing about the visitor are stored.',
					'runline'
				) }
			</p>

			{ abOn && (
				<>
					<h2>{ __( 'A/B test', 'runline' ) }</h2>
					<table className="widefat runline-ab-table">
						<thead>
							<tr>
								<th>{ __( 'Variant', 'runline' ) }</th>
								<th>{ __( 'Views', 'runline' ) }</th>
								<th>{ __( 'Clicks', 'runline' ) }</th>
								<th>{ __( 'Click rate', 'runline' ) }</th>
							</tr>
						</thead>
						<tbody>
							{ [
								[ 'a', 'A', a ],
								[ 'b', 'B', b ],
							].map( ( [ key, name, row ] ) => (
								<tr
									key={ key }
									className={
										leader === key ? 'is-leader' : ''
									}
								>
									<td>
										{ name }
										{ leader === key && (
											<span className="runline-badge">
												{ __( 'better', 'runline' ) }
											</span>
										) }
									</td>
									<td>{ row.views.toLocaleString() }</td>
									<td>{ row.clicks.toLocaleString() }</td>
									<td>{ rate( row.clicks, row.views ) }</td>
								</tr>
							) ) }
						</tbody>
					</table>
					<p className="runline-help">
						{ leader
							? __(
									'Keep the better variant: copy its messages to variant A and switch the test off.',
									'runline'
								)
							: __(
									'Wait for at least 100 views of each variant before choosing.',
									'runline'
								) }
					</p>
				</>
			) }

			<p>
				<Button
					variant="secondary"
					isDestructive
					onClick={ () => {
						if (
							// eslint-disable-next-line no-alert
							window.confirm(
								__(
									'Delete the statistics of this bar?',
									'runline'
								)
							)
						) {
							apiFetch( {
								path: '/runline/v1/stats?bar=' + id,
								method: 'DELETE',
							} ).then( () => {
								notify(
									__( 'Statistics deleted.', 'runline' )
								);
								load();
							} );
						}
					} }
				>
					{ __( 'Reset statistics', 'runline' ) }
				</Button>
			</p>
		</>
	);
}
