/**
 * The list of bars: on/off switch, where the bar shows, shortcode, edit, duplicate, delete.
 */
import { useState, useEffect, useRef } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import {
	Button,
	ToggleControl,
	Modal,
	Notice,
	Spinner,
	Flex,
} from '@wordpress/components';
import apiFetch from '@wordpress/api-fetch';
import { api, config, errorText } from './api';
import { CopyButton } from './controls';
import { plainText } from './render';

function choiceLabel( key, value ) {
	const found = ( config.choices[ key ] || [] ).find(
		( choice ) => choice.value === value
	);
	return found ? found.label : value;
}

export default function BarList( { go, notify } ) {
	const [ bars, setBars ] = useState( null );
	const [ error, setError ] = useState( '' );
	const [ busy, setBusy ] = useState( 0 );
	const [ deleting, setDeleting ] = useState( null );

	const load = () =>
		api
			.list()
			.then( setBars )
			.catch( ( e ) => setError( errorText( e ) ) );

	useEffect( () => {
		load();
	}, [] );

	const fileInput = useRef( null );

	const exportBars = () =>
		apiFetch( { path: '/runline/v1/export' } )
			.then( ( data ) => {
				const blob = new window.Blob(
					[ JSON.stringify( data, null, 2 ) ],
					{
						type: 'application/json',
					}
				);
				const link = document.createElement( 'a' );
				link.href = window.URL.createObjectURL( blob );
				link.download =
					'runline-bars-' +
					new Date().toISOString().slice( 0, 10 ) +
					'.json';
				document.body.appendChild( link );
				link.click();
				link.remove();
			} )
			.catch( ( e ) => notify( errorText( e ) ) );

	const importBars = ( event ) => {
		const file = event.target.files && event.target.files[ 0 ];
		event.target.value = '';
		if ( ! file ) {
			return;
		}
		file.text()
			.then( ( text ) => {
				const data = JSON.parse( text );
				if (
					! data ||
					'runline' !== data.plugin ||
					! Array.isArray( data.bars )
				) {
					throw new Error(
						__( 'This is not a Runline export file.', 'runline' )
					);
				}
				return apiFetch( {
					path: '/runline/v1/import',
					method: 'POST',
					data: { bars: data.bars },
				} );
			} )
			.then( ( res ) => {
				notify(
					sprintf(
						/* translators: %d: number of bars. */
						__(
							'Imported bars: %d. They are switched off.',
							'runline'
						),
						res.added
					)
				);
				return load();
			} )
			.catch( ( e ) => notify( errorText( e ) ) );
	};

	const toggle = ( bar ) => {
		setBusy( bar.id );
		api.setActive( bar.id, ! bar.active )
			.then( () => load() )
			.catch( ( e ) => notify( errorText( e ) ) )
			.finally( () => setBusy( 0 ) );
	};

	const duplicate = ( bar ) => {
		setBusy( bar.id );
		api.duplicate( bar.id )
			.then( ( copy ) => {
				notify(
					sprintf(
						/* translators: %s: bar name. */ __(
							'“%s” created. It is switched off.',
							'runline'
						),
						copy.title
					)
				);
				return load();
			} )
			.catch( ( e ) => notify( errorText( e ) ) )
			.finally( () => setBusy( 0 ) );
	};

	const remove = () => {
		const bar = deleting;
		setDeleting( null );
		setBusy( bar.id );
		api.remove( bar.id )
			.then( () => {
				notify(
					sprintf(
						/* translators: %s: bar name. */ __(
							'“%s” deleted.',
							'runline'
						),
						bar.title
					)
				);
				return load();
			} )
			.catch( ( e ) => notify( errorText( e ) ) )
			.finally( () => setBusy( 0 ) );
	};

	return (
		<div className="runline-list">
			<div className="runline-head">
				<h1 className="wp-heading-inline">
					{ __( 'Runline', 'runline' ) }
				</h1>
				<Button
					variant="primary"
					icon="plus-alt2"
					onClick={ () => go( 'new' ) }
				>
					{ __( 'Add bar', 'runline' ) }
				</Button>
				<Button
					variant="secondary"
					icon="download"
					onClick={ exportBars }
				>
					{ __( 'Export', 'runline' ) }
				</Button>
				<Button
					variant="secondary"
					icon="upload"
					onClick={ () =>
						fileInput.current && fileInput.current.click()
					}
				>
					{ __( 'Import', 'runline' ) }
				</Button>
				<input
					ref={ fileInput }
					type="file"
					accept="application/json,.json"
					hidden
					onChange={ importBars }
				/>
			</div>
			<p className="runline-intro">
				{ __(
					'Your scrolling bars. Switch on as many as you like: each shows where its display rules say.',
					'runline'
				) }
			</p>

			{ error && (
				<Notice status="error" isDismissible={ false }>
					{ error }
				</Notice>
			) }
			{ ! bars && ! error && <Spinner /> }

			{ bars && ! bars.length && (
				<div className="runline-empty">
					<div className="runline-empty__bar" aria-hidden="true">
						<span>
							🎉{ ' ' }
							{ __( 'Your first announcement here', 'runline' ) }
						</span>
						<span>•</span>
						<span>🚚 { __( 'Free shipping', 'runline' ) }</span>
					</div>
					<h2>{ __( 'No bars yet', 'runline' ) }</h2>
					<p>
						{ __(
							'Create a bar, write your messages and watch the preview. It takes two minutes.',
							'runline'
						) }
					</p>
					<Button variant="primary" onClick={ () => go( 'new' ) }>
						{ __( 'Create your first bar', 'runline' ) }
					</Button>
				</div>
			) }

			{ bars && bars.length > 0 && (
				<table className="wp-list-table widefat fixed striped runline-table">
					<thead>
						<tr>
							<th className="column-primary">
								{ __( 'Name', 'runline' ) }
							</th>
							<th className="runline-col-status">
								{ __( 'On the site', 'runline' ) }
							</th>
							<th className="runline-col-where">
								{ __( 'Where', 'runline' ) }
							</th>
							<th className="runline-col-code">
								{ __( 'Shortcode', 'runline' ) }
							</th>
							<th className="runline-col-stats">
								{ __( '30 days', 'runline' ) }
							</th>
							<th className="runline-col-actions">
								<span className="screen-reader-text">
									{ __( 'Actions', 'runline' ) }
								</span>
							</th>
						</tr>
					</thead>
					<tbody>
						{ bars.map( ( bar ) => (
							<tr
								key={ bar.id }
								className={ busy === bar.id ? 'is-busy' : '' }
							>
								<td className="column-primary">
									<Flex justify="flex-start" gap={ 3 }>
										<span
											className="runline-swatch"
											style={ {
												background: bar.settings.bg,
												color: bar.settings.color,
											} }
											aria-hidden="true"
										>
											Aa
										</span>
										<span>
											<a
												className="row-title"
												href={
													config.adminUrl +
													'&bar=' +
													bar.id
												}
												onClick={ ( event ) => {
													event.preventDefault();
													go( bar.id );
												} }
											>
												{ bar.title ||
													__(
														'(no name)',
														'runline'
													) }
											</a>
											<span className="runline-first-item">
												{ plainText(
													(
														bar.settings
															.items[ 0 ] || {}
													).text || ''
												) }
											</span>
										</span>
									</Flex>
								</td>
								<td className="runline-col-status">
									<ToggleControl
										className="runline-status"
										label={
											bar.active
												? __( 'On', 'runline' )
												: __( 'Off', 'runline' )
										}
										checked={ bar.active }
										disabled={ busy === bar.id }
										onChange={ () => toggle( bar ) }
										__nextHasNoMarginBottom
									/>
								</td>
								<td>
									{ choiceLabel(
										'position',
										bar.settings.position
									) }
									<span className="runline-muted">
										{ bar.summary }
									</span>
								</td>
								<td className="runline-col-code">
									<code>{ bar.shortcode }</code>{ ' ' }
									<CopyButton
										text={ bar.shortcode }
										notify={ notify }
									/>
								</td>
								<td className="runline-col-stats">
									{ bar.stats && bar.stats.views ? (
										<>
											{ sprintf(
												/* translators: 1: views, 2: clicks. */
												__(
													'%1$s views · %2$s clicks',
													'runline'
												),
												bar.stats.views.toLocaleString(),
												bar.stats.clicks.toLocaleString()
											) }
											<span className="runline-muted">
												{ sprintf(
													/* translators: %s: click rate, e.g. 2.4%. */
													__(
														'Click rate %s',
														'runline'
													),
													(
														( 100 *
															bar.stats.clicks ) /
														bar.stats.views
													).toFixed( 1 ) + '%'
												) }
											</span>
										</>
									) : (
										<span className="runline-muted">—</span>
									) }
								</td>
								<td className="runline-col-actions">
									<Button
										size="small"
										variant="secondary"
										onClick={ () => go( bar.id ) }
									>
										{ __( 'Edit', 'runline' ) }
									</Button>
									<Button
										size="small"
										icon="admin-page"
										label={ __( 'Duplicate', 'runline' ) }
										onClick={ () => duplicate( bar ) }
										disabled={ busy === bar.id }
									/>
									<Button
										size="small"
										icon="trash"
										label={ __( 'Delete', 'runline' ) }
										isDestructive
										onClick={ () => setDeleting( bar ) }
										disabled={ busy === bar.id }
									/>
								</td>
							</tr>
						) ) }
					</tbody>
				</table>
			) }

			{ deleting && (
				<Modal
					title={ __( 'Delete this bar?', 'runline' ) }
					onRequestClose={ () => setDeleting( null ) }
					size="small"
				>
					<p>
						{ sprintf(
							/* translators: %s: bar name. */
							__(
								'“%s” will be deleted for good. This cannot be undone.',
								'runline'
							),
							deleting.title
						) }
					</p>
					<Flex justify="flex-end">
						<Button
							variant="tertiary"
							onClick={ () => setDeleting( null ) }
						>
							{ __( 'Cancel', 'runline' ) }
						</Button>
						<Button
							variant="primary"
							isDestructive
							onClick={ remove }
						>
							{ __( 'Delete', 'runline' ) }
						</Button>
					</Flex>
				</Modal>
			) }

			<p className="runline-foot">
				<a href={ config.settingsUrl }>
					{ __( 'Settings', 'runline' ) }
				</a>
			</p>
		</div>
	);
}
