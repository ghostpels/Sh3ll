/**
 * The bar editor: name, on/off, save without reload (also Ctrl+S / Cmd+S), live preview on top,
 * settings in four tabs on the left: Content, Motion, Appearance, Display.
 */
import { useState, useEffect, useRef, useCallback } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import {
	Button,
	CheckboxControl,
	Modal,
	Notice,
	RangeControl,
	SelectControl,
	Spinner,
	TextControl,
	ToggleControl,
	Tooltip,
} from '@wordpress/components';
import { api, config, errorText, fromServer, toServer } from './api';
import {
	ColorField,
	CopyButton,
	ItemsEditor,
	Segmented,
	SeparatorField,
} from './controls';
import { RulesEditor, ScheduleEditor, Picker, DaysField } from './rules';
import apiFetch from '@wordpress/api-fetch';
import { decodeText } from './render';
import Preview from './preview';
import StatsTab from './stats';
import { loadGoogleFont } from './fonts';
import Gallery, { designById } from './gallery';

const TABS = [
	{
		name: 'content',
		title: __( 'Content', 'runline' ),
		icon: 'editor-alignleft',
	},
	{
		name: 'motion',
		title: __( 'Motion', 'runline' ),
		icon: 'controls-forward',
	},
	{ name: 'look', title: __( 'Appearance', 'runline' ), icon: 'art' },
	{ name: 'display', title: __( 'Display', 'runline' ), icon: 'visibility' },
	{ name: 'offers', title: __( 'Offers', 'runline' ), icon: 'tag' },
	{ name: 'stats', title: __( 'Stats', 'runline' ), icon: 'chart-bar' },
];
const TAB_KEY = 'runline-editor-tab';

function snapshot( title, settings ) {
	return JSON.stringify( { title, settings: toServer( settings ) } );
}

/**
 * The saved settings from the server, keeping the item keys the editor already has (focus stays put).
 */
function keepKeys( fresh, current ) {
	if ( fresh.items.length !== current.items.length ) {
		return fresh;
	}
	return {
		...fresh,
		items: fresh.items.map( ( item, i ) => ( {
			...item,
			_key: current.items[ i ]._key,
		} ) ),
	};
}

/** Settings of a new bar: a design from the gallery, or the defaults ("blank"). */
function startSettings( designId ) {
	const design = designById( designId );
	return fromServer( design ? design.settings : config.defaults );
}

/** The look of a design on the current settings: texts, place and pages stay. */
function applyLook( settings, design ) {
	const look = {};
	( config.lookKeys || [] ).forEach( ( key ) => {
		look[ key ] = design.settings[ key ];
	} );
	return { ...settings, ...look };
}

function readTab() {
	try {
		const tab = window.localStorage.getItem( TAB_KEY );
		return TABS.some( ( t ) => t.name === tab ) ? tab : 'content';
	} catch {
		return 'content';
	}
}

export default function Editor( { barId, designId, go, notify, setGuard } ) {
	const isNew = 'new' === barId;
	const [ id, setId ] = useState( isNew ? 0 : parseInt( barId, 10 ) );
	const [ title, setTitle ] = useState( () =>
		isNew && designById( designId ) ? designById( designId ).name : ''
	);
	const [ settings, setSettings ] = useState( () =>
		isNew ? startSettings( designId ) : null
	);
	const [ active, setActive ] = useState( false );
	// A new bar counts as unchanged until the first edit (no question when leaving it untouched).
	const [ saved, setSaved ] = useState( () =>
		isNew ? snapshot( title, settings ) : ''
	);
	const [ choosing, setChoosing ] = useState( false );
	const [ saving, setSaving ] = useState( false );
	const [ error, setError ] = useState( '' );
	const [ tab, setTab ] = useState( readTab );
	const idRef = useRef( id );

	// Load the bar (not again after "new" became a saved bar).
	useEffect( () => {
		if (
			isNew ||
			( String( barId ) === String( idRef.current ) && settings )
		) {
			return;
		}
		api.get( barId )
			.then( ( bar ) => {
				idRef.current = bar.id;
				setId( bar.id );
				setTitle( bar.title );
				setSettings( bar.settings );
				setActive( bar.active );
				setSaved( snapshot( bar.title, bar.settings ) );
			} )
			.catch( ( e ) => setError( errorText( e ) ) );
	}, [ barId ] ); // eslint-disable-line react-hooks/exhaustive-deps

	const dirty = !! settings && snapshot( title, settings ) !== saved;
	const set = ( changes ) =>
		setSettings( ( current ) => ( { ...current, ...changes } ) );
	const [ previewB, setPreviewB ] = useState( false );
	const baseExtra = usePreviewExtra( settings );
	const extra =
		previewB && settings && settings.ab.on && settings.ab.items.length
			? { ...baseExtra, items: settings.ab.items }
			: baseExtra;
	useGoogleFont( settings ? settings.font : '' );

	// Unsaved changes: ask before leaving the page or going back to the list.
	useEffect( () => {
		const ask = __(
			'You have unsaved changes. Leave without saving?',
			'runline'
		);
		setGuard( () => ( dirty ? () => window.confirm( ask ) : null ) ); // eslint-disable-line no-alert
		const onLeave = ( event ) => {
			if ( dirty ) {
				event.preventDefault();
				event.returnValue = '';
			}
		};
		window.addEventListener( 'beforeunload', onLeave );
		return () => window.removeEventListener( 'beforeunload', onLeave );
	}, [ dirty, setGuard ] );
	useEffect( () => () => setGuard( null ), [ setGuard ] );

	const save = useCallback( () => {
		if ( saving || ! settings ) {
			return;
		}
		setSaving( true );
		const sentTitle = title;
		const sent = snapshot( title, settings );
		const request = idRef.current
			? api.save( idRef.current, title, toServer( settings ) )
			: api.create( title, toServer( settings ) );
		request
			.then( ( res ) => {
				const bar = res.bar;
				setSaved( snapshot( bar.title, bar.settings ) );
				setActive( bar.active );
				// Take what the server kept (cleaned texts, dropped empty items) unless something changed meanwhile.
				setSettings( ( current ) =>
					snapshot( sentTitle, current ) === sent
						? keepKeys( bar.settings, current )
						: current
				);
				setTitle( ( current ) =>
					current === sentTitle ? bar.title : current
				);
				notify( __( 'Saved.', 'runline' ) );
				if ( ! idRef.current ) {
					idRef.current = bar.id;
					setId( bar.id );
					go( bar.id, true, true );
				}
			} )
			.catch( ( e ) =>
				notify(
					sprintf(
						/* translators: %s: error message. */ __(
							'Not saved: %s',
							'runline'
						),
						errorText( e )
					)
				)
			)
			.finally( () => setSaving( false ) );
	}, [ saving, settings, title, notify, go ] );

	useEffect( () => {
		const onKey = ( event ) => {
			if (
				( event.ctrlKey || event.metaKey ) &&
				's' === event.key.toLowerCase()
			) {
				event.preventDefault();
				save();
			}
		};
		window.addEventListener( 'keydown', onKey );
		return () => window.removeEventListener( 'keydown', onKey );
	}, [ save ] );

	const openTab = ( name ) => {
		setTab( name );
		try {
			window.localStorage.setItem( TAB_KEY, name );
		} catch {}
	};

	if ( error ) {
		return (
			<div className="runline-editor">
				<Notice status="error" isDismissible={ false }>
					{ error }
				</Notice>
				<Button variant="link" onClick={ () => go( '' ) }>
					← { __( 'All bars', 'runline' ) }
				</Button>
			</div>
		);
	}
	if ( ! settings ) {
		return <Spinner />;
	}

	let viewHelp = '';
	if ( 'manual' === settings.position ) {
		viewHelp = __(
			'This bar shows only where you put its shortcode.',
			'runline'
		);
	} else if ( ! active || dirty ) {
		viewHelp = __(
			'Switch the bar on and save to see it on the site.',
			'runline'
		);
	}

	return (
		<div className="runline-editor">
			<div className="runline-editor__bar">
				<Button
					variant="tertiary"
					icon="arrow-left-alt2"
					className="runline-editor__back"
					href={ config.adminUrl }
					onClick={ ( event ) => {
						event.preventDefault();
						go( '' );
					} }
				>
					{ __( 'All bars', 'runline' ) }
				</Button>
				<TextControl
					className="runline-editor__title"
					value={ title }
					onChange={ setTitle }
					placeholder={ __(
						'Bar name, e.g. Black Friday',
						'runline'
					) }
					aria-label={ __( 'Bar name', 'runline' ) }
					__nextHasNoMarginBottom
				/>
				<ToggleControl
					className="runline-editor__on"
					label={ __( 'On the site', 'runline' ) }
					checked={ settings.enabled }
					onChange={ ( enabled ) => set( { enabled } ) }
					__nextHasNoMarginBottom
				/>
				<Button
					variant="secondary"
					icon="art"
					onClick={ () => setChoosing( true ) }
				>
					{ __( 'Change design', 'runline' ) }
				</Button>
				{ viewHelp ? (
					<Tooltip text={ viewHelp }>
						<span>
							<Button
								variant="secondary"
								icon="external"
								disabled
								accessibleWhenDisabled
							>
								{ __( 'View on site', 'runline' ) }
							</Button>
						</span>
					</Tooltip>
				) : (
					<Button
						variant="secondary"
						icon="external"
						href={ config.homeUrl }
						target="_blank"
					>
						{ __( 'View on site', 'runline' ) }
					</Button>
				) }
				<Button
					variant="primary"
					className="runline-editor__save"
					onClick={ save }
					isBusy={ saving }
					disabled={ saving || ( !! id && ! dirty ) }
				>
					{ ! id || dirty
						? __( 'Save', 'runline' )
						: __( 'Saved', 'runline' ) }
				</Button>
			</div>

			{ choosing && (
				<Modal
					title={ __( 'Change design', 'runline' ) }
					onRequestClose={ () => setChoosing( false ) }
					size="large"
					className="runline-design-modal"
				>
					<p className="runline-help">
						{ __(
							'Takes the colours, font, size and motion of the design. Your messages, label text, place and pages stay as they are.',
							'runline'
						) }
					</p>
					<Gallery
						mode="apply"
						onPick={ ( design ) => {
							setSettings( ( current ) =>
								applyLook( current, design )
							);
							setChoosing( false );
							notify(
								sprintf(
									/* translators: %s: design name. */
									__(
										'Design “%s” applied. Save to keep it.',
										'runline'
									),
									design.name
								)
							);
						} }
					/>
				</Modal>
			) }

			<Preview settings={ settings } extra={ extra } />

			<div className="runline-settings">
				<div
					className="runline-tabs"
					role="tablist"
					aria-orientation="vertical"
				>
					{ TABS.map( ( t ) => (
						<Button
							key={ t.name }
							role="tab"
							id={ 'runline-tab-' + t.name }
							aria-selected={ tab === t.name }
							aria-controls={ 'runline-panel-' + t.name }
							className={
								'runline-tab' +
								( tab === t.name ? ' is-active' : '' )
							}
							icon={ t.icon }
							onClick={ () => openTab( t.name ) }
						>
							{ t.title }
						</Button>
					) ) }
				</div>
				<div
					className="runline-panel"
					role="tabpanel"
					id={ 'runline-panel-' + tab }
					aria-labelledby={ 'runline-tab-' + tab }
				>
					{ 'content' === tab && (
						<ContentTab
							settings={ settings }
							set={ set }
							previewB={ previewB }
							setPreviewB={ setPreviewB }
						/>
					) }
					{ 'motion' === tab && (
						<MotionTab settings={ settings } set={ set } />
					) }
					{ 'look' === tab && (
						<LookTab settings={ settings } set={ set } />
					) }
					{ 'stats' === tab && (
						<StatsTab
							id={ id }
							settings={ settings }
							notify={ notify }
						/>
					) }
					{ 'offers' === tab && (
						<OffersTab settings={ settings } set={ set } />
					) }
					{ 'display' === tab && (
						<DisplayTab
							settings={ settings }
							set={ set }
							id={ id }
							notify={ notify }
						/>
					) }
				</div>
			</div>
		</div>
	);
}

function ContentTab( { settings, set, previewB, setPreviewB } ) {
	const manual = 'manual' === settings.source.type || !! settings.source.mix;
	return (
		<>
			<h2>{ __( 'Messages', 'runline' ) }</h2>
			<SourceSection settings={ settings } set={ set } />
			{ manual && (
				<>
					<p className="runline-help">
						{ __(
							'They run one after another in a loop. Simple formatting works in the text: <strong>bold</strong>, <em>italic</em>. Variables: {date}, {site_name}, {coupon}, {countdown}, {free_shipping_left}, {cart_total}, {cart_count}, {visitor_country}, {open_now}, {delivery_date}, {pickup_date}, {places_left}. The calendar button gives a message its own dates.',
							'runline'
						) }
					</p>
					<ItemsEditor
						items={ settings.items }
						onChange={ ( items ) => set( { items } ) }
						max={ config.maxItems }
					/>
				</>
			) }
			{ 'manual' === settings.source.type && (
				<AbSection
					settings={ settings }
					set={ set }
					previewB={ previewB }
					setPreviewB={ setPreviewB }
				/>
			) }
			<div className="runline-grid">
				<SeparatorField
					value={ settings.separator }
					onChange={ ( separator ) => set( { separator } ) }
				/>
			</div>
			{ usesVar( settings, '{open_now}' ) && (
				<HoursSection settings={ settings } set={ set } />
			) }
			<DayslotNeeded settings={ settings } />
			<h2>{ __( 'Fixed label', 'runline' ) }</h2>
			<div className="runline-grid">
				<TextControl
					label={ __( 'Label on the left', 'runline' ) }
					help={ __(
						'Stays in place while the text moves, e.g. NEW or SALE. Empty = no label.',
						'runline'
					) }
					value={ settings.label }
					onChange={ ( label ) => set( { label } ) }
					maxLength={ 40 }
					__nextHasNoMarginBottom
				/>
				{ '' !== settings.label.trim() && (
					<>
						<ColorField
							label={ __( 'Label background', 'runline' ) }
							value={ settings.label_bg }
							onChange={ ( v ) => set( { label_bg: v } ) }
						/>
						<ColorField
							label={ __( 'Label text', 'runline' ) }
							value={ settings.label_color }
							onChange={ ( v ) => set( { label_color: v } ) }
						/>
					</>
				) }
			</div>
		</>
	);
}

/** Whether a message (or its A/B variant) uses a text variable. */
function usesVar( settings, name ) {
	return [ ...settings.items, ...( settings.ab.items || [] ) ].some(
		( item ) => ( item.text || '' ).includes( name )
	);
}

// Whether the bar uses something that comes from Dayslot (variables, the timer, the rules about days off).
function usesDayslot( settings ) {
	const rules = settings.rules || {};
	return (
		[ '{delivery_date}', '{pickup_date}', '{places_left}' ].some(
			( name ) => usesVar( settings, name )
		) ||
		( settings.countdown.on && 'dayslot' === settings.countdown.source ) ||
		[ ...( rules.show || [] ), ...( rules.hide || [] ) ].some( ( rule ) =>
			( rule.type || '' ).startsWith( 'ds_off_' )
		)
	);
}

// Without Dayslot: what these parts need, once, where they are set. No ad: only when the bar uses them.
function DayslotNeeded( { settings } ) {
	if ( config.dayslotOn || ! usesDayslot( settings ) ) {
		return null;
	}
	return (
		<p className="runline-hint">
			{ __(
				'The delivery date, pickup date, places left, the timer until the next delivery date and the rules about days without delivery come from Dayslot, our free plugin for WooCommerce delivery dates. Without it, these messages are not shown on the site.',
				'runline'
			) }{ ' ' }
			<a
				href={ config.dayslotUrl }
				target="_blank"
				rel="noopener noreferrer"
			>
				{ __( 'Dayslot on WordPress.org', 'runline' ) }
			</a>
		</p>
	);
}

function HoursSection( { settings, set } ) {
	const hours = settings.hours;
	const setHours = ( changes ) => set( { hours: { ...hours, ...changes } } );
	return (
		<>
			<h2>{ __( 'Opening hours for {open_now}', 'runline' ) }</h2>
			<DaysField
				label={ __( 'Open on', 'runline' ) }
				value={ hours.days }
				onChange={ ( days ) => setHours( { days } ) }
			/>
			<div className="runline-grid">
				<TextControl
					type="time"
					label={ __( 'From', 'runline' ) }
					value={ hours.from }
					onChange={ ( from ) => setHours( { from } ) }
					__nextHasNoMarginBottom
				/>
				<TextControl
					type="time"
					label={ __( 'To', 'runline' ) }
					value={ hours.to }
					onChange={ ( to ) => setHours( { to } ) }
					__nextHasNoMarginBottom
				/>
				<TextControl
					label={ __( 'Text when open', 'runline' ) }
					value={ hours.open }
					onChange={ ( open ) => setHours( { open } ) }
					maxLength={ 60 }
					__nextHasNoMarginBottom
				/>
				<TextControl
					label={ __( 'Text when closed', 'runline' ) }
					value={ hours.closed }
					onChange={ ( closed ) => setHours( { closed } ) }
					maxLength={ 60 }
					__nextHasNoMarginBottom
				/>
			</div>
			<p className="runline-help">
				{ sprintf(
					/* translators: %s: time zone of the site. */
					__(
						'No day ticked = every day. Time zone of the site: %s',
						'runline'
					),
					config.timezone
				) }
			</p>
		</>
	);
}

function CountdownSection( { settings, set } ) {
	const cd = settings.countdown;
	const setCd = ( changes ) => set( { countdown: { ...cd, ...changes } } );
	return (
		<>
			<h2>{ __( 'Countdown timer', 'runline' ) }</h2>
			<ToggleControl
				label={ __(
					'Count down to a date (sales, offers, events)',
					'runline'
				) }
				checked={ cd.on }
				onChange={ ( on ) => setCd( { on } ) }
				__nextHasNoMarginBottom
			/>
			{ cd.on && (
				<>
					<div className="runline-grid">
						<SelectControl
							label={ __( 'Count down to', 'runline' ) }
							value={ cd.source }
							options={ config.choices.cd_source.filter(
								( o ) =>
									config.woo ||
									! [
										'product',
										'current_product',
										'dayslot',
									].includes( o.value )
							) }
							onChange={ ( source ) => setCd( { source } ) }
							__nextHasNoMarginBottom
						/>
						{ 'daily' === cd.source && (
							<TextControl
								type="time"
								label={ __( 'Every day until', 'runline' ) }
								help={ sprintf(
									/* translators: %s: time zone of the site. */
									__(
										'Time zone of the site: %s',
										'runline'
									),
									config.timezone
								) }
								value={ cd.daily }
								onChange={ ( daily ) => setCd( { daily } ) }
								__nextHasNoMarginBottom
							/>
						) }
						{ 'visitor' === cd.source && (
							<RangeControl
								label={ __(
									'Minutes for each visitor',
									'runline'
								) }
								help={ __(
									'Starts when a visitor sees the bar for the first time and runs out for them alone.',
									'runline'
								) }
								value={ cd.minutes }
								onChange={ ( v ) =>
									setCd( { minutes: v || 15 } )
								}
								min={ 1 }
								max={ 1440 }
								__nextHasNoMarginBottom
							/>
						) }
						{ 'product' === cd.source && (
							<BaseControlPicker
								label={ __( 'Product', 'runline' ) }
								value={ cd.product ? [ cd.product ] : [] }
								onChange={ ( ids ) =>
									setCd( {
										product: ids.length
											? ids[ ids.length - 1 ]
											: 0,
									} )
								}
							/>
						) }
						{ 'date' === cd.source && (
							<TextControl
								type="datetime-local"
								label={ __( 'Ends at', 'runline' ) }
								help={ sprintf(
									/* translators: %s: time zone of the site. */
									__(
										'Time zone of the site: %s',
										'runline'
									),
									config.timezone
								) }
								value={ cd.end }
								onChange={ ( end ) => setCd( { end } ) }
								__nextHasNoMarginBottom
							/>
						) }
						<SelectControl
							label={ __( 'Where the timer is', 'runline' ) }
							value={ cd.place }
							options={ config.choices.cd_place }
							onChange={ ( place ) => setCd( { place } ) }
							__nextHasNoMarginBottom
						/>
						{ 'text' !== cd.place && (
							<TextControl
								label={ __(
									'Text before the timer',
									'runline'
								) }
								value={ cd.prefix }
								onChange={ ( prefix ) => setCd( { prefix } ) }
								maxLength={ 60 }
								__nextHasNoMarginBottom
							/>
						) }
						{ 'daily' !== cd.source && (
							<SelectControl
								label={ __(
									'When the time is over',
									'runline'
								) }
								value={ cd.after }
								options={ config.choices.cd_after }
								onChange={ ( after ) => setCd( { after } ) }
								__nextHasNoMarginBottom
							/>
						) }
						{ 'text' === cd.after && 'daily' !== cd.source && (
							<TextControl
								label={ __( 'Text after the end', 'runline' ) }
								value={ cd.after_text }
								onChange={ ( v ) => setCd( { after_text: v } ) }
								maxLength={ 120 }
								__nextHasNoMarginBottom
							/>
						) }
					</div>
					{ 'dayslot' === cd.source && (
						<DayslotNeeded settings={ settings } />
					) }
					{ 'daily' === cd.source && (
						<DaysField
							label={ __(
								'On these days (none ticked = every day)',
								'runline'
							) }
							value={ cd.daily_days }
							onChange={ ( v ) => setCd( { daily_days: v } ) }
						/>
					) }
					{ 'text' !== cd.place && (
						<div className="runline-grid runline-grid--colors">
							<ColorField
								label={ __( 'Timer background', 'runline' ) }
								value={ cd.bg }
								onChange={ ( bg ) => setCd( { bg } ) }
							/>
							<ColorField
								label={ __( 'Timer text', 'runline' ) }
								value={ cd.color }
								onChange={ ( color ) => setCd( { color } ) }
							/>
						</div>
					) }
					<p className="runline-help">
						{ __(
							'Write {countdown} in any message to show the timer right inside the moving text, e.g. "Sale ends in {countdown}".',
							'runline'
						) }
					</p>
					{ 'current_product' === cd.source && (
						<p className="runline-help">
							{ __(
								"On product pages the timer counts down to the end of that product's sale (set in the product: Sale price → Schedule). Products without a sale end show no timer.",
								'runline'
							) }
						</p>
					) }
					{ 'date' === cd.source && ! cd.end && (
						<p className="runline-warning">
							{ __(
								'Choose the end date: without it there is no timer.',
								'runline'
							) }
						</p>
					) }
				</>
			) }
		</>
	);
}

function MotionTab( { settings, set } ) {
	const oneByOne = [ 'fade', 'slide', 'typewriter' ].includes(
		settings.mode
	);
	return (
		<>
			<div className="runline-grid">
				<SelectControl
					label={ __( 'Mode', 'runline' ) }
					value={ settings.mode }
					options={ config.choices.mode }
					onChange={ ( mode ) => set( { mode } ) }
					__nextHasNoMarginBottom
				/>
				{ oneByOne && (
					<RangeControl
						label={ __( 'Seconds per message', 'runline' ) }
						value={ settings.interval }
						onChange={ ( v ) => set( { interval: v || 4 } ) }
						min={ 2 }
						max={ 20 }
						__nextHasNoMarginBottom
					/>
				) }
			</div>
			{ 'vertical' === settings.mode && (
				<p className="runline-help">
					{ __(
						'The vertical ticker moves up at a third of the speed below, so every line can be read.',
						'runline'
					) }
				</p>
			) }
			<div className="runline-grid">
				<Segmented
					label={ __( 'Direction', 'runline' ) }
					value={ settings.direction }
					onChange={ ( direction ) => set( { direction } ) }
					options={ [
						{
							value: 'left',
							label: __( 'To the left', 'runline' ),
							icon: 'arrow-left-alt',
						},
						{
							value: 'right',
							label: __( 'To the right', 'runline' ),
							icon: 'arrow-right-alt',
						},
					] }
				/>
			</div>
			<div className="runline-grid">
				<RangeControl
					label={ __( 'Speed on computers and tablets', 'runline' ) }
					help={ __(
						'Pixels per second. 40–80 is easy to read.',
						'runline'
					) }
					value={ settings.speed }
					onChange={ ( speed ) => set( { speed: speed || 60 } ) }
					min={ 10 }
					max={ 400 }
					__nextHasNoMarginBottom
				/>
				<RangeControl
					label={ __( 'Speed on phones', 'runline' ) }
					help={ __(
						'Phones are narrow: a little slower reads better.',
						'runline'
					) }
					value={ settings.speed_mobile }
					onChange={ ( speed ) =>
						set( { speed_mobile: speed || 45 } )
					}
					min={ 10 }
					max={ 400 }
					__nextHasNoMarginBottom
				/>
			</div>
			<ToggleControl
				label={ __( 'Stop when the mouse is over the bar', 'runline' ) }
				checked={ settings.pause_hover }
				onChange={ ( pause_hover ) => set( { pause_hover } ) } // eslint-disable-line camelcase
				__nextHasNoMarginBottom
			/>
			<p className="runline-help">
				{ __(
					'The speed is the same for short and long texts. On phones a tap on the bar stops it. Visitors who switched on "reduce motion" in their system see one message at a time instead.',
					'runline'
				) }
			</p>
		</>
	);
}

function LookTab( { settings, set } ) {
	const images =
		'manual' === settings.source.type
			? settings.items.some( ( item ) => item.image )
			: settings.source.images;
	return (
		<>
			<h2>{ __( 'Style', 'runline' ) }</h2>
			<div className="runline-grid">
				<SelectControl
					label={ __( 'Messages look like', 'runline' ) }
					value={ settings.style }
					options={ config.choices.style }
					onChange={ ( style ) => set( { style } ) }
					help={
						'cards' === settings.style
							? __(
									'Cards need a taller bar: try 90–140 px in Size below.',
									'runline'
								)
							: ''
					}
					__nextHasNoMarginBottom
				/>
				{ images && (
					<RangeControl
						label={ __(
							'Image size (% of the bar height)',
							'runline'
						) }
						value={ settings.image_height }
						onChange={ ( v ) => set( { image_height: v || 70 } ) }
						min={ 20 }
						max={ 100 }
						__nextHasNoMarginBottom
					/>
				) }
			</div>
			<h2>{ __( 'Colours', 'runline' ) }</h2>
			<div className="runline-grid runline-grid--colors">
				<ColorField
					label={ __( 'Background', 'runline' ) }
					value={ settings.bg }
					onChange={ ( bg ) => set( { bg } ) }
				/>
				<ColorField
					label={ __( 'Text', 'runline' ) }
					value={ settings.color }
					onChange={ ( color ) => set( { color } ) }
				/>
				<ColorField
					label={ __( 'Links', 'runline' ) }
					value={ settings.link_color }
					onChange={ ( v ) => set( { link_color: v } ) }
					allowEmpty
					emptyLabel={ __( 'Like the text', 'runline' ) }
				/>
				<ColorField
					label={ __( 'Links under the mouse', 'runline' ) }
					value={ settings.link_hover }
					onChange={ ( v ) => set( { link_hover: v } ) }
					allowEmpty
					emptyLabel={ __( 'Like the links', 'runline' ) }
				/>
			</div>
			<div className="runline-grid">
				<ColorField
					label={ __( 'Gradient to', 'runline' ) }
					value={ settings.bg2 }
					onChange={ ( v ) => set( { bg2: v } ) }
					allowEmpty
					emptyLabel={ __( 'No gradient', 'runline' ) }
				/>
				{ settings.bg2 && (
					<RangeControl
						label={ __(
							'Gradient direction (degrees)',
							'runline'
						) }
						value={ settings.bg_angle }
						onChange={ ( v ) => set( { bg_angle: v ?? 90 } ) }
						min={ 0 }
						max={ 360 }
						__nextHasNoMarginBottom
					/>
				) }
				<RangeControl
					label={ __( 'Border (px)', 'runline' ) }
					value={ settings.border_width }
					onChange={ ( v ) => set( { border_width: v || 0 } ) }
					min={ 0 }
					max={ 10 }
					__nextHasNoMarginBottom
				/>
				{ settings.border_width > 0 && (
					<ColorField
						label={ __( 'Border colour', 'runline' ) }
						value={ settings.border_color }
						onChange={ ( v ) => set( { border_color: v } ) }
					/>
				) }
				<SelectControl
					label={ __( 'Shadow', 'runline' ) }
					value={ settings.shadow }
					options={ config.choices.shadow }
					onChange={ ( shadow ) => set( { shadow } ) }
					__nextHasNoMarginBottom
				/>
			</div>
			<h2>{ __( 'Ribbon', 'runline' ) }</h2>
			<div className="runline-grid">
				<SelectControl
					label={ __( 'Shape', 'runline' ) }
					value={ settings.ribbon }
					options={ config.choices.ribbon }
					onChange={ ( ribbon ) => set( { ribbon } ) }
					help={ __(
						'Tilted ribbons look best inside a page (block, widget, shortcode), like on landing pages.',
						'runline'
					) }
					__nextHasNoMarginBottom
				/>
				{ 'none' !== settings.ribbon && (
					<RangeControl
						label={ __( 'Tilt (degrees)', 'runline' ) }
						value={ settings.tilt }
						onChange={ ( v ) => set( { tilt: v ?? -2 } ) }
						min={ -8 }
						max={ 8 }
						__nextHasNoMarginBottom
					/>
				) }
				{ 'crossed' === settings.ribbon && (
					<ColorField
						label={ __( 'Second ribbon', 'runline' ) }
						value={ settings.ribbon2 }
						onChange={ ( v ) => set( { ribbon2: v } ) }
					/>
				) }
			</div>
			<h2>{ __( 'Text', 'runline' ) }</h2>
			<div className="runline-grid">
				<SelectControl
					label={ __( 'Font', 'runline' ) }
					value={ settings.font }
					options={ config.choices.font }
					onChange={ ( font ) => set( { font } ) }
					__nextHasNoMarginBottom
				/>
				<SelectControl
					label={ __( 'Weight', 'runline' ) }
					value={ settings.font_weight }
					options={ config.choices.font_weight }
					onChange={ ( v ) => set( { font_weight: v } ) }
					__nextHasNoMarginBottom
				/>
				<RangeControl
					label={ __( 'Size on computers (px)', 'runline' ) }
					value={ settings.font_size }
					onChange={ ( v ) => set( { font_size: v || 15 } ) }
					min={ 10 }
					max={ 48 }
					__nextHasNoMarginBottom
				/>
				<RangeControl
					label={ __( 'Size on phones (px)', 'runline' ) }
					value={ settings.font_size_mobile }
					onChange={ ( v ) => set( { font_size_mobile: v || 14 } ) }
					min={ 10 }
					max={ 48 }
					__nextHasNoMarginBottom
				/>
			</div>
			<ToggleControl
				label={ __( 'CAPITAL LETTERS', 'runline' ) }
				checked={ settings.uppercase }
				onChange={ ( uppercase ) => set( { uppercase } ) }
				__nextHasNoMarginBottom
			/>
			<h2>{ __( 'Size', 'runline' ) }</h2>
			<div className="runline-grid">
				<RangeControl
					label={ __( 'Bar height (px)', 'runline' ) }
					value={ settings.height }
					onChange={ ( height ) => set( { height: height || 40 } ) }
					min={ 24 }
					max={ 120 }
					__nextHasNoMarginBottom
				/>
				<RangeControl
					label={ __( 'Space between messages (px)', 'runline' ) }
					value={ settings.gap }
					onChange={ ( gap ) => set( { gap: gap || 40 } ) }
					min={ 8 }
					max={ 200 }
					__nextHasNoMarginBottom
				/>
			</div>
			<h2>{ __( 'Width', 'runline' ) }</h2>
			<div className="runline-grid">
				<Segmented
					label={ __( 'Width', 'runline' ) }
					value={ settings.width }
					options={ config.choices.width }
					onChange={ ( width ) => set( { width } ) }
				/>
				{ 'boxed' === settings.width && (
					<>
						<RangeControl
							label={ __( 'Largest width (px)', 'runline' ) }
							value={ settings.max_width }
							onChange={ ( v ) =>
								set( { max_width: v || 1200 } )
							}
							min={ 120 }
							max={ 2000 }
							__nextHasNoMarginBottom
						/>
						<Segmented
							label={ __( 'Alignment', 'runline' ) }
							value={ settings.align }
							options={ config.choices.align }
							onChange={ ( align ) => set( { align } ) }
						/>
					</>
				) }
				<RangeControl
					label={ __( 'Rounded corners (px)', 'runline' ) }
					value={ settings.radius }
					onChange={ ( v ) => set( { radius: v || 0 } ) }
					min={ 0 }
					max={ 40 }
					__nextHasNoMarginBottom
				/>
			</div>
			<p className="runline-help">
				{ __(
					'In a column, a sidebar or any small block the bar takes the width of that place. "Limited width" also keeps it narrower on wide screens.',
					'runline'
				) }
			</p>
			<h2>{ __( 'For developers', 'runline' ) }</h2>
			<div className="runline-grid">
				<TextControl
					label={ __( 'Extra CSS class', 'runline' ) }
					value={ settings.css_class }
					onChange={ ( v ) => set( { css_class: v } ) }
					__nextHasNoMarginBottom
				/>
			</div>
		</>
	);
}

function DisplayTab( { settings, set, id, notify } ) {
	const devices = [
		[ 'desktop', __( 'Computers', 'runline' ) ],
		[ 'tablet', __( 'Tablets', 'runline' ) ],
		[ 'mobile', __( 'Phones', 'runline' ) ],
	];
	const shortcode = id ? '[runline id="' + id + '"]' : '';
	return (
		<>
			<h2>{ __( 'Where', 'runline' ) }</h2>
			<div
				className="runline-positions"
				role="radiogroup"
				aria-label={ __( 'Where', 'runline' ) }
			>
				{ config.choices.position.map( ( choice ) => (
					<button
						type="button"
						role="radio"
						aria-checked={ settings.position === choice.value }
						key={ choice.value }
						className={
							'runline-position runline-position--' +
							choice.value +
							( settings.position === choice.value
								? ' is-active'
								: '' )
						}
						onClick={ () => set( { position: choice.value } ) }
					>
						<span
							className="runline-position__pic"
							aria-hidden="true"
						>
							<i />
						</span>
						{ choice.label }
					</button>
				) ) }
			</div>
			{ 'top' === settings.position && (
				<ToggleControl
					label={ __( 'Keep at the top while scrolling', 'runline' ) }
					checked={ settings.sticky }
					onChange={ ( sticky ) => set( { sticky } ) }
					__nextHasNoMarginBottom
				/>
			) }
			{ 'bottom' === settings.position && (
				<p className="runline-help">
					{ __(
						'The bottom bar always stays on the screen; the page gets space at the end so nothing is covered.',
						'runline'
					) }
				</p>
			) }

			<h2>{ __( 'When it comes in', 'runline' ) }</h2>
			<div className="runline-grid">
				<RangeControl
					label={ __( 'After this many seconds', 'runline' ) }
					value={ settings.appear.delay }
					onChange={ ( v ) =>
						set( { appear: { ...settings.appear, delay: v || 0 } } )
					}
					min={ 0 }
					max={ 120 }
					__nextHasNoMarginBottom
				/>
				<RangeControl
					label={ __(
						'After scrolling this part of the page (%)',
						'runline'
					) }
					value={ settings.appear.scroll }
					onChange={ ( v ) =>
						set( {
							appear: { ...settings.appear, scroll: v || 0 },
						} )
					}
					min={ 0 }
					max={ 100 }
					__nextHasNoMarginBottom
				/>
			</div>
			<p className="runline-help">
				{ __(
					'0 = at once. With both set, the bar comes in when both have happened, with a short slide.',
					'runline'
				) }
			</p>

			<h2>{ __( 'Close button', 'runline' ) }</h2>
			<ToggleControl
				label={ __( 'Close button (×)', 'runline' ) }
				help={ __(
					'Off: visitors cannot close the bar, it always shows.',
					'runline'
				) }
				checked={ settings.closable }
				onChange={ ( closable ) => set( { closable } ) }
				__nextHasNoMarginBottom
			/>
			{ settings.closable && (
				<RangeControl
					label={ __( 'Hide after closing for (days)', 'runline' ) }
					help={ __(
						'0 = until you change the texts of the bar.',
						'runline'
					) }
					value={ settings.close_days }
					onChange={ ( v ) => set( { close_days: v || 0 } ) }
					min={ 0 }
					max={ 365 }
					__nextHasNoMarginBottom
				/>
			) }

			<div className="runline-shortcode">
				<p>
					{ 'manual' === settings.position
						? __(
								'Put the bar into any place — a page, a column, a sidebar, a small block — with the Runline block, the Runline Elementor widget or this shortcode. It takes the width of that place:',
								'runline'
							)
						: __(
								'You can also put the bar anywhere with the shortcode:',
								'runline'
							) }
				</p>
				{ shortcode ? (
					<p>
						<code>{ shortcode }</code>{ ' ' }
						<CopyButton text={ shortcode } notify={ notify } />
					</p>
				) : (
					<p className="runline-muted">
						{ __(
							'Save the bar to get its shortcode.',
							'runline'
						) }
					</p>
				) }
			</div>

			<RangeControl
				label={ __( 'Priority', 'runline' ) }
				help={ __(
					'Several bars in one place: higher priority goes first (on top).',
					'runline'
				) }
				value={ settings.priority }
				onChange={ ( v ) => set( { priority: v ?? 10 } ) }
				min={ 0 }
				max={ 100 }
				__nextHasNoMarginBottom
			/>
			<h2>{ __( 'Pages and visitors', 'runline' ) }</h2>
			<RulesEditor
				rules={ settings.rules }
				onChange={ ( rules ) => set( { rules } ) }
			/>
			<h2>{ __( 'Schedule', 'runline' ) }</h2>
			<ScheduleEditor
				schedule={ settings.schedule }
				onChange={ ( schedule ) => set( { schedule } ) }
			/>
			<h2>{ __( 'Devices', 'runline' ) }</h2>
			<div className="runline-devices">
				{ devices.map( ( [ key, label ] ) => (
					<CheckboxControl
						key={ key }
						label={ label }
						checked={ settings.devices[ key ] }
						onChange={ ( on ) =>
							set( {
								devices: { ...settings.devices, [ key ]: on },
							} )
						}
						__nextHasNoMarginBottom
					/>
				) ) }
			</div>
			<p className="runline-help">
				{ __(
					'Phones: up to 767 px wide, tablets: 768–1024 px, computers: wider.',
					'runline'
				) }
			</p>
			<SelectControl
				label={ __( 'On a phone: form, button, coupon', 'runline' ) }
				value={ settings.mobile_layout || 'stack' }
				options={ config.choices.mobile_layout }
				onChange={ ( v ) => set( { mobile_layout: v } ) }
				help={ __(
					'Used when the moving text would get less than about 120 px next to them. See it with "Phone" in the preview.',
					'runline'
				) }
				__nextHasNoMarginBottom
			/>
			<p className="runline-help">
				<a href={ config.settingsUrl }>
					{ __( 'Plugin settings', 'runline' ) }
				</a>
			</p>
		</>
	);
}

/**
 * What the preview needs besides the settings: messages of a source (from the server), end of a product sale.
 */
function usePreviewExtra( settings ) {
	const [ items, setItems ] = useState( null );
	const [ saleEnd, setSaleEnd ] = useState( 0 );
	const source = settings ? settings.source : null;
	const sourceKey = source ? JSON.stringify( source ) : '';
	useEffect( () => {
		if ( ! source || 'manual' === source.type ) {
			setItems( null );
			return;
		}
		const timer = setTimeout( () => {
			apiFetch( {
				path: '/runline/v1/source-items',
				method: 'POST',
				data: { source },
			} )
				.then( ( list ) =>
					setItems(
						list.map( ( item ) => ( {
							...item,
							text: decodeText( item.text ),
						} ) )
					)
				)
				.catch( () => setItems( [] ) );
		}, 400 );
		return () => clearTimeout( timer );
	}, [ sourceKey ] ); // eslint-disable-line react-hooks/exhaustive-deps

	const cd = settings ? settings.countdown : null;
	const cdKey = cd ? cd.on + cd.source + cd.product : '';
	useEffect( () => {
		if ( ! cd || ! cd.on || 'date' === cd.source ) {
			setSaleEnd( 0 );
			return;
		}
		if ( 'dayslot' === cd.source ) {
			// From Dayslot when the page was opened, or an example.
			setSaleEnd(
				config.dayslotEnd
					? config.dayslotEnd * 1000
					: Date.now() + ( 2 * 3600 + 15 * 60 ) * 1000
			);
			return;
		}
		if ( 'current_product' === cd.source ) {
			// An example: the preview has no product page.
			setSaleEnd( Date.now() + ( 2 * 86400 + 3 * 3600 ) * 1000 );
			return;
		}
		if ( ! cd.product ) {
			setSaleEnd( 0 );
			return;
		}
		apiFetch( { path: '/runline/v1/sale-end?product=' + cd.product } )
			.then( ( res ) => setSaleEnd( res.end ) )
			.catch( () => setSaleEnd( 0 ) );
	}, [ cdKey ] ); // eslint-disable-line react-hooks/exhaustive-deps

	return { items, saleEnd };
}

/** A picker of one page / post / product with a label. */
function BaseControlPicker( {
	label,
	value,
	onChange,
	kind = 'ids',
	subtype,
} ) {
	return (
		<div className="runline-field-picker">
			<span className="runline-field-picker__label">{ label }</span>
			<Picker
				kind={ kind }
				value={ value }
				onChange={ onChange }
				subtype={ subtype }
			/>
		</div>
	);
}

// One quiet line about Dayslot (our WooCommerce delivery date plugin) next to the shop features, until closed.
let dayslotClosed = false;
function DayslotHint() {
	const [ closed, setClosed ] = useState( dayslotClosed );
	if ( ! config.dayslot || closed ) {
		return null;
	}
	return (
		<p className="runline-hint">
			{ __(
				'Shop with deliveries? Dayslot, our plugin, lets customers pick the delivery date and time at checkout.',
				'runline'
			) }{ ' ' }
			<a
				href={ config.dayslot }
				target="_blank"
				rel="noopener noreferrer"
			>
				{ __( 'Learn more', 'runline' ) }
			</a>
			<Button
				icon="no-alt"
				size="small"
				label={ __( 'Do not show again', 'runline' ) }
				onClick={ () => {
					dayslotClosed = true;
					setClosed( true );
					apiFetch( {
						path: '/runline/v1/hint',
						method: 'POST',
						data: { hint: 'dayslot' },
					} ).catch( () => {} );
				} }
			/>
		</p>
	);
}

function SourceSection( { settings, set } ) {
	const src = settings.source;
	const setSrc = ( changes ) => set( { source: { ...src, ...changes } } );
	const choices = config.choices.source.filter(
		( choice ) =>
			config.woo || ! [ 'products', 'orders' ].includes( choice.value )
	);
	return (
		<>
			<div className="runline-grid">
				<SelectControl
					label={ __( 'Messages come from', 'runline' ) }
					value={ src.type }
					options={ choices }
					onChange={ ( type ) => setSrc( { type } ) }
					__nextHasNoMarginBottom
				/>
				{ 'manual' !== src.type && (
					<RangeControl
						label={ __( 'How many', 'runline' ) }
						value={ src.count }
						onChange={ ( count ) =>
							setSrc( { count: count || 5 } )
						}
						min={ 1 }
						max={ 30 }
						__nextHasNoMarginBottom
					/>
				) }
				{ 'products' === src.type && (
					<SelectControl
						label={ __( 'Which products', 'runline' ) }
						value={ src.products }
						options={ config.choices.products }
						onChange={ ( products ) => setSrc( { products } ) }
						__nextHasNoMarginBottom
					/>
				) }
				{ 'products' === src.type && (
					<TextControl
						label={ __(
							'Text with each product (optional)',
							'runline'
						) }
						help={ __(
							'{product} = name, {price} = price. E.g. "🔥 {product} — only {price}". Empty = name and price.',
							'runline'
						) }
						value={ src.text || '' }
						onChange={ ( text ) => setSrc( { text } ) }
						maxLength={ 120 }
						__nextHasNoMarginBottom
					/>
				) }
				{ 'orders' === src.type && (
					<>
						<TextControl
							label={ __( 'Message', 'runline' ) }
							help={ __(
								'{name} = the buyer (as chosen below), {city}, {product}, {time} = how long ago.',
								'runline'
							) }
							value={ src.template }
							onChange={ ( template ) => setSrc( { template } ) }
							maxLength={ 120 }
							__nextHasNoMarginBottom
						/>
						<SelectControl
							label={ __( 'How to show the name', 'runline' ) }
							value={ src.name || 'initial' }
							options={ config.choices.buyer_name }
							onChange={ ( name ) => setSrc( { name } ) }
							__nextHasNoMarginBottom
						/>
						<ToggleControl
							label={ __(
								'Show the city of the buyer',
								'runline'
							) }
							checked={ !! src.city }
							onChange={ ( city ) => setSrc( { city } ) }
							__nextHasNoMarginBottom
						/>
						<RangeControl
							label={ __( 'Orders of the last days', 'runline' ) }
							value={ src.days }
							onChange={ ( days ) =>
								setSrc( { days: days || 14 } )
							}
							min={ 1 }
							max={ 90 }
							__nextHasNoMarginBottom
						/>
					</>
				) }
				{ 'rss' === src.type && (
					<TextControl
						type="url"
						label={ __( 'Address of the RSS feed', 'runline' ) }
						value={ src.rss }
						onChange={ ( rss ) => setSrc( { rss } ) }
						placeholder="https://example.com/feed/"
						__nextHasNoMarginBottom
					/>
				) }
			</div>
			{ 'products' === src.type && 'chosen' === src.products && (
				<BaseControlPicker
					label={ __( 'Products (in this order)', 'runline' ) }
					subtype="product"
					value={ src.ids || [] }
					onChange={ ( ids ) =>
						setSrc( { ids: ids.map( Number ).slice( 0, 30 ) } )
					}
				/>
			) }
			{ ( 'posts' === src.type ||
				( 'products' === src.type && 'chosen' !== src.products ) ) && (
				<BaseControlPicker
					kind="terms"
					label={
						'products' === src.type
							? __(
									'Only from this product category (optional)',
									'runline'
								)
							: __(
									'Only from this category (optional)',
									'runline'
								)
					}
					value={ src.term ? [ src.term ] : [] }
					onChange={ ( terms ) =>
						setSrc( {
							term: terms.length ? terms[ terms.length - 1 ] : '',
						} )
					}
				/>
			) }
			{ 'orders' === src.type && (
				<Notice status="warning" isDismissible={ false }>
					{ __(
						'You show data of your customers. Mention it in the privacy policy of your shop.',
						'runline'
					) }
				</Notice>
			) }
			{ [ 'products', 'orders' ].includes( src.type ) && <DayslotHint /> }
			{ 'manual' !== src.type && (
				<ToggleControl
					label={ __( 'Also show my own messages', 'runline' ) }
					help={ __(
						'Your written messages run after the automatic ones — e.g. a delivery note between the products.',
						'runline'
					) }
					checked={ !! src.mix }
					onChange={ ( mix ) => setSrc( { mix } ) }
					__nextHasNoMarginBottom
				/>
			) }
			{ [ 'posts', 'products', 'orders' ].includes( src.type ) && (
				<ToggleControl
					label={ __( 'Show pictures', 'runline' ) }
					checked={ src.images }
					onChange={ ( images ) => setSrc( { images } ) }
					__nextHasNoMarginBottom
				/>
			) }
			{ 'products' === src.type && (
				<ToggleControl
					label={ __( 'Show prices', 'runline' ) }
					checked={ src.prices }
					onChange={ ( prices ) => setSrc( { prices } ) }
					__nextHasNoMarginBottom
				/>
			) }
			{ 'manual' !== src.type && (
				<p className="runline-help">
					{ __(
						'The messages are made automatically and refreshed every 10 minutes. Each one links to its page.',
						'runline'
					) }
				</p>
			) }
		</>
	);
}

function OffersTab( { settings, set } ) {
	const button = settings.button;
	const coupon = settings.coupon;
	const ship = settings.shipping;
	const setButton = ( changes ) =>
		set( { button: { ...button, ...changes } } );
	const setCoupon = ( changes ) =>
		set( { coupon: { ...coupon, ...changes } } );
	const setShip = ( changes ) => set( { shipping: { ...ship, ...changes } } );
	return (
		<>
			<CountdownSection settings={ settings } set={ set } />

			<h2>{ __( 'Button', 'runline' ) }</h2>
			<ToggleControl
				label={ __(
					'A button on the right (e.g. Shop now)',
					'runline'
				) }
				checked={ button.on }
				onChange={ ( on ) => setButton( { on } ) }
				__nextHasNoMarginBottom
			/>
			{ button.on && (
				<div className="runline-grid">
					<TextControl
						label={ __( 'Button text', 'runline' ) }
						value={ button.text }
						onChange={ ( text ) => setButton( { text } ) }
						maxLength={ 40 }
						__nextHasNoMarginBottom
					/>
					<TextControl
						type="url"
						label={ __( 'Button link', 'runline' ) }
						value={ button.url }
						onChange={ ( url ) => setButton( { url } ) }
						placeholder="https://"
						__nextHasNoMarginBottom
					/>
					<CheckboxControl
						label={ __( 'Open in a new tab', 'runline' ) }
						checked={ button.new_tab }
						onChange={ ( v ) => setButton( { new_tab: v } ) }
						__nextHasNoMarginBottom
					/>
					<ColorField
						label={ __( 'Button background', 'runline' ) }
						value={ button.bg }
						onChange={ ( bg ) => setButton( { bg } ) }
					/>
					<ColorField
						label={ __( 'Button text colour', 'runline' ) }
						value={ button.color }
						onChange={ ( color ) => setButton( { color } ) }
					/>
					<RangeControl
						label={ __( 'Button corners (px)', 'runline' ) }
						value={ button.radius }
						onChange={ ( v ) => setButton( { radius: v ?? 4 } ) }
						min={ 0 }
						max={ 40 }
						__nextHasNoMarginBottom
					/>
					<ToggleControl
						label={ __( 'Soft pulse to draw the eye', 'runline' ) }
						checked={ !! button.pulse }
						onChange={ ( pulse ) => setButton( { pulse } ) }
						__nextHasNoMarginBottom
					/>
				</div>
			) }

			<h2>{ __( 'Coupon', 'runline' ) }</h2>
			<ToggleControl
				label={ __( 'A coupon code with a Copy button', 'runline' ) }
				checked={ coupon.on }
				onChange={ ( on ) => setCoupon( { on } ) }
				__nextHasNoMarginBottom
			/>
			{ coupon.on && (
				<>
					<div className="runline-grid">
						<TextControl
							label={ __( 'Code', 'runline' ) }
							value={ coupon.code }
							onChange={ ( code ) => setCoupon( { code } ) }
							maxLength={ 40 }
							__nextHasNoMarginBottom
						/>
						<TextControl
							label={ __( 'Text before the code', 'runline' ) }
							value={ coupon.prefix }
							onChange={ ( prefix ) => setCoupon( { prefix } ) }
							maxLength={ 40 }
							__nextHasNoMarginBottom
						/>
						<TextControl
							label={ __( 'Copy button', 'runline' ) }
							value={ coupon.copy }
							onChange={ ( copy ) => setCoupon( { copy } ) }
							maxLength={ 30 }
							__nextHasNoMarginBottom
						/>
						<TextControl
							label={ __( 'After copying', 'runline' ) }
							value={ coupon.copied }
							onChange={ ( copied ) => setCoupon( { copied } ) }
							maxLength={ 30 }
							__nextHasNoMarginBottom
						/>
						<ColorField
							label={ __( 'Copy button background', 'runline' ) }
							value={ coupon.bg }
							onChange={ ( bg ) => setCoupon( { bg } ) }
						/>
						<ColorField
							label={ __( 'Copy button text', 'runline' ) }
							value={ coupon.color }
							onChange={ ( color ) => setCoupon( { color } ) }
						/>
						<ToggleControl
							label={ __( 'Confetti when copied', 'runline' ) }
							checked={ !! coupon.confetti }
							onChange={ ( confetti ) =>
								setCoupon( { confetti } )
							}
							__nextHasNoMarginBottom
						/>
					</div>
					<p className="runline-help">
						{ __(
							'Write {coupon} in a message to show the code inside the moving text too.',
							'runline'
						) }
					</p>
				</>
			) }

			<SignupSection settings={ settings } set={ set } />

			<ContactSection settings={ settings } set={ set } />

			{ config.woo && (
				<>
					<h2>{ __( 'Free shipping progress', 'runline' ) }</h2>
					<ToggleControl
						label={ __(
							'Show how much is left to free shipping (from the cart of the visitor)',
							'runline'
						) }
						checked={ ship.on }
						onChange={ ( on ) => setShip( { on } ) }
						__nextHasNoMarginBottom
					/>
					{ ship.on && <DayslotHint /> }
					{ ship.on && (
						<>
							<div className="runline-grid">
								<TextControl
									type="number"
									min={ 0 }
									label={ __(
										'Free shipping from',
										'runline'
									) }
									help={
										config.shipping.auto > 0
											? sprintf(
													/* translators: %s: amount found in the WooCommerce shipping settings. */
													__(
														'0 = from WooCommerce (now %s).',
														'runline'
													),
													config.shipping.auto
												)
											: __(
													'WooCommerce has no free shipping with a minimum amount: enter the amount here.',
													'runline'
												)
									}
									value={ ship.threshold }
									onChange={ ( v ) =>
										setShip( {
											threshold: parseFloat( v ) || 0,
										} )
									}
									__nextHasNoMarginBottom
								/>
								<TextControl
									label={ __(
										'Text before reaching it',
										'runline'
									) }
									value={ ship.before }
									onChange={ ( before ) =>
										setShip( { before } )
									}
									maxLength={ 160 }
									__nextHasNoMarginBottom
								/>
								<TextControl
									label={ __(
										'Text when it is reached',
										'runline'
									) }
									value={ ship.after }
									onChange={ ( after ) =>
										setShip( { after } )
									}
									maxLength={ 160 }
									__nextHasNoMarginBottom
								/>
								<ColorField
									label={ __( 'Progress line', 'runline' ) }
									value={ ship.color }
									onChange={ ( color ) =>
										setShip( { color } )
									}
								/>
							</div>
							<ToggleControl
								label={ __(
									'Progress line at the bottom of the bar',
									'runline'
								) }
								checked={ ship.progress }
								onChange={ ( progress ) =>
									setShip( { progress } )
								}
								__nextHasNoMarginBottom
							/>
							<p className="runline-help">
								{ __(
									'{free_shipping_left} is replaced by the amount left. The preview pretends a third of it is already in the cart.',
									'runline'
								) }
							</p>
						</>
					) }
				</>
			) }
		</>
	);
}

/**
 * A Google font chosen in the editor: downloaded to the site and loaded into the admin page for the preview.
 */
function useGoogleFont( font ) {
	useEffect( () => loadGoogleFont( font ), [ font ] );
}

function AbSection( { settings, set, previewB, setPreviewB } ) {
	const ab = settings.ab;
	const setAb = ( changes ) => set( { ab: { ...ab, ...changes } } );
	return (
		<>
			<h2>{ __( 'A/B test', 'runline' ) }</h2>
			<ToggleControl
				label={ __(
					'Test a second set of messages (variant B) against these (variant A)',
					'runline'
				) }
				checked={ ab.on }
				onChange={ ( on ) => {
					const changes = { on };
					if ( on && ! ab.items.length ) {
						changes.items = settings.items.map( ( item ) => ( {
							...item,
							_key: item._key + 'b',
						} ) );
					}
					setAb( changes );
					if ( ! on ) {
						setPreviewB( false );
					}
				} }
				__nextHasNoMarginBottom
			/>
			{ ab.on && (
				<>
					<RangeControl
						label={ __(
							'Visitors who see variant A (%)',
							'runline'
						) }
						value={ ab.split }
						onChange={ ( split ) =>
							setAb( { split: split || 50 } )
						}
						min={ 10 }
						max={ 90 }
						__nextHasNoMarginBottom
					/>
					<Segmented
						label={ __( 'Preview', 'runline' ) }
						value={ previewB ? 'b' : 'a' }
						onChange={ ( v ) => setPreviewB( 'b' === v ) }
						options={ [
							{ value: 'a', label: __( 'Variant A', 'runline' ) },
							{ value: 'b', label: __( 'Variant B', 'runline' ) },
						] }
					/>
					<h3>{ __( 'Variant B', 'runline' ) }</h3>
					<ItemsEditor
						items={ ab.items }
						onChange={ ( items ) => setAb( { items } ) }
						max={ config.maxItems }
					/>
					<p className="runline-help">
						{ __(
							'Each visitor keeps the same variant. Compare the click rate in the Stats tab.',
							'runline'
						) }
					</p>
				</>
			) }
		</>
	);
}

function ContactSection( { settings, set } ) {
	const contact = settings.contact;
	const setContact = ( changes ) =>
		set( { contact: { ...contact, ...changes } } );
	return (
		<>
			<h2>{ __( 'Contact buttons', 'runline' ) }</h2>
			<ToggleControl
				label={ __(
					'WhatsApp, call and Messenger buttons',
					'runline'
				) }
				checked={ contact.on }
				onChange={ ( on ) => setContact( { on } ) }
				__nextHasNoMarginBottom
			/>
			{ contact.on && (
				<>
					<div className="runline-grid">
						<TextControl
							type="tel"
							label={ __( 'WhatsApp number', 'runline' ) }
							value={ contact.whatsapp }
							onChange={ ( whatsapp ) =>
								setContact( { whatsapp } )
							}
							placeholder="+48 600 100 200"
							__nextHasNoMarginBottom
						/>
						<TextControl
							type="tel"
							label={ __( 'Phone number to call', 'runline' ) }
							value={ contact.phone }
							onChange={ ( phone ) => setContact( { phone } ) }
							placeholder="+48 600 100 200"
							__nextHasNoMarginBottom
						/>
						<TextControl
							label={ __(
								'Messenger: page or user name',
								'runline'
							) }
							value={ contact.messenger }
							onChange={ ( messenger ) =>
								setContact( { messenger } )
							}
							placeholder="yourpage"
							__nextHasNoMarginBottom
						/>
					</div>
					<p className="runline-help">
						{ __(
							'Empty fields are not shown. WhatsApp: the number with the country code. On phones the buttons show only their icons.',
							'runline'
						) }
					</p>
				</>
			) }
		</>
	);
}

function SignupSection( { settings, set } ) {
	const su = settings.signup;
	const setSu = ( changes ) => set( { signup: { ...su, ...changes } } );
	return (
		<>
			<h2>{ __( 'E-mail signup', 'runline' ) }</h2>
			<ToggleControl
				label={ __(
					'A field for the e-mail address and a Subscribe button',
					'runline'
				) }
				checked={ su.on }
				onChange={ ( on ) => setSu( { on } ) }
				__nextHasNoMarginBottom
			/>
			{ su.on && (
				<>
					<div className="runline-grid">
						<TextControl
							label={ __( 'Text in the field', 'runline' ) }
							value={ su.placeholder }
							onChange={ ( placeholder ) =>
								setSu( { placeholder } )
							}
							maxLength={ 60 }
							__nextHasNoMarginBottom
						/>
						<TextControl
							label={ __( 'Button', 'runline' ) }
							value={ su.button }
							onChange={ ( button ) => setSu( { button } ) }
							maxLength={ 30 }
							__nextHasNoMarginBottom
						/>
						<TextControl
							label={ __( 'Thank-you text', 'runline' ) }
							value={ su.success }
							onChange={ ( success ) => setSu( { success } ) }
							maxLength={ 120 }
							__nextHasNoMarginBottom
						/>
						<TextControl
							label={ __(
								'Consent check box (optional)',
								'runline'
							) }
							help={ __(
								'E.g. "I agree to get the newsletter". With a text here, the box must be ticked.',
								'runline'
							) }
							value={ su.consent }
							onChange={ ( consent ) => setSu( { consent } ) }
							maxLength={ 200 }
							__nextHasNoMarginBottom
						/>
						<SelectControl
							label={ __( 'Send addresses to', 'runline' ) }
							value={ su.service }
							options={ config.choices.service }
							onChange={ ( service ) => setSu( { service } ) }
							__nextHasNoMarginBottom
						/>
						{ 'local' !== su.service && (
							<TextControl
								label={
									'webhook' === su.service
										? __(
												'Extra text sent with each address (optional)',
												'runline'
											)
										: __(
												'List / audience / group ID',
												'runline'
											)
								}
								help={
									{
										kit: __(
											'Kit: the ID of a form (optional).',
											'runline'
										),
										omnisend: __(
											'Omnisend: a tag for the new contacts (optional).',
											'runline'
										),
										fluentcrm: __(
											'FluentCRM: the ID of a list (optional). FluentCRM sends its confirmation e-mail.',
											'runline'
										),
										mailpoet: __(
											'MailPoet: the ID of a list (empty = the first list).',
											'runline'
										),
										webhook: __(
											'The address of the webhook is set in Runline → Settings.',
											'runline'
										),
									}[ su.service ]
								}
								value={ su.list }
								onChange={ ( list ) => setSu( { list } ) }
								maxLength={ 200 }
								__nextHasNoMarginBottom
							/>
						) }
						<TextControl
							label={ __(
								'Coupon code shown after subscribing',
								'runline'
							) }
							help={ __(
								'Optional: the visitor sees it with a Copy button right after subscribing. It is not in the page before that.',
								'runline'
							) }
							value={ su.coupon || '' }
							onChange={ ( coupon ) => setSu( { coupon } ) }
							maxLength={ 40 }
							__nextHasNoMarginBottom
						/>
					</div>
					<ToggleControl
						label={ __(
							'Hide the bar for visitors who subscribed',
							'runline'
						) }
						checked={ su.hide_after }
						onChange={ ( v ) => setSu( { hide_after: v } ) }
						__nextHasNoMarginBottom
					/>
					<p className="runline-help">
						{ __(
							'Every address is kept in Runline → Subscribers (with CSV export). API keys of the services are set in the plugin settings. The colours of the button are taken from the Button section above.',
							'runline'
						) }
					</p>
				</>
			) }
		</>
	);
}
