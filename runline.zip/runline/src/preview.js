/**
 * Live preview: the bar drawn in the browser from the unsaved settings (render.js), on a sketch of a page.
 * The bar sits where it will be on the site: top, bottom of the screen, or inside the page (shortcode).
 */
import { useEffect, useRef, useState, useMemo } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Button } from '@wordpress/components';
import { renderBar } from './render';
import { config } from './api';

function Lines() {
	return (
		<div className="runline-sketch__lines" aria-hidden="true">
			<i />
			<i />
			<i />
		</div>
	);
}

export default function Preview( { settings, extra = {} } ) {
	const [ device, setDevice ] = useState( 'desktop' );
	const [ dark, setDark ] = useState( false );
	const host = useRef( null );

	const html = useMemo(
		() =>
			renderBar( settings, {
				id: 'runline-preview-bar',
				fonts: config.fonts,
				maxItems: config.maxItems,
				announcements: __( 'Announcements', 'runline' ),
				close: __( 'Close', 'runline' ),
				call: __( 'Call', 'runline' ),
				yourCountry: __( 'your country', 'runline' ),
				tzOffset: config.tzOffset,
				daysFormat: config.daysFormat,
				vars: config.vars,
				shippingAuto: ( config.shipping || {} ).auto,
				shippingFmt: ( config.shipping || {} ).fmt,
				items: extra.items || undefined,
				saleEnd: extra.saleEnd,
			} ),
		[ settings, extra.items, extra.saleEnd ]
	);

	// New HTML: stop watching the old bar, put the new one in and let runline.js set it up.
	useEffect( () => {
		const node = host.current;
		if ( ! node ) {
			return;
		}
		node.querySelectorAll( '.runline' ).forEach(
			( bar ) => bar.runlineObserver && bar.runlineObserver.disconnect()
		);
		node.innerHTML = html;
		if ( window.runlineInit ) {
			window.runlineInit( node );
		}
	}, [ html, device, settings.position ] );

	const position = settings.position;
	const bar = <div className="runline-preview" ref={ host } />;
	const empty = ! html;

	return (
		<div className="runline-preview-box">
			<div className="runline-preview-toolbar">
				<strong>{ __( 'Live preview', 'runline' ) }</strong>
				<div
					className="runline-segmented"
					role="group"
					aria-label={ __( 'Screen', 'runline' ) }
				>
					<Button
						icon="desktop"
						className={ 'desktop' === device ? 'is-active' : '' }
						aria-pressed={ 'desktop' === device }
						onClick={ () => setDevice( 'desktop' ) }
					>
						{ __( 'Computer', 'runline' ) }
					</Button>
					<Button
						icon="smartphone"
						className={ 'phone' === device ? 'is-active' : '' }
						aria-pressed={ 'phone' === device }
						onClick={ () => setDevice( 'phone' ) }
					>
						{ __( 'Phone', 'runline' ) }
					</Button>
				</div>
				<div
					className="runline-segmented"
					role="group"
					aria-label={ __( 'Page background', 'runline' ) }
				>
					<Button
						className={ ! dark ? 'is-active' : '' }
						aria-pressed={ ! dark }
						onClick={ () => setDark( false ) }
					>
						{ __( 'Light page', 'runline' ) }
					</Button>
					<Button
						className={ dark ? 'is-active' : '' }
						aria-pressed={ dark }
						onClick={ () => setDark( true ) }
					>
						{ __( 'Dark page', 'runline' ) }
					</Button>
				</div>
			</div>
			<div className={ 'runline-stage' + ( dark ? ' is-dark' : '' ) }>
				<div
					className={
						'runline-sketch' +
						( 'phone' === device
							? ' runline-preview--phone is-phone'
							: '' )
					}
				>
					{ 'top' === position && bar }
					<div className="runline-sketch__header" aria-hidden="true">
						<b />
						<span />
					</div>
					<Lines />
					{ 'manual' === position && bar }
					<Lines />
					{ 'bottom' === position && bar }
				</div>
				{ empty && (
					<p className="runline-preview-empty">
						{ __( 'Add a message to see the bar.', 'runline' ) }
					</p>
				) }
			</div>
		</div>
	);
}
