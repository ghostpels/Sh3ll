/**
 * Display rules in the editor: "Show on…" / "Hide on…" lists of conditions, and the schedule.
 * Rule types, groups, post types, roles and languages come from PHP (includes/rules.php) in window.runlineAdmin.
 */
import { useEffect, useRef, useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import {
	BaseControl,
	Button,
	CheckboxControl,
	SelectControl,
	TextControl,
	ToggleControl,
	Spinner,
} from '@wordpress/components';
import apiFetch from '@wordpress/api-fetch';
import { addQueryArgs } from '@wordpress/url';
import { config } from './api';

const titles = { posts: {}, terms: {} };

/** Default value of a new rule by its kind. */
function emptyValue( kind ) {
	if ( 'text' === kind || 'countries' === kind ) {
		return '';
	}
	if ( 'range' === kind ) {
		return { min: '', max: '' };
	}
	if ( 'number' === kind ) {
		return 2;
	}
	return 'none' === kind ? null : [];
}

function typeInfo( type ) {
	return (
		( config.ruleTypes || {} )[ type ] || {
			label: type,
			value: 'none',
			group: 'page',
		}
	);
}

/** Pages / posts / products or terms, found by name; chosen ones as chips. */
export function Picker( { kind, value, onChange, subtype = 'any' } ) {
	const [ search, setSearch ] = useState( '' );
	const [ results, setResults ] = useState( [] );
	const [ busy, setBusy ] = useState( false );
	const [ , setLoaded ] = useState( 0 );
	const isTerms = 'terms' === kind;
	const store = isTerms ? titles.terms : titles.posts;

	// Names of chosen items that are not known yet.
	useEffect( () => {
		const missing = value.filter( ( key ) => ! store[ key ] );
		if ( ! missing.length ) {
			return;
		}
		apiFetch( {
			path: addQueryArgs( '/runline/v1/titles', {
				[ isTerms ? 'terms' : 'ids' ]: missing.join( ',' ),
			} ),
		} )
			.then( ( res ) => {
				Object.assign( titles.posts, res.posts );
				Object.assign( titles.terms, res.terms );
				setLoaded( ( n ) => n + 1 );
			} )
			.catch( () => {} );
	}, [ value.join( ',' ) ] ); // eslint-disable-line react-hooks/exhaustive-deps

	const timer = useRef( 0 );
	useEffect( () => {
		clearTimeout( timer.current );
		if ( search.trim().length < 2 ) {
			setResults( [] );
			return;
		}
		timer.current = setTimeout( () => {
			setBusy( true );
			apiFetch( {
				path: addQueryArgs( '/wp/v2/search', {
					search,
					type: isTerms ? 'term' : 'post',
					subtype: isTerms ? 'any' : subtype,
					per_page: 10,
				} ),
			} )
				.then( ( found ) =>
					setResults(
						found
							.map( ( item ) => {
								let key = item.id;
								if ( isTerms ) {
									key =
										'term' === item.type
											? item.subtype + ':' + item.id
											: '';
								}
								store[ key ] = {
									title: item.title,
									type: item.subtype,
								};
								return {
									key,
									title: item.title,
									type: item.subtype,
								};
							} )
							.filter( ( item ) => item.key )
					)
				)
				.catch( () => setResults( [] ) )
				.finally( () => setBusy( false ) );
		}, 300 );
	}, [ search, isTerms, store, subtype ] );

	const add = ( key ) => {
		if ( key && ! value.includes( key ) ) {
			onChange( [ ...value, key ] );
		}
		setSearch( '' );
	};

	return (
		<div className="runline-picker">
			{ value.length > 0 && (
				<ul className="runline-chips">
					{ value.map( ( key ) => (
						<li key={ key }>
							<span>
								{ store[ key ]
									? store[ key ].title
									: '#' + key }
								{ store[ key ] && (
									<small> · { store[ key ].type }</small>
								) }
							</span>
							<Button
								size="small"
								icon="no-alt"
								label={ __( 'Remove', 'runline' ) }
								onClick={ () =>
									onChange(
										value.filter( ( v ) => v !== key )
									)
								}
							/>
						</li>
					) ) }
				</ul>
			) }
			<TextControl
				value={ search }
				onChange={ setSearch }
				placeholder={
					isTerms
						? __( 'Type to find a category or tag…', 'runline' )
						: __(
								'Type to find a page, post or product…',
								'runline'
							)
				}
				aria-label={ __( 'Search', 'runline' ) }
				__nextHasNoMarginBottom
			/>
			{ busy && <Spinner /> }
			{ results.length > 0 && (
				<ul className="runline-picker__results">
					{ results.map( ( item ) => (
						<li key={ item.key }>
							<Button
								onClick={ () => add( item.key ) }
								disabled={ value.includes( item.key ) }
							>
								{ item.title } <small>{ item.type }</small>
							</Button>
						</li>
					) ) }
				</ul>
			) }
		</div>
	);
}

function Checkboxes( { options, value, onChange } ) {
	return (
		<div className="runline-checks">
			{ Object.entries( options || {} ).map( ( [ key, label ] ) => (
				<CheckboxControl
					key={ key }
					label={ label }
					checked={ value.includes( key ) }
					onChange={ ( on ) =>
						onChange(
							on
								? [ ...value, key ]
								: value.filter( ( v ) => v !== key )
						)
					}
					__nextHasNoMarginBottom
				/>
			) ) }
		</div>
	);
}

function ValueEditor( { rule, onChange } ) {
	const kind = typeInfo( rule.type ).value;
	const value = rule.value ?? emptyValue( kind );
	switch ( kind ) {
		case 'ids':
		case 'terms':
			return (
				<Picker kind={ kind } value={ value } onChange={ onChange } />
			);
		case 'post_types':
			return (
				<Checkboxes
					options={ config.postTypes }
					value={ value }
					onChange={ onChange }
				/>
			);
		case 'roles':
			return (
				<Checkboxes
					options={ config.roles }
					value={ value }
					onChange={ onChange }
				/>
			);
		case 'languages':
			return (
				<Checkboxes
					options={ config.languages }
					value={ value }
					onChange={ onChange }
				/>
			);
		case 'text':
			return (
				<TextControl
					value={ value }
					onChange={ onChange }
					placeholder={
						'url' === rule.type
							? __( 'e.g. /sale/ or ?ref=', 'runline' )
							: __( 'e.g. facebook', 'runline' )
					}
					aria-label={ typeInfo( rule.type ).label }
					__nextHasNoMarginBottom
				/>
			);
		case 'countries':
			return (
				<TextControl
					value={ value }
					onChange={ onChange }
					placeholder="PL, DE, CZ"
					help={ __(
						'Two-letter country codes. Works when your site is behind Cloudflare or your hosting tells the country of the visitor.',
						'runline'
					) }
					aria-label={ typeInfo( rule.type ).label }
					__nextHasNoMarginBottom
				/>
			);
		case 'number':
			return (
				<TextControl
					type="number"
					min={ 1 }
					max={ 100 }
					value={ value }
					onChange={ ( v ) => onChange( parseInt( v, 10 ) || 1 ) }
					help={ __(
						'Counted on the pages of your site where this bar can show.',
						'runline'
					) }
					aria-label={ typeInfo( rule.type ).label }
					__nextHasNoMarginBottom
				/>
			);
		case 'range':
			return (
				<div className="runline-range">
					<TextControl
						type="number"
						min={ 0 }
						label={ __( 'From', 'runline' ) }
						value={ value.min }
						onChange={ ( min ) => onChange( { ...value, min } ) }
						__nextHasNoMarginBottom
					/>
					<TextControl
						type="number"
						min={ 0 }
						label={ __( 'To', 'runline' ) }
						value={ value.max }
						onChange={ ( max ) => onChange( { ...value, max } ) }
						__nextHasNoMarginBottom
					/>
				</div>
			);
	}
	return null;
}

function RuleList( { label, help, rules, onChange } ) {
	const groups = config.ruleGroups || {};
	const types = Object.entries( config.ruleTypes || {} );
	const update = ( index, changes ) =>
		onChange(
			rules.map( ( rule, i ) =>
				i === index ? { ...rule, ...changes } : rule
			)
		);
	return (
		<div className="runline-rules__list">
			<h3>{ label }</h3>
			<p className="runline-help">{ help }</p>
			{ rules.map( ( rule, index ) => (
				<div className="runline-rule" key={ index }>
					<div className="runline-rule__head">
						<strong>{ typeInfo( rule.type ).label }</strong>
						{ 'client' === typeInfo( rule.type ).side && (
							<span className="runline-rule__note">
								{ __( 'checked in the browser', 'runline' ) }
							</span>
						) }
						<Button
							size="small"
							icon="trash"
							isDestructive
							label={ __( 'Remove condition', 'runline' ) }
							onClick={ () =>
								onChange(
									rules.filter( ( _, i ) => i !== index )
								)
							}
						/>
					</div>
					<ValueEditor
						rule={ rule }
						onChange={ ( value ) => update( index, { value } ) }
					/>
				</div>
			) ) }
			<SelectControl
				className="runline-rules__add"
				value=""
				aria-label={ __( 'Add a condition', 'runline' ) }
				onChange={ ( type ) =>
					type &&
					onChange( [
						...rules,
						{ type, value: emptyValue( typeInfo( type ).value ) },
					] )
				}
				__nextHasNoMarginBottom
			>
				<option value="">
					+ { __( 'Add a condition…', 'runline' ) }
				</option>
				{ Object.entries( groups ).map( ( [ group, name ] ) => (
					<optgroup key={ group } label={ name }>
						{ types
							.filter( ( [ , info ] ) => info.group === group )
							.map( ( [ type, info ] ) => (
								<option key={ type } value={ type }>
									{ info.label }
								</option>
							) ) }
					</optgroup>
				) ) }
			</SelectControl>
		</div>
	);
}

export function RulesEditor( { rules, onChange } ) {
	return (
		<div className="runline-rules">
			<RuleList
				label={ __( 'Show on', 'runline' ) }
				help={ __(
					'Empty = everywhere. With conditions: where any of them fits.',
					'runline'
				) }
				rules={ rules.show }
				onChange={ ( show ) => onChange( { ...rules, show } ) }
			/>
			<RuleList
				label={ __( 'Do not show on', 'runline' ) }
				help={ __(
					'Where any of these fits, the bar does not show — even if "Show on" allows it.',
					'runline'
				) }
				rules={ rules.hide }
				onChange={ ( hide ) => onChange( { ...rules, hide } ) }
			/>
		</div>
	);
}

const DAYS = [
	[ 1, __( 'Mon', 'runline' ) ],
	[ 2, __( 'Tue', 'runline' ) ],
	[ 3, __( 'Wed', 'runline' ) ],
	[ 4, __( 'Thu', 'runline' ) ],
	[ 5, __( 'Fri', 'runline' ) ],
	[ 6, __( 'Sat', 'runline' ) ],
	[ 7, __( 'Sun', 'runline' ) ],
];

/** Days of the week as check boxes (1 = Monday … 7 = Sunday; none ticked = every day). */
export function DaysField( { label, value, onChange } ) {
	const days = value || [];
	return (
		<BaseControl __nextHasNoMarginBottom>
			<BaseControl.VisualLabel>{ label }</BaseControl.VisualLabel>
			<div className="runline-days">
				{ DAYS.map( ( [ day, name ] ) => (
					<CheckboxControl
						key={ day }
						label={ name }
						checked={ days.includes( day ) }
						onChange={ ( on ) =>
							onChange(
								on
									? [ ...days, day ].sort()
									: days.filter( ( d ) => d !== day )
							)
						}
						__nextHasNoMarginBottom
					/>
				) ) }
			</div>
		</BaseControl>
	);
}

export function ScheduleEditor( { schedule, onChange } ) {
	const set = ( changes ) => onChange( { ...schedule, ...changes } );
	return (
		<div className="runline-schedule">
			<ToggleControl
				label={ __( 'Show only at certain times', 'runline' ) }
				checked={ schedule.on }
				onChange={ ( on ) => set( { on } ) }
				__nextHasNoMarginBottom
			/>
			{ schedule.on && (
				<>
					<div className="runline-grid">
						<TextControl
							type="datetime-local"
							label={ __( 'From (date and time)', 'runline' ) }
							value={ schedule.start }
							onChange={ ( start ) => set( { start } ) }
							__nextHasNoMarginBottom
						/>
						<TextControl
							type="datetime-local"
							label={ __( 'Until (date and time)', 'runline' ) }
							value={ schedule.end }
							onChange={ ( end ) => set( { end } ) }
							__nextHasNoMarginBottom
						/>
					</div>
					<BaseControl __nextHasNoMarginBottom>
						<BaseControl.VisualLabel>
							{ __( 'Days of the week', 'runline' ) }
						</BaseControl.VisualLabel>
						<div className="runline-days">
							{ DAYS.map( ( [ day, name ] ) => (
								<CheckboxControl
									key={ day }
									label={ name }
									checked={ schedule.days.includes( day ) }
									onChange={ ( on ) =>
										set( {
											days: on
												? [
														...schedule.days,
														day,
													].sort()
												: schedule.days.filter(
														( d ) => d !== day
													),
										} )
									}
									__nextHasNoMarginBottom
								/>
							) ) }
						</div>
					</BaseControl>
					<div className="runline-grid">
						<TextControl
							type="time"
							label={ __( 'Every day from', 'runline' ) }
							value={ schedule.from }
							onChange={ ( from ) => set( { from } ) }
							__nextHasNoMarginBottom
						/>
						<TextControl
							type="time"
							label={ __( 'Every day until', 'runline' ) }
							value={ schedule.to }
							onChange={ ( to ) => set( { to } ) }
							__nextHasNoMarginBottom
						/>
					</div>
					<p className="runline-help">
						{ sprintf(
							/* translators: %s: time zone of the site, e.g. Europe/Warsaw. */
							__(
								'Empty fields = no limit. No day ticked = every day. Times are in the time zone of the site: %s.',
								'runline'
							),
							config.timezone
						) }
					</p>
				</>
			) }
		</div>
	);
}
