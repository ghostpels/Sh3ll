<?php
/**
 * Plugin Name:       Runline – Marquee, News Ticker & Announcement Bar
 * Plugin URI:        https://creonix.pl/
 * Description:       100% free, no Pro version. A scrolling announcement bar for the top or bottom of your site, or anywhere with a block, an Elementor widget or a shortcode. 100+ ready designs, countdown, e-mail signup, click stats and A/B tests — every feature included. Without jQuery.
 * Version:           1.2.1
 * Author:            Creonix
 * Author URI:        https://creonix.pl
 * Requires at least: 6.6
 * Requires PHP:      7.4
 * Text Domain:       runline
 * Domain Path:       /languages
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 */

defined( 'ABSPATH' ) || exit;

define( 'RUNLINE_VERSION', '1.2.1' );
define( 'RUNLINE_FILE', __FILE__ );
define( 'RUNLINE_DIR', plugin_dir_path( __FILE__ ) );
define( 'RUNLINE_URL', plugin_dir_url( __FILE__ ) );

require_once RUNLINE_DIR . 'includes/rules.php';
require_once RUNLINE_DIR . 'includes/language.php';
require_once RUNLINE_DIR . 'includes/fonts.php';
require_once RUNLINE_DIR . 'includes/settings.php';
require_once RUNLINE_DIR . 'includes/sources.php';
require_once RUNLINE_DIR . 'includes/dayslot.php';
require_once RUNLINE_DIR . 'includes/multilingual.php';
require_once RUNLINE_DIR . 'includes/stats.php';
require_once RUNLINE_DIR . 'includes/signup.php';
require_once RUNLINE_DIR . 'includes/post-type.php';
require_once RUNLINE_DIR . 'includes/render.php';
require_once RUNLINE_DIR . 'includes/frontend.php';
require_once RUNLINE_DIR . 'includes/rest.php';
require_once RUNLINE_DIR . 'includes/designs.php';
require_once RUNLINE_DIR . 'includes/designs-more.php';
require_once RUNLINE_DIR . 'includes/designs-extra.php';
require_once RUNLINE_DIR . 'includes/designs-2026.php';
require_once RUNLINE_DIR . 'includes/designs-features.php';
require_once RUNLINE_DIR . 'includes/block.php';
require_once RUNLINE_DIR . 'includes/elementor.php';

if ( is_admin() ) {
	require_once RUNLINE_DIR . 'includes/admin.php';
	require_once RUNLINE_DIR . 'includes/help.php';
}

// Translations: a language pack from translate.wordpress.org wins (WordPress loads it by itself);
// without one, the translation shipped in languages/ is used (10 languages, see tools/translations/).
register_activation_hook( RUNLINE_FILE, 'runline_stats_install' );
register_deactivation_hook(
	RUNLINE_FILE,
	function () {
		wp_clear_scheduled_hook( 'runline_signup_retry' );
	}
);

add_action(
	'init',
	function () {
		$locale = determine_locale();
		$pack   = WP_LANG_DIR . '/plugins/runline-' . $locale;
		$own    = RUNLINE_DIR . 'languages/runline-' . $locale . '.mo';
		if ( ! file_exists( $pack . '.mo' ) && ! file_exists( $pack . '.l10n.php' ) && file_exists( $own ) ) {
			load_textdomain( 'runline', $own, $locale );
		}
	},
	1
);

add_filter(
	'plugin_action_links_' . plugin_basename( RUNLINE_FILE ),
	function ( $links ) {
		$url = runline_admin_url();
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Bars', 'runline' ) . '</a>' );
		return $links;
	}
);
