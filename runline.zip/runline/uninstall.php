<?php
/**
 * Deleting the plugin removes its data only when Runline → Settings says so.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$runline_options = get_option( 'runline_options', array() );
if ( empty( $runline_options['delete_data'] ) ) {
	return;
}

$runline_ids = get_posts(
	array(
		'post_type'      => 'runline_bar',
		'post_status'    => 'any',
		'posts_per_page' => -1,
		'fields'         => 'ids',
	)
);
foreach ( $runline_ids as $runline_id ) {
	wp_delete_post( $runline_id, true );
}
delete_option( 'runline_options' );
delete_option( 'runline_db_version' );
delete_option( 'runline_installed' );
delete_option( 'runline_signup_error' );
wp_clear_scheduled_hook( 'runline_signup_retry' );
delete_metadata( 'user', 0, 'runline_welcome_done', '', true );
delete_metadata( 'user', 0, 'runline_review_later', '', true );
delete_metadata( 'user', 0, 'runline_review_done', '', true );
delete_metadata( 'user', 0, 'runline_hint_dayslot', '', true );
// Google fonts saved on the site.
$runline_uploads = wp_upload_dir( null, false );
$runline_fonts   = trailingslashit( $runline_uploads['basedir'] ) . 'runline-fonts';
if ( is_dir( $runline_fonts ) ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	WP_Filesystem();
	global $wp_filesystem;
	if ( $wp_filesystem ) {
		$wp_filesystem->rmdir( $runline_fonts, true );
	}
}
global $wpdb;
// Counters of the signup and statistics limits (they expire by themselves within a day; removed here at once).
$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE option_name LIKE %s OR option_name LIKE %s', $wpdb->options, $wpdb->esc_like( '_transient_runline_' ) . '%', $wpdb->esc_like( '_transient_timeout_runline_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}runline_stats, {$wpdb->prefix}runline_subscribers" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange -- removing the plugin's own table on uninstall.
