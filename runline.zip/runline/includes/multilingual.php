<?php
/**
 * Multilingual sites: the texts of the bars go to WPML (String Translation) or Polylang (Strings translations),
 * and the site shows them in the language of the page.
 */

defined( 'ABSPATH' ) || exit;

define( 'RUNLINE_STRINGS_CONTEXT', 'Runline' );

/**
 * Texts of a bar that can be translated: name => value. Names stay the same while the order of messages stays.
 *
 * @param int   $bar_id   Bar ID.
 * @param array $settings Bar settings.
 */
function runline_translatable_texts( $bar_id, $settings ) {
	$texts = array(
		'label'             => $settings['label'],
		'countdown prefix'  => $settings['countdown']['prefix'],
		'countdown ended'   => $settings['countdown']['after_text'],
		'button text'       => $settings['button']['text'],
		'coupon prefix'     => $settings['coupon']['prefix'],
		'coupon copy'       => $settings['coupon']['copy'],
		'coupon copied'     => $settings['coupon']['copied'],
		'free shipping'     => $settings['shipping']['before'],
		'free shipping got' => $settings['shipping']['after'],
		'signup field'      => $settings['signup']['placeholder'],
		'signup button'     => $settings['signup']['button'],
		'signup thanks'     => $settings['signup']['success'],
		'signup consent'    => $settings['signup']['consent'],
	);
	foreach ( $settings['items'] as $i => $item ) {
		$texts[ 'message ' . ( $i + 1 ) ]         = isset( $item['text'] ) ? (string) $item['text'] : '';
		$texts[ 'message ' . ( $i + 1 ) . ' by' ] = isset( $item['author'] ) ? (string) $item['author'] : '';
	}
	$out = array();
	foreach ( array_filter( $texts, 'strlen' ) as $name => $value ) {
		$out[ sprintf( 'Bar %d: %s', $bar_id, $name ) ] = $value;
	}
	return $out;
}

function runline_multilingual_active() {
	return has_action( 'wpml_register_single_string' ) || function_exists( 'pll_register_string' );
}

// WPML: register the texts when a bar is saved.
add_action(
	'runline_settings_saved',
	function ( $bar_id, $settings ) {
		if ( ! has_action( 'wpml_register_single_string' ) ) {
			return;
		}
		foreach ( runline_translatable_texts( $bar_id, $settings ) as $name => $value ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- the WPML API.
			do_action( 'wpml_register_single_string', RUNLINE_STRINGS_CONTEXT, $name, $value );
		}
	},
	10,
	2
);

// Polylang: strings are registered on every admin page load (that is how Polylang works).
add_action(
	'admin_init',
	function () {
		if ( ! function_exists( 'pll_register_string' ) ) {
			return;
		}
		$ids = get_posts(
			array(
				'post_type'      => RUNLINE_POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 500,
				'fields'         => 'ids',
			)
		);
		if ( $ids ) {
			update_meta_cache( 'post', $ids );
		}
		foreach ( $ids as $id ) {
			foreach ( runline_translatable_texts( $id, runline_get_settings( $id ) ) as $name => $value ) {
				pll_register_string( $name, $value, RUNLINE_STRINGS_CONTEXT, false );
			}
		}
	}
);

/**
 * The settings of a bar with its texts in the language of the page.
 *
 * @param int   $bar_id   Bar ID.
 * @param array $settings Bar settings.
 * @return array
 */
function runline_translate_settings( $bar_id, $settings ) {
	if ( ! runline_multilingual_active() ) {
		return $settings;
	}
	$translate = function ( $name, $value ) use ( $bar_id ) {
		if ( '' === $value ) {
			return $value;
		}
		$full = sprintf( 'Bar %d: %s', $bar_id, $name );
		if ( has_filter( 'wpml_translate_single_string' ) ) {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- the WPML API.
			return apply_filters( 'wpml_translate_single_string', $value, RUNLINE_STRINGS_CONTEXT, $full );
		}
		return function_exists( 'pll__' ) ? pll__( $value ) : $value;
	};

	$settings['label']                   = $translate( 'label', $settings['label'] );
	$settings['countdown']['prefix']     = $translate( 'countdown prefix', $settings['countdown']['prefix'] );
	$settings['countdown']['after_text'] = $translate( 'countdown ended', $settings['countdown']['after_text'] );
	$settings['button']['text']          = $translate( 'button text', $settings['button']['text'] );
	$settings['coupon']['prefix']        = $translate( 'coupon prefix', $settings['coupon']['prefix'] );
	$settings['coupon']['copy']          = $translate( 'coupon copy', $settings['coupon']['copy'] );
	$settings['coupon']['copied']        = $translate( 'coupon copied', $settings['coupon']['copied'] );
	$settings['shipping']['before']      = $translate( 'free shipping', $settings['shipping']['before'] );
	$settings['shipping']['after']       = $translate( 'free shipping got', $settings['shipping']['after'] );
	$settings['signup']['placeholder']   = $translate( 'signup field', $settings['signup']['placeholder'] );
	$settings['signup']['button']        = $translate( 'signup button', $settings['signup']['button'] );
	$settings['signup']['success']       = $translate( 'signup thanks', $settings['signup']['success'] );
	$settings['signup']['consent']       = $translate( 'signup consent', $settings['signup']['consent'] );
	foreach ( $settings['items'] as $i => $item ) {
		$settings['items'][ $i ]['text']   = $translate( 'message ' . ( $i + 1 ), isset( $item['text'] ) ? (string) $item['text'] : '' );
		$settings['items'][ $i ]['author'] = $translate( 'message ' . ( $i + 1 ) . ' by', isset( $item['author'] ) ? (string) $item['author'] : '' );
	}
	return $settings;
}
