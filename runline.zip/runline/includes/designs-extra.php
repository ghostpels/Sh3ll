<?php
/**
 * Designs added in 1.0.1: winter season, delivery, loyalty, shop info and a few looks.
 * Merged into runline_designs(); every one passes WCAG AA contrast (tests/run-tests.php).
 */

defined( 'ABSPATH' ) || exit;

/**
 * The 12 designs of 1.0.1.
 */
function runline_extra_designs() {
	$home = home_url( '/' );
	$item = 'runline_design_item';

	return array(
		// Shop & sales.
		array(
			'id'       => 'black-friday-gold',
			'name'     => __( 'Black Friday gold', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'        => '#0a0a0a',
				'color'     => '#facc15',
				'font'      => 'g:Bebas Neue',
				'font_size' => 20,
				'uppercase' => true,
				'height'    => 46,
				'separator' => '★',
				'countdown' => array(
					'on'    => true,
					'end'   => runline_design_in_days( 4 ),
					'place' => 'right',
					'bg'    => '#facc15',
					'color' => '#0a0a0a',
				),
				'items'     => array(
					$item( '', __( 'Black Friday: up to −60% on everything', 'runline' ) ),
					$item( '', __( 'Only this weekend', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'winter-sale',
			'name'     => __( 'Winter sale', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#1e3a8a',
				'bg2'         => '#0e7490',
				'color'       => '#ffffff',
				'font'        => 'g:Nunito',
				'font_weight' => '700',
				'separator'   => '❄',
				'button'      => array(
					'on'     => true,
					'text'   => __( 'See the sale', 'runline' ),
					'url'    => $home,
					'bg'     => '#ffffff',
					'color'  => '#1e3a8a',
					'radius' => 20,
				),
				'items'       => array(
					$item( '❄️', __( 'Winter sale: −30% on the whole collection', 'runline' ) ),
					$item( '🧣', __( 'Warm gifts for the whole family', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'gift-with-purchase',
			'name'     => __( 'Free gift with order', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#fdf2f8',
				'color'       => '#9d174d',
				'font'        => 'g:Poppins',
				'font_weight' => '600',
				'separator'   => '♥',
				'items'       => array(
					$item( '🎁', __( 'A free gift with every order over 200', 'runline' ) ),
					$item( '💌', __( 'Gift wrapping and a card for free', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'back-in-stock',
			'name'     => __( 'Back in stock', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'           => '#ecfdf5',
				'color'        => '#065f46',
				'font'         => 'g:DM Sans',
				'font_weight'  => '700',
				'mode'         => 'fade',
				'interval'     => 4,
				'border_width' => 1,
				'border_color' => '#6ee7b7',
				'items'        => array(
					$item( '✅', __( 'Back in stock: our bestsellers are here again', 'runline' ) ),
					$item( '🔔', __( 'Pre-order the new collection today', 'runline' ) ),
				),
			),
		),
		// Holidays.
		array(
			'id'       => 'christmas-deadline',
			'name'     => __( 'Order before Christmas', 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'          => '#14532d',
				'color'       => '#ffffff',
				'font'        => 'g:Nunito',
				'font_weight' => '800',
				'separator'   => '❄',
				'label'       => __( 'Christmas', 'runline' ),
				'label_bg'    => '#b91c1c',
				'label_color' => '#ffffff',
				'items'       => array(
					$item( '🎁', __( 'Order by December 20 — it arrives before Christmas', 'runline' ) ),
					$item( '🎄', __( 'Merry Christmas!', 'runline' ) ),
				),
			),
		),
		// Coupons & signups.
		array(
			'id'       => 'loyalty-points',
			'name'     => __( 'Loyalty club', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'          => '#4c1d95',
				'bg2'         => '#6d28d9',
				'color'       => '#ffffff',
				'font'        => 'g:Manrope',
				'font_weight' => '700',
				'separator'   => '✦',
				'button'      => array(
					'on'     => true,
					'text'   => __( 'Join free', 'runline' ),
					'url'    => $home,
					'bg'     => '#fde68a',
					'color'  => '#3b0764',
					'radius' => 4,
				),
				'items'       => array(
					$item( '💎', __( 'Join the club: points on every order', 'runline' ) ),
					$item( '🎂', __( 'A birthday gift for members', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'refer-a-friend',
			'name'     => __( 'Refer a friend', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'          => '#fff7ed',
				'color'       => '#9a3412',
				'font'        => 'g:Rubik',
				'font_weight' => '600',
				'coupon'      => array(
					'on'    => true,
					'code'  => 'FRIEND15',
					'bg'    => '#9a3412',
					'color' => '#ffffff',
				),
				'items'       => array(
					$item( '🤝', __( 'Bring a friend: you both get −15%', 'runline' ) ),
				),
			),
		),
		// News & blog.
		array(
			'id'       => 'we-are-hiring',
			'name'     => __( 'We are hiring', 'runline' ),
			'category' => 'news',
			'settings' => array(
				'bg'          => '#111827',
				'color'       => '#a7f3d0',
				'font'        => 'g:Space Grotesk',
				'font_weight' => '500',
				'separator'   => '/',
				'label'       => __( 'Jobs', 'runline' ),
				'label_bg'    => '#a7f3d0',
				'label_color' => '#111827',
				'items'       => array(
					$item( '', __( 'We are hiring — join our team', 'runline' ) ),
					$item( '', __( 'Remote and office positions open', 'runline' ) ),
				),
			),
		),
		// Flowers, cafés, events.
		array(
			'id'       => 'same-day-delivery',
			'name'     => __( 'Same-day delivery', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#0369a1',
				'color'       => '#ffffff',
				'font'        => 'g:Montserrat',
				'font_weight' => '700',
				'separator'   => '•',
				'items'       => array(
					$item( '🚚', __( 'Order by 2 pm — delivered today', 'runline' ) ),
					$item( '📞', __( 'Questions? Call us, we answer 7 days a week', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'opening-hours',
			'name'     => __( 'Opening hours', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#f5f5f4',
				'color'       => '#292524',
				'font'        => 'g:Work Sans',
				'font_weight' => '500',
				'mode'        => 'static',
				'items'       => array(
					$item( '🕘', __( 'Open Mon–Fri 9:00–18:00, Sat 10:00–14:00', 'runline' ) ),
				),
			),
		),
		// Landing pages.
		array(
			'id'       => 'aurora',
			'name'     => __( 'Aurora', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'          => '#312e81',
				'bg2'         => '#065f46',
				'color'       => '#ffffff',
				'font'        => 'g:Raleway',
				'font_size'   => 17,
				'font_weight' => '700',
				'height'      => 48,
				'shadow'      => 'soft',
				'separator'   => '✧',
				'items'       => array(
					$item( '', __( 'Something new is coming', 'runline' ) ),
					$item( '', __( 'Be the first to see it', 'runline' ) ),
				),
			),
		),
		// Minimal.
		array(
			'id'       => 'minimal-pastel',
			'name'     => __( 'Minimal pastel', 'runline' ),
			'category' => 'minimal',
			'settings' => array(
				'bg'               => '#e0f2fe',
				'color'            => '#0c4a6e',
				'font'             => 'g:Inter',
				'font_size'        => 13,
				'font_size_mobile' => 12,
				'font_weight'      => '500',
				'height'           => 34,
				'separator'        => '·',
				'items'            => array(
					$item( '', __( 'Free delivery from 150', 'runline' ) ),
					$item( '', __( 'Easy returns within 30 days', 'runline' ) ),
				),
			),
		),
	);
}
