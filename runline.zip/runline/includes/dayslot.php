<?php
/**
 * Runline + Dayslot, our free plugin for WooCommerce delivery dates. Only FREE Dayslot features are used:
 * {delivery_date}, {pickup_date}, {places_left}; the countdown "until the next delivery date changes"; the free
 * delivery amount for the free shipping progress; the display rules "Dayslot: no delivery today / tomorrow".
 * Without Dayslot nothing here shows on the site. Every Dayslot call is guarded: an update of Dayslot must never break
 * a bar. Dates go to the browser too, so cached pages stay right (runline.js `dayslotDates`, gate.js `dsOff`).
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether Dayslot is active (with the functions Runline reads).
 */
function runline_dayslot_on() {
	return function_exists( 'dayslot_earliest_date' ) && function_exists( 'dayslot_get_settings' ) && function_exists( 'dayslot_modes' );
}

/**
 * Calls a Dayslot function; null when it fails.
 *
 * @param callable $fn Function.
 * @return mixed
 */
function runline_dayslot_call( $fn ) {
	try {
		return $fn();
	} catch ( Throwable $e ) {
		return null;
	}
}

/**
 * The first date a customer can choose in Dayslot for "delivery" or "pickup" (Y-m-d), or ''.
 *
 * @param string $mode "delivery" or "pickup".
 */
function runline_dayslot_first( $mode = 'delivery' ) {
	if ( ! runline_dayslot_on() ) {
		return '';
	}
	$date = runline_dayslot_call(
		function () use ( $mode ) {
			$modes = (array) dayslot_modes();
			return isset( $modes[ $mode ] ) ? (string) dayslot_earliest_date( array( 'mode' => $mode ) ) : '';
		}
	);
	return is_string( $date ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ? $date : '';
}

/**
 * Today at midnight in the site time zone.
 */
function runline_dayslot_today() {
	return new DateTimeImmutable( 'today', wp_timezone() );
}

/**
 * A date as text: "today", "tomorrow" or the date (Dayslot's own format when it has one).
 *
 * @param string $date Y-m-d.
 */
function runline_dayslot_day_text( $date ) {
	$today = runline_dayslot_today();
	if ( $today->format( 'Y-m-d' ) === $date ) {
		return __( 'today', 'runline' );
	}
	if ( $today->modify( '+1 day' )->format( 'Y-m-d' ) === $date ) {
		return __( 'tomorrow', 'runline' );
	}
	return runline_dayslot_full_date( $date );
}

/**
 * A date written out ("Friday, 20 November").
 *
 * @param string $date Y-m-d.
 */
function runline_dayslot_full_date( $date ) {
	if ( function_exists( 'dayslot_format_date' ) ) {
		$text = runline_dayslot_call(
			function () use ( $date ) {
				return wp_strip_all_tags( (string) dayslot_format_date( $date ) );
			}
		);
		if ( is_string( $text ) && '' !== $text ) {
			return $text;
		}
	}
	return wp_date( 'l, j F', ( new DateTimeImmutable( $date, wp_timezone() ) )->getTimestamp() );
}

/**
 * {delivery_date} as plain text ("tomorrow"); '' without Dayslot or a free date.
 *
 * @param bool $preview An example ("tomorrow") instead of ''.
 */
function runline_delivery_date( $preview = false ) {
	$date = runline_dayslot_first( 'delivery' );
	if ( '' === $date ) {
		return $preview ? __( 'tomorrow', 'runline' ) : '';
	}
	return runline_dayslot_day_text( $date );
}

/**
 * The element of a date: the browser writes "today" / "tomorrow" again on cached pages and drops the message when
 * the date is gone (runline.js).
 *
 * @param string $date Y-m-d.
 */
function runline_dayslot_date_span( $date ) {
	return sprintf(
		'<span class="runline__ds" data-ds="%1$s" data-o="%2$d" data-today="%3$s" data-tomorrow="%4$s" data-full="%5$s">%6$s</span>',
		esc_attr( $date ),
		runline_tz_offset(),
		esc_attr__( 'today', 'runline' ),
		esc_attr__( 'tomorrow', 'runline' ),
		esc_attr( runline_dayslot_full_date( $date ) ),
		esc_html( runline_dayslot_day_text( $date ) )
	);
}

/**
 * Free places left on the first delivery date: the day limit and the limits of its times (null = no limit).
 *
 * @param string $date Y-m-d.
 * @return int|null
 */
function runline_dayslot_places( $date ) {
	if ( '' === $date || ! function_exists( 'dayslot_day_limit' ) || ! function_exists( 'dayslot_occupancy' ) ) {
		return null;
	}
	$left = runline_dayslot_call(
		function () use ( $date ) {
			$ctx   = array( 'mode' => 'delivery' );
			$left  = null;
			$limit = (int) dayslot_day_limit( $date, $ctx );
			if ( $limit > 0 ) {
				$occ  = dayslot_occupancy( $date, $ctx );
				$left = max( 0, $limit - (int) $occ['total'] );
			}
			if ( function_exists( 'dayslot_time_options' ) ) {
				$sum   = 0;
				$known = true;
				$any   = false;
				foreach ( (array) dayslot_time_options( $date, $ctx ) as $group ) {
					// An exact time also takes a place in its window: the sum would count it twice.
					if ( 'exact' === $group['type'] ) {
						$known = false;
					}
					foreach ( $group['options'] as $option ) {
						if ( empty( $option['available'] ) ) {
							continue;
						}
						$any = true;
						if ( null === $option['left'] ) {
							$known = false;
						} else {
							$sum += (int) $option['left'];
						}
					}
				}
				if ( $any && $known ) {
					$left = null === $left ? $sum : min( $left, $sum );
				}
			}
			return $left;
		}
	);
	return is_int( $left ) ? $left : null;
}

/**
 * The most places left for which {places_left} is shown ("only 3 left"); with more it would not sound true.
 */
function runline_dayslot_places_max() {
	return max( 1, (int) apply_filters( 'runline_places_max', 5 ) );
}

/**
 * Values of {delivery_date}, {pickup_date} and {places_left} for the texts ('' = messages with it are not shown).
 *
 * @param bool $preview Examples instead of '' (the preview in the admin).
 * @return array
 */
function runline_dayslot_vars( $preview = false ) {
	$example  = runline_dayslot_today()->modify( '+1 day' )->format( 'Y-m-d' );
	$delivery = runline_dayslot_first( 'delivery' );
	$pickup   = runline_dayslot_first( 'pickup' );
	$places   = runline_dayslot_places( $delivery );
	if ( null !== $places && ( $places < 1 || $places > runline_dayslot_places_max() ) ) {
		$places = null;
	}
	if ( $preview ) {
		$delivery = '' !== $delivery ? $delivery : $example;
		$pickup   = '' !== $pickup ? $pickup : $example;
		$places   = null !== $places ? $places : 3;
	}
	return array(
		'{delivery_date}' => '' !== $delivery ? runline_dayslot_date_span( $delivery ) : '',
		'{pickup_date}'   => '' !== $pickup ? runline_dayslot_date_span( $pickup ) : '',
		'{places_left}'   => null !== $places ? '<span class="runline__ds-places" data-ds="' . esc_attr( $delivery ) . '" data-o="' . runline_tz_offset() . '">' . (int) $places . '</span>' : '',
	);
}

/**
 * Messages with a Dayslot variable that has no value now are left out (no "Next delivery: " without a date).
 *
 * @param array $items Items.
 * @param array $vars  From runline_dayslot_vars().
 * @return array
 */
function runline_dayslot_drop_items( $items, $vars ) {
	$empty = array_keys( array_filter( $vars, 'runline_dayslot_is_empty' ) );
	if ( ! $empty ) {
		return $items;
	}
	return array_values(
		array_filter(
			$items,
			function ( $item ) use ( $empty ) {
				$text = isset( $item['text'] ) ? (string) $item['text'] : '';
				foreach ( $empty as $name ) {
					if ( false !== strpos( $text, $name ) ) {
						return false;
					}
				}
				return true;
			}
		)
	);
}

/**
 * Whether a value is empty (callback).
 *
 * @param string $value Value.
 */
function runline_dayslot_is_empty( $value ) {
	return '' === $value;
}

/**
 * When the first delivery date moves to a later day (Unix time, 0 = unknown): at midnight when the minimum notice
 * in days passes it, or when the last free time of that day is too close (Dayslot's "Preparation time").
 * For the countdown "until the next delivery date changes": "Order in 02:15:30 — delivery tomorrow".
 */
function runline_dayslot_deadline() {
	$date = runline_dayslot_first( 'delivery' );
	if ( '' === $date ) {
		return 0;
	}
	$end = runline_dayslot_call(
		function () use ( $date ) {
			$zone = wp_timezone();
			$day  = new DateTimeImmutable( $date, $zone );
			$min  = function_exists( 'dayslot_min_days' ) ? (int) dayslot_min_days( array( 'mode' => 'delivery' ) ) : 0;
			$ends = array( $day->modify( '-' . $min . ' days' )->modify( '+1 day' )->getTimestamp() );
			$s    = dayslot_get_settings();
			if ( function_exists( 'dayslot_time_options' ) && function_exists( 'dayslot_slot_start' ) && ( ! function_exists( 'dayslot_feature_on' ) || dayslot_feature_on( 'times' ) ) ) {
				$last = 0;
				foreach ( (array) dayslot_time_options( $date, array( 'mode' => 'delivery' ) ) as $group ) {
					$variant = function_exists( 'dayslot_variant' ) ? dayslot_variant( $group['variant'] ) : null;
					foreach ( $group['options'] as $option ) {
						if ( empty( $option['available'] ) ) {
							continue;
						}
						$start = dayslot_slot_start( $date, $option['key'] );
						if ( $start && $variant && function_exists( 'dayslot_night_next_day' ) && dayslot_night_next_day( $variant, $option['key'] ) ) {
							$start = $start->modify( '+1 day' );
						}
						if ( $start ) {
							$last = max( $last, $start->getTimestamp() );
						}
					}
				}
				if ( $last ) {
					// A time can be chosen while this minute + preparation time is not after its start.
					$prep   = isset( $s['slot_prep_minutes'] ) ? max( 0, (int) $s['slot_prep_minutes'] ) : 0;
					$ends[] = $last - $prep * 60 + 60;
				}
			}
			return min( $ends );
		}
	);
	return is_int( $end ) && $end > time() ? $end : 0;
}

/**
 * Days without delivery in the next two weeks (Y-m-d): Dayslot's days off, blocked dates and day types on which
 * every kind of delivery is off. For the rules "Dayslot: no delivery today / tomorrow".
 */
function runline_dayslot_days_off() {
	if ( ! runline_dayslot_on() ) {
		return array();
	}
	$off = runline_dayslot_call(
		function () {
			$ctx     = array( 'mode' => 'delivery' );
			$closed  = function_exists( 'dayslot_closed_weekdays' ) ? dayslot_closed_weekdays( $ctx ) : array();
			$blocked = function_exists( 'dayslot_blocked_dates' ) ? array_flip( dayslot_blocked_dates() ) : array();
			$dead    = array();
			if ( function_exists( 'dayslot_variants' ) && function_exists( 'dayslot_day_type' ) && dayslot_variants() ) {
				foreach ( array( 'weekday', 'sunday', 'holiday' ) as $type ) {
					$dead[ $type ] = true;
					foreach ( dayslot_variants() as $variant ) {
						if ( ! in_array( $type, (array) $variant['off_days'], true ) ) {
							unset( $dead[ $type ] );
							break;
						}
					}
				}
			}
			$out = array();
			$day = runline_dayslot_today();
			for ( $i = 0; $i < 15; $i++, $day = $day->modify( '+1 day' ) ) {
				$key = $day->format( 'Y-m-d' );
				if ( in_array( (int) $day->format( 'w' ), $closed, true ) || isset( $blocked[ $key ] ) || ( $dead && isset( $dead[ dayslot_day_type( $key ) ] ) ) ) {
					$out[] = $key;
				}
			}
			return $out;
		}
	);
	return is_array( $off ) ? $off : array();
}

/**
 * The free delivery amount of Dayslot (0 = none), for the free shipping progress when the bar has no amount.
 */
function runline_dayslot_free_above() {
	if ( ! runline_dayslot_on() ) {
		return 0;
	}
	$above = runline_dayslot_call(
		function () {
			$s = dayslot_get_settings();
			if ( ( function_exists( 'dayslot_feature_on' ) && ! dayslot_feature_on( 'shipping' ) ) || ( isset( $s['free_always'] ) && 'yes' === $s['free_always'] ) ) {
				return 0;
			}
			return isset( $s['free_above'] ) ? (float) $s['free_above'] : 0;
		}
	);
	return is_numeric( $above ) && $above > 0 ? (float) $above : 0;
}
