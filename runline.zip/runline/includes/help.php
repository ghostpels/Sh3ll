<?php
/**
 * Admin: the Help page, the "ready to go" notice after activation, the review request and the links in the
 * list of plugins. Notices show only to admins, can always be closed, and never on the editor of a bar.
 */

defined( 'ABSPATH' ) || exit;

define( 'RUNLINE_SUPPORT_URL', 'https://wordpress.org/support/plugin/runline/' );
define( 'RUNLINE_REVIEW_URL', 'https://wordpress.org/support/plugin/runline/reviews/#new-post' );
define( 'RUNLINE_SITE_URL', 'https://creonix.pl/' );
if ( ! defined( 'RUNLINE_DAYSLOT_URL' ) ) {
	define( 'RUNLINE_DAYSLOT_URL', 'https://wordpress.org/plugins/dayslot/' );
}

/**
 * Whether Dayslot (our plugin for WooCommerce delivery dates) is installed, switched on or not.
 */
function runline_dayslot_installed() {
	return defined( 'DAYSLOT_VERSION' ) || file_exists( WP_PLUGIN_DIR . '/dayslot/dayslot.php' );
}

/**
 * The one-line hint about Dayslot in the bar editor: only with WooCommerce, without Dayslot, until the admin closes it.
 */
function runline_dayslot_hint() {
	return class_exists( 'WooCommerce' ) && ! runline_dayslot_installed() && ! get_user_meta( get_current_user_id(), 'runline_hint_dayslot', true );
}

add_action(
	'admin_menu',
	function () {
		add_submenu_page( RUNLINE_PAGE, __( 'Runline help', 'runline' ), __( 'Help', 'runline' ), 'manage_options', 'runline-help', 'runline_help_page' );
	},
	30
);

function runline_help_page() {
	$steps = array(
		__( 'Go to Runline → Add bar and pick one of the ready designs, or start from scratch.', 'runline' ),
		__( 'Write your messages. The preview shows the bar as it will look on your site.', 'runline' ),
		__( 'In the Display tab choose where the bar shows: top, bottom, or only where you put the block, the Elementor widget or the shortcode.', 'runline' ),
		__( 'Click Save. Switch bars on and off in the list.', 'runline' ),
	);
	$faq   = array(
		__( 'The bar does not show', 'runline' ) => __( 'Check that the bar is switched on in the list, that the display rules and the schedule fit the page, and that you did not close it yourself (closed bars stay hidden for the days set in the Appearance tab — try a private window). If you use page caching, clear the cache after changes.', 'runline' ),
		__( 'The bar is under the header of my theme', 'runline' ) => __( 'Switch on "Move a fixed (sticky) header of the theme below the top bars" in Runline → Settings, or put the bar into the header with the block or the Elementor widget.', 'runline' ),
		__( 'How do I put a bar into a page or a column?', 'runline' ) => __( 'Set Display → Where to "Only where I put the shortcode", then add the Runline bar block, the Runline bar Elementor widget, or the shortcode below. The bar takes the width of that place.', 'runline' ),
		__( 'How do I move my bars to another site?', 'runline' ) => __( 'Click Export in the list of bars and Import on the other site. Imported bars are switched off, so you can check them first.', 'runline' ),
	);
	?>
	<div class="wrap runline-help">
		<h1><?php esc_html_e( 'Runline help', 'runline' ); ?></h1>

		<h2><?php esc_html_e( 'Your first bar in two minutes', 'runline' ); ?></h2>
		<ol>
			<?php foreach ( $steps as $step ) : ?>
				<li><?php echo esc_html( $step ); ?></li>
			<?php endforeach; ?>
		</ol>
		<p><a class="button button-primary" href="<?php echo esc_url( runline_admin_url( 'new' ) ); ?>"><?php esc_html_e( 'Add bar', 'runline' ); ?></a></p>

		<h2><?php esc_html_e( 'Shortcode', 'runline' ); ?></h2>
		<p><?php esc_html_e( 'Use [runline id="123"] to put a bar into a page, a column, a sidebar widget or the Elementor Shortcode widget. The bar takes the width of the place you put it in. Without an ID it shows the first bar that is switched on. The ID is in the list of bars.', 'runline' ); ?></p>
		<p><?php esc_html_e( 'Options for one place only:', 'runline' ); ?></p>
		<ul class="ul-disc">
			<li><code>width="320"</code> — <?php esc_html_e( 'largest width in pixels', 'runline' ); ?></li>
			<li><code>align="left"</code> — <?php esc_html_e( 'left, center or right (with width)', 'runline' ); ?></li>
			<li><code>radius="8"</code> — <?php esc_html_e( 'rounded corners in pixels', 'runline' ); ?></li>
			<li><code>height="32"</code> — <?php esc_html_e( 'bar height in pixels', 'runline' ); ?></li>
			<li><code>size="13"</code> — <?php esc_html_e( 'text size in pixels', 'runline' ); ?></li>
		</ul>
		<p><code>[runline id="123" width="320" radius="8" size="13"]</code></p>

		<h2><?php esc_html_e( 'Variables in texts', 'runline' ); ?></h2>
		<ul class="ul-disc">
			<li><code>{date}</code> — <?php esc_html_e( 'today’s date', 'runline' ); ?></li>
			<li><code>{site_name}</code> — <?php esc_html_e( 'the name of your site', 'runline' ); ?></li>
			<li><code>{coupon}</code> — <?php esc_html_e( 'the coupon code of the bar (Offers tab)', 'runline' ); ?></li>
			<li><code>{countdown}</code> — <?php esc_html_e( 'the countdown timer of the bar (Offers tab)', 'runline' ); ?></li>
			<li><code>{free_shipping_left}</code> — <?php esc_html_e( 'how much is left to free shipping (WooCommerce)', 'runline' ); ?></li>
			<li><code>{cart_total}</code>, <code>{cart_count}</code> — <?php esc_html_e( 'the total and the number of products in the cart of the visitor (WooCommerce)', 'runline' ); ?></li>
			<li><code>{visitor_country}</code> — <?php esc_html_e( 'the country of the visitor (with Cloudflare or a hosting that tells the country)', 'runline' ); ?></li>
			<li><code>{open_now}</code> — <?php esc_html_e( '"Open now" or "Closed now" by the opening hours you set in the Content tab', 'runline' ); ?></li>
			<li><code>{delivery_date}</code> — <?php esc_html_e( 'the next delivery date: "today", "tomorrow" or the date (with Dayslot, our free plugin for WooCommerce delivery dates)', 'runline' ); ?></li>
			<li><code>{pickup_date}</code> — <?php esc_html_e( 'the next pickup date (with Dayslot)', 'runline' ); ?></li>
			<li><code>{places_left}</code> — <?php esc_html_e( 'delivery places left on the next delivery date, shown only when there are 5 or fewer (with Dayslot)', 'runline' ); ?></li>
		</ul>

		<h2><?php esc_html_e( 'Questions', 'runline' ); ?></h2>
		<?php foreach ( $faq as $question => $answer ) : ?>
			<h3><?php echo esc_html( $question ); ?></h3>
			<p><?php echo esc_html( $answer ); ?></p>
		<?php endforeach; ?>

		<h2><?php esc_html_e( 'Need more help?', 'runline' ); ?></h2>
		<p><?php esc_html_e( 'Ask in the support forum: we answer every question. Runline is free, with no paid version — a short review helps other people find it.', 'runline' ); ?></p>
		<p>
			<a class="button" href="<?php echo esc_url( RUNLINE_SUPPORT_URL ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Support forum', 'runline' ); ?></a>
			<a class="button" href="<?php echo esc_url( RUNLINE_REVIEW_URL ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Leave a review', 'runline' ); ?></a>
			<a class="button" href="<?php echo esc_url( RUNLINE_SITE_URL ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Runline by Creonix', 'runline' ); ?></a>
		</p>

		<h2><?php esc_html_e( 'More plugins by Creonix', 'runline' ); ?></h2>
		<div class="card runline-more">
			<h3>Dayslot</h3>
			<p><?php esc_html_e( 'Let customers choose the date and time of delivery or pickup — or of an event — right in the WooCommerce checkout.', 'runline' ); ?></p>
			<p><a class="button" href="<?php echo esc_url( RUNLINE_DAYSLOT_URL ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Learn more', 'runline' ); ?></a></p>
		</div>
	</div>
	<?php
}

/* Settings → Privacy: a text for the privacy policy of the site. */
add_action(
	'admin_init',
	function () {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}
		$text = '<p class="privacy-policy-tutorial">' . esc_html__( 'Runline adds announcement bars to the site. Here is what it stores and shows; copy what fits your site.', 'runline' ) . '</p>'
			. '<p><strong class="privacy-policy-tutorial">' . esc_html__( 'Suggested text:', 'runline' ) . '</strong> '
			. esc_html__( 'When you subscribe with the form in an announcement bar, we keep your e-mail address, the date, the bar you used and, if the form asks for your consent, its text and the time you gave it. If the form is connected to an e-mail service (such as Mailchimp, MailerLite or Brevo), your address is also sent to that service.', 'runline' ) . '</p>'
			. '<p>' . esc_html__( 'We count how many times each announcement bar is shown and clicked, per day. These numbers contain no cookies, no IP addresses and nothing that identifies you. To count a view only once, your browser keeps a note for the length of your visit (session storage).', 'runline' ) . '</p>'
			. '<p>' . esc_html__( 'Against fake clicks and views, the site keeps for one day a scrambled code made from your IP address and browser name (not the address itself), with the times you saw or clicked a bar.', 'runline' ) . '</p>'
			. '<p>' . esc_html__( 'A bar can remember in your browser that you closed it, so it stays hidden.', 'runline' ) . '</p>'
			. '<p>' . esc_html__( 'If the "Recent orders" messages are on, the bar shows recent orders of our shop: the product, how long ago, and — as set by us — the first letter of the first name, the first name, or the city of the buyer.', 'runline' ) . '</p>';
		wp_add_privacy_policy_content( 'Runline', wp_kses_post( $text ) );
	}
);

/* Links in the list of plugins. */
add_filter(
	'plugin_row_meta',
	function ( $links, $file ) {
		if ( plugin_basename( RUNLINE_FILE ) === $file ) {
			$links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=runline-help' ) ) . '">' . esc_html__( 'Help', 'runline' ) . '</a>';
			$links[] = '<a href="' . esc_url( RUNLINE_SUPPORT_URL ) . '" target="_blank" rel="noopener">' . esc_html__( 'Support', 'runline' ) . '</a>';
			$links[] = '<a href="' . esc_url( RUNLINE_REVIEW_URL ) . '" target="_blank" rel="noopener">' . esc_html__( 'Rate Runline ★★★★★', 'runline' ) . '</a>';
		}
		return $links;
	},
	10,
	2
);

/**
 * When Runline was first used here (for the review request). Set on activation, or now for older installs.
 */
function runline_installed_at() {
	$time = (int) get_option( 'runline_installed' );
	if ( ! $time ) {
		$time = time();
		update_option( 'runline_installed', $time, false );
	}
	return $time;
}

add_action(
	'runline_install',
	function () {
		runline_installed_at();
		set_transient( 'runline_welcome', 1, DAY_IN_SECONDS );
	}
);

/**
 * Which notice an admin sees now: "welcome" (after activation, until a bar is made or the notice is closed),
 * "review" (two weeks after the start, with a bar switched on) or "".
 *
 * @param string $screen ID of the admin screen.
 */
function runline_notice_now( $screen ) {
	if ( ! current_user_can( 'manage_options' ) || ( 'toplevel_page_' . RUNLINE_PAGE === $screen && isset( $_GET['bar'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only reads which screen this is.
		return '';
	}
	$user = get_current_user_id();
	if ( 'plugins' === $screen && get_transient( 'runline_welcome' ) && ! get_user_meta( $user, 'runline_welcome_done', true ) ) {
		$bars = get_posts(
			array(
				'post_type'      => RUNLINE_POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
		if ( ! $bars ) {
			return 'welcome';
		}
	}
	// Screens of Runline (the IDs of sub-pages start with the translated menu name, so only the slug is checked).
	if ( 'toplevel_page_' . RUNLINE_PAGE !== $screen && ! preg_match( '/_page_runline-(settings|help|subscribers)$/', $screen ) ) {
		return '';
	}
	$later = (int) get_user_meta( $user, 'runline_review_later', true );
	if ( get_user_meta( $user, 'runline_review_done', true ) || $later > time() || time() - runline_installed_at() < 14 * DAY_IN_SECONDS ) {
		return '';
	}
	$on = get_posts(
		array(
			'post_type'      => RUNLINE_POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'meta_key'       => RUNLINE_ACTIVE_META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		)
	);
	return $on ? 'review' : '';
}

add_action(
	'admin_notices',
	function () {
		$screen = get_current_screen();
		$notice = $screen ? runline_notice_now( $screen->id ) : '';
		if ( ! $notice ) {
			return;
		}
		$answer = function ( $choice ) {
			return wp_nonce_url(
				add_query_arg(
					array(
						'action' => 'runline_notice',
						'choice' => $choice,
					),
					admin_url( 'admin-post.php' )
				),
				'runline_notice'
			);
		};
		if ( 'welcome' === $notice ) {
			?>
			<div class="notice notice-success runline-notice">
				<p><strong><?php esc_html_e( 'Runline is ready.', 'runline' ); ?></strong> <?php esc_html_e( 'Pick one of 100+ designs and put your first bar on the site in two minutes.', 'runline' ); ?></p>
				<p>
					<a class="button button-primary" href="<?php echo esc_url( runline_admin_url( 'new' ) ); ?>"><?php esc_html_e( 'Create your first bar', 'runline' ); ?></a>
					<a class="button-link" href="<?php echo esc_url( $answer( 'welcome' ) ); ?>"><?php esc_html_e( 'Close', 'runline' ); ?></a>
				</p>
			</div>
			<?php
			return;
		}
		?>
		<div class="notice notice-info runline-notice">
			<p><?php esc_html_e( 'You have been using Runline for a while — we hope it helps. Runline is free; a short review on WordPress.org helps other people find it and keeps it free.', 'runline' ); ?></p>
			<p>
				<a class="button button-primary" href="<?php echo esc_url( $answer( 'review' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Leave a review', 'runline' ); ?></a>
				<a class="button" href="<?php echo esc_url( $answer( 'later' ) ); ?>"><?php esc_html_e( 'Maybe later', 'runline' ); ?></a>
				<a class="button-link" href="<?php echo esc_url( $answer( 'done' ) ); ?>"><?php esc_html_e( 'I already did', 'runline' ); ?></a>
			</p>
		</div>
		<?php
	}
);

/* Answers to the notices: remembered per admin. */
add_action(
	'admin_post_runline_notice',
	function () {
		check_admin_referer( 'runline_notice' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You cannot do this.', 'runline' ) );
		}
		$user   = get_current_user_id();
		$choice = isset( $_GET['choice'] ) ? sanitize_key( $_GET['choice'] ) : '';
		if ( 'welcome' === $choice ) {
			update_user_meta( $user, 'runline_welcome_done', 1 );
		} elseif ( 'later' === $choice ) {
			update_user_meta( $user, 'runline_review_later', time() + 30 * DAY_IN_SECONDS );
		} elseif ( 'done' === $choice || 'review' === $choice ) {
			update_user_meta( $user, 'runline_review_done', 1 );
		}
		if ( 'review' === $choice ) {
			wp_redirect( RUNLINE_REVIEW_URL ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- the review page on WordPress.org.
			exit;
		}
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : runline_admin_url() );
		exit;
	}
);
