<?php
/**
 * Designs added in 1.5: gradients, ribbons, Google fonts, button, coupon, signup, timers, review cards.
 * Merged into runline_designs(); every one passes WCAG AA contrast (tests/run-tests.php), both ends of a gradient too.
 */

defined( 'ABSPATH' ) || exit;

/**
 * A review message: text + who wrote it.
 */
function runline_design_review( $text, $author ) {
	$item           = runline_design_item( '', $text );
	$item['author'] = $author;
	return $item;
}

/**
 * Date and time N days from now in the site time zone, for timers of designs.
 */
function runline_design_in_days( $days ) {
	return wp_date( 'Y-m-d\TH:i', time() + $days * DAY_IN_SECONDS );
}

/**
 * The 40 designs of 1.5.
 */
function runline_more_designs() {
	$home   = home_url( '/' );
	$button = function ( $text, $bg, $color, $radius = 4 ) use ( $home ) {
		return array(
			'on'     => true,
			'text'   => $text,
			'url'    => $home,
			'bg'     => $bg,
			'color'  => $color,
			'radius' => $radius,
		);
	};
	$timer  = function ( $days, $bg, $color, $place = 'right' ) {
		return array(
			'on'    => true,
			'end'   => runline_design_in_days( $days ),
			'place' => $place,
			'bg'    => $bg,
			'color' => $color,
		);
	};
	$item   = 'runline_design_item';

	return array(
		// Shop & sales.
		array(
			'id'       => 'summer-sale',
			'name'     => __( 'Summer sale', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#c2410c',
				'bg2'         => '#be185d',
				'color'       => '#ffffff',
				'font'        => 'g:Poppins',
				'font_weight' => '700',
				'separator'   => '☀',
				'button'      => $button( __( 'Shop now', 'runline' ), '#ffffff', '#9d174d', 20 ),
				'items'       => array(
					$item( '☀️', __( 'Summer sale: up to −40%', 'runline' ) ),
					$item( '↩️', __( 'Free returns all summer', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'cyber-monday',
			'name'     => __( 'Cyber Monday', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#0f172a',
				'bg2'         => '#1e1b4b',
				'color'       => '#67e8f9',
				'font'        => 'g:Space Grotesk',
				'font_weight' => '700',
				'uppercase'   => true,
				'separator'   => '//',
				'items'       => array(
					$item( '⚡', __( 'Cyber Monday: −35% on everything', 'runline' ) ),
					$item( '💻', __( 'Online only, today', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'last-chance',
			'name'     => __( 'Last chance (timer)', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#7f1d1d',
				'color'       => '#ffffff',
				'label'       => __( 'LAST CHANCE', 'runline' ),
				'label_bg'    => '#ffffff',
				'label_color' => '#7f1d1d',
				'font_weight' => '700',
				'countdown'   => $timer( 3, '#fde047', '#7f1d1d' ),
				'items'       => array(
					$item( '⏰', __( 'The sale ends soon — don\'t miss it', 'runline' ) ),
					$item( '🛍️', __( 'Up to −50% on bestsellers', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'bogo',
			'name'     => __( 'Buy one, get one', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'               => '#fef08a',
				'color'            => '#713f12',
				'font'             => 'g:Bebas Neue',
				'font_size'        => 22,
				'font_size_mobile' => 18,
				'height'           => 48,
				'uppercase'        => true,
				'separator'        => '✦',
				'items'            => array(
					$item( '', __( 'Buy one, get one free', 'runline' ) ),
					$item( '', __( 'This weekend only', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'clearance',
			'name'     => __( 'Clearance', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'           => '#ffffff',
				'color'        => '#b91c1c',
				'border_width' => 2,
				'border_color' => '#b91c1c',
				'font_weight'  => '800',
				'uppercase'    => true,
				'separator'    => '•',
				'items'        => array(
					$item( '🏷️', __( 'Clearance: everything must go', 'runline' ) ),
					$item( '', __( 'Up to −70%', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'gift-cards',
			'name'     => __( 'Gift cards', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'        => '#ecfeff',
				'color'     => '#155e75',
				'font'      => 'g:Nunito',
				'separator' => '·',
				'button'    => $button( __( 'Buy a gift card', 'runline' ), '#155e75', '#ffffff', 20 ),
				'items'     => array(
					$item( '🎁', __( 'Gift cards for any amount', 'runline' ) ),
					$item( '✉️', __( 'Delivered by e-mail in a minute', 'runline' ) ),
				),
			),
		),
		// Coupons & signups.
		array(
			'id'       => 'coupon-welcome',
			'name'     => __( 'Welcome coupon', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'     => '#1e293b',
				'color'  => '#ffffff',
				'coupon' => array(
					'on'   => true,
					'code' => 'WELCOME10',
				),
				'items'  => array(
					$item( '👋', __( 'New here? Take 10% off your first order', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'coupon-gold',
			'name'     => __( 'Gold coupon', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'          => '#111111',
				'bg2'         => '#3f3f46',
				'color'       => '#fde68a',
				'font'        => 'g:Playfair Display',
				'font_size'   => 16,
				'font_weight' => '700',
				'coupon'      => array(
					'on'    => true,
					'code'  => 'GOLD20',
					'bg'    => '#fde68a',
					'color' => '#111111',
				),
				'items'       => array(
					$item( '✨', __( 'VIP week: −20% with code GOLD20', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'newsletter-dark',
			'name'     => __( 'Newsletter (dark)', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'       => '#111827',
				'color'    => '#ffffff',
				'mode'     => 'static',
				'closable' => true,
				'signup'   => array( 'on' => true ),
				'button'   => array(
					'on'    => false,
					'bg'    => '#facc15',
					'color' => '#111827',
				),
				'items'    => array(
					$item( '📬', __( 'Get our best deals first', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'newsletter-light',
			'name'     => __( 'Newsletter (light)', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'     => '#f1f5f9',
				'color'  => '#0f172a',
				'mode'   => 'static',
				'font'   => 'g:Inter',
				'signup' => array( 'on' => true ),
				'button' => array(
					'on'    => false,
					'bg'    => '#0f172a',
					'color' => '#ffffff',
				),
				'items'  => array(
					$item( '✉️', __( 'Join our newsletter: news and offers once a week', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'app-download',
			'name'     => __( 'Get the app', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'     => '#000000',
				'color'  => '#ffffff',
				'font'   => 'g:DM Sans',
				'button' => $button( __( 'Get the app', 'runline' ), '#ffffff', '#000000', 20 ),
				'items'  => array(
					$item( '📱', __( 'Our app is here — order in two taps', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'book-a-call',
			'name'     => __( 'Book a call', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'     => '#1d4ed8',
				'color'  => '#ffffff',
				'mode'   => 'static',
				'button' => $button( __( 'Book a call', 'runline' ), '#ffffff', '#1d4ed8' ),
				'items'  => array(
					$item( '📞', __( 'Free 15-minute consultation', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'webinar',
			'name'     => __( 'Webinar', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'        => '#4c1d95',
				'bg2'       => '#6d28d9',
				'color'     => '#ffffff',
				'font'      => 'g:Montserrat',
				'countdown' => $timer( 5, '#ffffff', '#4c1d95', 'left' ),
				'button'    => $button( __( 'Register', 'runline' ), '#facc15', '#1e1b4b' ),
				'items'     => array(
					$item( '🎥', __( 'Free webinar: grow your online shop', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'offer-timer',
			'name'     => __( 'Offer with a timer', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'          => '#b91c1c',
				'color'       => '#ffffff',
				'mode'        => 'static',
				'font_weight' => '700',
				'countdown'   => array_merge( $timer( 2, '#ffffff', '#b91c1c' ), array( 'place' => 'text' ) ),
				'items'       => array(
					$item( '⏰', __( 'The offer ends in {countdown}', 'runline' ) ),
				),
			),
		),
		// Reviews & trust.
		array(
			'id'       => 'reviews-cards',
			'name'     => __( 'Review cards', 'runline' ),
			'category' => 'reviews',
			'settings' => array(
				'bg'        => '#fdf2f8',
				'color'     => '#831843',
				'style'     => 'cards',
				'height'    => 90,
				'speed'     => 40,
				'separator' => '',
				'closable'  => false,
				'items'     => array(
					runline_design_review( __( 'Beautiful, and delivered on time!', 'runline' ), __( 'Anna, Kraków', 'runline' ) ),
					runline_design_review( __( 'The best service in town.', 'runline' ), __( 'Mark, Warsaw', 'runline' ) ),
					runline_design_review( __( 'I order here every month.', 'runline' ), __( 'Julia, Gdańsk', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'reviews-stars',
			'name'     => __( 'Five stars', 'runline' ),
			'category' => 'reviews',
			'settings' => array(
				'bg'        => '#fffbeb',
				'color'     => '#78350f',
				'separator' => '•',
				'items'     => array(
					runline_design_review( __( '★★★★★ “Fast and friendly”', 'runline' ), __( 'Anna', 'runline' ) ),
					runline_design_review( __( '★★★★★ “Exactly as in the photos”', 'runline' ), __( 'Tom', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'trust-badges',
			'name'     => __( 'Trust badges', 'runline' ),
			'category' => 'reviews',
			'settings' => array(
				'bg'               => '#f8fafc',
				'color'            => '#0f172a',
				'mode'             => 'static',
				'font_size'        => 13,
				'font_size_mobile' => 12,
				'gap'              => 24,
				'separator'        => '',
				'closable'         => false,
				'items'            => array(
					$item( '🔒', __( 'Secure payment', 'runline' ) ),
					$item( '🚚', __( 'Fast delivery', 'runline' ) ),
					$item( '↩️', __( '30-day returns', 'runline' ) ),
					$item( '⭐', __( '4.9 from 2,000 reviews', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'in-the-press',
			'name'     => __( 'In the press', 'runline' ),
			'category' => 'reviews',
			'settings' => array(
				'bg'          => '#ffffff',
				'color'       => '#111827',
				'label'       => __( 'AS SEEN IN', 'runline' ),
				'label_bg'    => '#111827',
				'label_color' => '#ffffff',
				'font'        => 'g:Playfair Display',
				'font_size'   => 18,
				'height'      => 52,
				'gap'         => 56,
				'separator'   => '',
				'closable'    => false,
				'items'       => array(
					$item( '', __( 'Daily News', 'runline' ) ),
					$item( '', __( 'Style Magazine', 'runline' ) ),
					$item( '', __( 'Tech Weekly', 'runline' ) ),
					$item( '', __( 'City Radio', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'partners',
			'name'     => __( 'Partners strip', 'runline' ),
			'category' => 'reviews',
			'settings' => array(
				'bg'               => '#ffffff',
				'color'            => '#111827',
				'font'             => 'g:Oswald',
				'font_size'        => 20,
				'font_size_mobile' => 16,
				'uppercase'        => true,
				'height'           => 56,
				'gap'              => 64,
				'separator'        => '✦',
				'closable'         => false,
				'items'            => array(
					$item( '', __( 'Northwind', 'runline' ) ),
					$item( '', __( 'Bluebird', 'runline' ) ),
					$item( '', __( 'Greenleaf', 'runline' ) ),
					$item( '', __( 'Stonebridge', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'social-proof',
			'name'     => __( 'Social proof', 'runline' ),
			'category' => 'reviews',
			'settings' => array(
				'bg'        => '#fff7ed',
				'color'     => '#9a3412',
				'mode'      => 'fade',
				'interval'  => 4,
				'separator' => '',
				'items'     => array(
					$item( '🔥', __( '128 people bought this today', 'runline' ) ),
					$item( '⭐', __( 'Rated 4.9 out of 5', 'runline' ) ),
					$item( '👀', __( '23 people are looking right now', 'runline' ) ),
				),
			),
		),
		// Holidays.
		array(
			'id'       => 'mothers-day',
			'name'     => __( 'Mother\'s Day', 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'        => '#fce7f3',
				'color'     => '#9d174d',
				'font'      => 'g:Playfair Display',
				'font_size' => 16,
				'separator' => '♥',
				'items'     => array(
					$item( '💐', __( 'Mother\'s Day: flowers and gifts she will love', 'runline' ) ),
					$item( '🚚', __( 'Delivery on the day', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'fathers-day',
			'name'     => __( 'Father\'s Day', 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'        => '#e0f2fe',
				'color'     => '#075985',
				'font'      => 'g:Oswald',
				'uppercase' => true,
				'separator' => '•',
				'items'     => array(
					$item( '👔', __( 'Father\'s Day gifts', 'runline' ) ),
					$item( '🎁', __( 'Free gift wrapping', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'back-to-school',
			'name'     => __( 'Back to school', 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'          => '#fef9c3',
				'color'       => '#713f12',
				'font'        => 'g:Rubik',
				'font_weight' => '600',
				'separator'   => '✏',
				'items'       => array(
					$item( '🎒', __( 'Back to school: −20% on supplies', 'runline' ) ),
					$item( '📚', __( 'Everything for the new school year', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'holiday-closed',
			'name'     => __( 'Closed for holidays', 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'        => '#ecfeff',
				'color'     => '#155e75',
				'mode'      => 'static',
				'separator' => '',
				'items'     => array(
					$item( '🏖️', __( 'We are on holiday from 1 to 15 August — orders ship after we are back', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'singles-day',
			'name'     => __( 'Singles\' Day 11.11', 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'               => '#111111',
				'color'            => '#f472b6',
				'font'             => 'g:Bebas Neue',
				'font_size'        => 24,
				'font_size_mobile' => 18,
				'height'           => 52,
				'separator'        => '11.11',
				'items'            => array(
					$item( '', __( 'Singles\' Day: −11% on everything', 'runline' ) ),
					$item( '', __( 'Only on 11.11', 'runline' ) ),
				),
			),
		),
		// News & blog.
		array(
			'id'       => 'weather-alert',
			'name'     => __( 'Alert', 'runline' ),
			'category' => 'news',
			'settings' => array(
				'bg'          => '#fef3c7',
				'color'       => '#78350f',
				'label'       => __( 'ALERT', 'runline' ),
				'label_bg'    => '#92400e',
				'label_color' => '#ffffff',
				'font_weight' => '600',
				'items'       => array(
					$item( '⚠️', __( 'Delivery may be late because of the weather', 'runline' ) ),
					$item( '📞', __( 'Questions? Call us 9:00–17:00', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'scores',
			'name'     => __( 'Scores', 'runline' ),
			'category' => 'news',
			'settings' => array(
				'bg'          => '#14532d',
				'color'       => '#ffffff',
				'mode'        => 'vertical',
				'font'        => 'g:Roboto',
				'font_weight' => '700',
				'items'       => array(
					$item( '⚽', __( 'Home FC 2 : 1 Away United', 'runline' ) ),
					$item( '🏀', __( 'City Hawks 98 : 91 River Bulls', 'runline' ) ),
					$item( '🎾', __( 'Final today at 18:00', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'tech-headlines',
			'name'     => __( 'Tech headlines', 'runline' ),
			'category' => 'news',
			'settings' => array(
				'bg'          => '#0b1120',
				'color'       => '#e2e8f0',
				'label'       => __( 'TECH', 'runline' ),
				'label_bg'    => '#38bdf8',
				'label_color' => '#0b1120',
				'font'        => 'mono',
				'font_size'   => 14,
				'separator'   => '>',
				'items'       => array(
					$item( '', __( 'New version released', 'runline' ) ),
					$item( '', __( 'How we made the site 2× faster', 'runline' ) ),
				),
			),
		),
		// Landing pages.
		array(
			'id'       => 'ribbon-tilted',
			'name'     => __( 'Tilted ribbon', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'               => '#facc15',
				'color'            => '#111111',
				'ribbon'           => 'tilted',
				'tilt'             => -3,
				'position'         => 'manual',
				'font'             => 'g:Anton',
				'font_size'        => 28,
				'font_size_mobile' => 20,
				'uppercase'        => true,
				'height'           => 64,
				'gap'              => 48,
				'separator'        => '✦',
				'closable'         => false,
				'items'            => array(
					$item( '', __( 'New', 'runline' ) ),
					$item( '', __( 'Fresh', 'runline' ) ),
					$item( '', __( 'Bold', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'ribbons-crossed',
			'name'     => __( 'Crossed ribbons', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'               => '#111111',
				'color'            => '#ffffff',
				'ribbon'           => 'crossed',
				'tilt'             => -4,
				'ribbon2'          => '#facc15',
				'position'         => 'manual',
				'font'             => 'g:Bebas Neue',
				'font_size'        => 30,
				'font_size_mobile' => 22,
				'height'           => 60,
				'gap'              => 48,
				'separator'        => '★',
				'closable'         => false,
				'items'            => array(
					$item( '', __( 'Design', 'runline' ) ),
					$item( '', __( 'Build', 'runline' ) ),
					$item( '', __( 'Launch', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'gradient-sunset',
			'name'     => __( 'Sunset gradient', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'          => '#fda4af',
				'bg2'         => '#fde68a',
				'color'       => '#1f2937',
				'font'        => 'g:Poppins',
				'font_weight' => '600',
				'separator'   => '✺',
				'items'       => array(
					$item( '', __( 'Made with love', 'runline' ) ),
					$item( '', __( 'Shipped worldwide', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'gradient-ocean',
			'name'     => __( 'Ocean gradient', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'          => '#0e7490',
				'bg2'         => '#1d4ed8',
				'color'       => '#ffffff',
				'font'        => 'g:Manrope',
				'font_weight' => '700',
				'separator'   => '〜',
				'items'       => array(
					$item( '🌊', __( 'Dive into the new season', 'runline' ) ),
					$item( '', __( 'Free shipping over $50', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'neon',
			'name'     => __( 'Neon', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'               => '#0a0a0a',
				'color'            => '#22d3ee',
				'font'             => 'g:Bebas Neue',
				'font_size'        => 26,
				'font_size_mobile' => 20,
				'height'           => 56,
				'shadow'           => 'strong',
				'separator'        => '✚',
				'items'            => array(
					$item( '', __( 'Open late tonight', 'runline' ) ),
					$item( '', __( 'Live music from 21:00', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'outline-pill',
			'name'     => __( 'Outline pill', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'           => '#ffffff',
				'color'        => '#111111',
				'border_width' => 2,
				'border_color' => '#111111',
				'radius'       => 40,
				'width'        => 'boxed',
				'max_width'    => 900,
				'separator'    => '•',
				'items'        => array(
					$item( '', __( 'Free shipping over $50', 'runline' ) ),
					$item( '', __( 'New arrivals every Friday', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'floating-pill',
			'name'     => __( 'Floating pill', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'        => '#111827',
				'color'     => '#ffffff',
				'radius'    => 40,
				'width'     => 'boxed',
				'max_width' => 720,
				'shadow'    => 'soft',
				'separator' => '·',
				'items'     => array(
					$item( '✨', __( 'New collection is live — shop now', 'runline' ) ),
					$item( '🎁', __( 'Free gift card with every order', 'runline' ) ),
				),
			),
		),
		// Minimal.
		array(
			'id'       => 'minimal-mono',
			'name'     => __( 'Minimal mono', 'runline' ),
			'category' => 'minimal',
			'settings' => array(
				'bg'               => '#ffffff',
				'color'            => '#111111',
				'font'             => 'mono',
				'font_size'        => 12,
				'font_size_mobile' => 12,
				'height'           => 30,
				'uppercase'        => true,
				'separator'        => '/',
				'border_width'     => 1,
				'border_color'     => '#111111',
				'items'            => array(
					$item( '', __( 'Free shipping over $50', 'runline' ) ),
					$item( '', __( 'Easy returns', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'minimal-serif',
			'name'     => __( 'Minimal serif', 'runline' ),
			'category' => 'minimal',
			'settings' => array(
				'bg'               => '#faf7f2',
				'color'            => '#3f3a33',
				'font'             => 'g:Merriweather',
				'font_size'        => 14,
				'font_size_mobile' => 13,
				'font_weight'      => '400',
				'height'           => 34,
				'separator'        => '—',
				'items'            => array(
					$item( '', __( 'Handmade in small batches', 'runline' ) ),
					$item( '', __( 'Delivery in 1–2 days', 'runline' ) ),
				),
			),
		),
		// Flowers, cafés, events.
		array(
			'id'       => 'restaurant',
			'name'     => __( 'Restaurant', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'        => '#7c2d12',
				'color'     => '#ffedd5',
				'font'      => 'g:Lobster',
				'font_size' => 18,
				'separator' => '•',
				'button'    => $button( __( 'Order now', 'runline' ), '#ffedd5', '#7c2d12', 20 ),
				'items'     => array(
					$item( '🍕', __( 'Free delivery over $30', 'runline' ) ),
					$item( '🕘', __( 'Order until 21:00', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'beauty-salon',
			'name'     => __( 'Beauty salon', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#fdf2f8',
				'color'       => '#9d174d',
				'font'        => 'g:Raleway',
				'font_weight' => '600',
				'mode'        => 'static',
				'button'      => $button( __( 'Book now', 'runline' ), '#9d174d', '#ffffff', 20 ),
				'items'       => array(
					$item( '💅', __( 'Book your visit online — free slots this week', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'event-tickets',
			'name'     => __( 'Event tickets', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#312e81',
				'color'       => '#ffffff',
				'font'        => 'g:Work Sans',
				'font_weight' => '600',
				'countdown'   => $timer( 10, '#facc15', '#312e81' ),
				'button'      => $button( __( 'Get tickets', 'runline' ), '#ffffff', '#312e81' ),
				'items'       => array(
					$item( '🎟️', __( 'Tickets on sale now', 'runline' ) ),
				),
			),
		),
	);
}
