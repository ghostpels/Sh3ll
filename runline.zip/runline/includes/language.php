<?php
/**
 * Language of Runline chosen by hand (Runline → Settings): the admin screens of Runline — editor, list, help, block —
 * can speak another language than WordPress. What visitors see stays in the language of the site.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Languages Runline ships (locale => name in that language).
 */
function runline_languages() {
	return array(
		'en_US' => 'English',
		'cs_CZ' => 'Čeština',
		'de_DE' => 'Deutsch',
		'es_ES' => 'Español',
		'fr_FR' => 'Français',
		'it_IT' => 'Italiano',
		'nl_NL' => 'Nederlands',
		'pl_PL' => 'Polski',
		'pt_BR' => 'Português do Brasil',
		'ru_RU' => 'Русский',
		'uk'    => 'Українська',
	);
}

/**
 * The chosen language when this request belongs to the admin of Runline, else "".
 */
function runline_chosen_language() {
	$lang = (string) runline_options()['language'];
	if ( '' === $lang || ! isset( runline_languages()[ $lang ] ) ) {
		return '';
	}
	if ( is_admin() ) {
		return $lang;
	}
	// Requests of the admin app (REST API of Runline), not the public ones of visitors (signup, statistics, country).
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? rawurldecode( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) ) : '';
	if ( preg_match( '#/runline/v1/(?!subscribe|track|country)#', $uri ) ) {
		return $lang;
	}
	return '';
}

add_action(
	'init',
	function () {
		$lang = runline_chosen_language();
		if ( '' === $lang ) {
			return;
		}
		// Not reloadable: WordPress must not load the language pack of the site language again by itself.
		unload_textdomain( 'runline' );
		$own = RUNLINE_DIR . 'languages/runline-' . $lang . '.mo';
		if ( 'en_US' !== $lang && file_exists( $own ) ) {
			// Loaded under the current locale of WordPress: that switches only Runline, not the whole admin.
			load_textdomain( 'runline', $own, determine_locale() );
		}
	},
	2
);

// Translations of the scripts (admin app, block): the files of the chosen language; none for English.
add_filter(
	'load_script_translation_file',
	function ( $file, $handle, $domain ) {
		$lang = 'runline' === $domain ? runline_chosen_language() : '';
		if ( '' === $lang || ! $file ) {
			return $file;
		}
		if ( 'en_US' === $lang ) {
			return RUNLINE_DIR . 'languages/none.json';
		}
		if ( preg_match( '/^runline-[a-z]{2,3}(?:_[A-Za-z0-9]+)*-(.+\.json)$/', basename( $file ), $m ) ) {
			return RUNLINE_DIR . 'languages/runline-' . $lang . '-' . $m[1];
		}
		return $file;
	},
	10,
	3
);
