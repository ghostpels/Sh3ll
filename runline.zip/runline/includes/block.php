<?php
/**
 * Block "Runline bar" (runline/blocks/bar/block.json, editor script runline/src/block → runline/build/block).
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'runline_register_block' );

/**
 * On the site the block needs only its server render: the editor script and styles are not registered there.
 *
 * @param array $metadata Block metadata from block.json.
 */
function runline_block_metadata( $metadata ) {
	if ( isset( $metadata['name'] ) && 'runline/bar' === $metadata['name'] && ! is_admin() ) {
		unset( $metadata['editorScript'], $metadata['editorStyle'] );
	}
	return $metadata;
}
add_filter( 'block_type_metadata', 'runline_block_metadata' );

function runline_register_block() {
	if ( ! file_exists( RUNLINE_DIR . 'build/block/index.asset.php' ) ) {
		return;
	}
	// The editor style "runline" (the bar itself) must exist before the block is registered — in the admin only:
	// pages of the site register nothing until a bar is really printed.
	if ( is_admin() ) {
		runline_register_assets();
	}
	register_block_type(
		RUNLINE_DIR . 'blocks/bar',
		array( 'render_callback' => 'runline_render_block' )
	);

	$handle = generate_block_asset_handle( 'runline/bar', 'editorScript' );
	$script = wp_scripts()->query( $handle, 'registered' );
	if ( ! $script ) {
		return;
	}
	// runline.js sets the speed of the preview (window.runlineInit).
	$script->deps[] = 'runline';
	wp_set_script_translations( $handle, 'runline', RUNLINE_DIR . 'languages' );
	wp_add_inline_script(
		$handle,
		'window.runlineBlock = ' . wp_json_encode(
			array(
				'fonts'      => runline_font_stacks(),
				'maxItems'   => runline_max_items(),
				'tzOffset'   => (int) ( wp_timezone()->getOffset( new DateTime( 'now', wp_timezone() ) ) / 60 ),
				'daysFormat' => runline_countdown_days_format(),
				'vars'       => runline_text_vars( true ),
				'shipping'   => array(
					'auto' => runline_free_shipping_threshold( runline_default_settings() ),
					'fmt'  => runline_price_format(),
				),
				'adminUrl'   => admin_url( 'admin.php?page=runline' ),
				'canManage'  => current_user_can( 'manage_options' ),
			)
		) . ';',
		'before'
	);
}

/**
 * The block on the site: the same bar as the shortcode, in the block wrapper (alignment, margin).
 *
 * @param array $attributes Block attributes.
 */
function runline_render_block( $attributes ) {
	$html = runline_shortcode( array( 'id' => isset( $attributes['barId'] ) ? (int) $attributes['barId'] : 0 ) );
	if ( '' === $html ) {
		return '';
	}
	return '<div ' . get_block_wrapper_attributes() . '>' . $html . '</div>';
}
