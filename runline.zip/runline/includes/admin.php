<?php
/**
 * Admin: the Runline menu with one React page (list of bars + editor, runline/src → runline/build), the small
 * Settings page, and redirects from the classic post screens of the bar post type.
 */

defined( 'ABSPATH' ) || exit;

define( 'RUNLINE_PAGE', 'runline' );

add_action(
	'admin_menu',
	function () {
		add_menu_page(
			__( 'Runline', 'runline' ),
			__( 'Runline', 'runline' ),
			'manage_options',
			RUNLINE_PAGE,
			'runline_app_page',
			'dashicons-megaphone',
			59
		);
		add_submenu_page( RUNLINE_PAGE, __( 'Bars', 'runline' ), __( 'All bars', 'runline' ), 'manage_options', RUNLINE_PAGE, 'runline_app_page' );
		add_submenu_page( RUNLINE_PAGE, __( 'Runline settings', 'runline' ), __( 'Settings', 'runline' ), 'manage_options', 'runline-settings', 'runline_settings_page' );
	}
);

/**
 * Link to the admin app: the list, or the editor of one bar ("new" = a new bar).
 *
 * @param int|string $bar Bar ID, "new" or 0 for the list.
 */
function runline_admin_url( $bar = 0 ) {
	$args = array( 'page' => RUNLINE_PAGE );
	if ( $bar ) {
		$args['bar'] = $bar;
	}
	return add_query_arg( $args, admin_url( 'admin.php' ) );
}

/**
 * The classic screens of the post type lead to the app.
 */
function runline_redirect_classic_screens() {
	global $typenow;
	$type = $typenow;
	$bar  = 0;
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- only reads where to go.
	if ( isset( $_GET['post'] ) ) {
		$bar  = absint( $_GET['post'] );
		$type = get_post_type( $bar );
	} elseif ( isset( $_GET['post_type'] ) ) {
		$type = sanitize_key( $_GET['post_type'] );
	}
	// phpcs:enable
	if ( RUNLINE_POST_TYPE !== $type ) {
		return;
	}
	if ( 'post-new.php' === $GLOBALS['pagenow'] ) {
		$bar = 'new';
	}
	wp_safe_redirect( runline_admin_url( $bar ) );
	exit;
}
add_action( 'load-edit.php', 'runline_redirect_classic_screens' );
add_action( 'load-post.php', 'runline_redirect_classic_screens' );
add_action( 'load-post-new.php', 'runline_redirect_classic_screens' );

/**
 * Public post types for the display rules: name => label.
 */
function runline_admin_post_types() {
	$types = array();
	foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $type ) {
		if ( 'attachment' !== $type->name ) {
			$types[ $type->name ] = $type->labels->name;
		}
	}
	return $types;
}

function runline_app_page() {
	// Notices of other plugins go above the app (WordPress moves them after .wp-header-end), not into its header.
	echo '<div class="wrap runline-wrap"><hr class="wp-header-end"><div id="runline-app"><p class="runline-loading">' . esc_html__( 'Loading…', 'runline' ) . '</p></div></div>';
}

add_action(
	'admin_enqueue_scripts',
	function ( $hook ) {
		if ( 'toplevel_page_' . RUNLINE_PAGE !== $hook ) {
			return;
		}
		$asset_file = RUNLINE_DIR . 'build/index.asset.php';
		if ( ! file_exists( $asset_file ) ) {
			return;
		}
		$asset = require $asset_file;

		// The bar itself (CSS + runline.js) for the live preview.
		runline_register_assets();
		wp_enqueue_style( 'runline' );
		wp_enqueue_media();

		wp_enqueue_script( 'runline-admin', RUNLINE_URL . 'build/index.js', array_merge( $asset['dependencies'], array( 'runline' ) ), $asset['version'], true );
		wp_enqueue_style( 'runline-admin', RUNLINE_URL . 'build/style-index.css', array( 'wp-components' ), $asset['version'] );
		wp_style_add_data( 'runline-admin', 'rtl', 'replace' );
		wp_set_script_translations( 'runline-admin', 'runline', RUNLINE_DIR . 'languages' );

		$choices = array();
		foreach ( array( 'direction', 'font', 'font_weight', 'position', 'width', 'align', 'cd_place', 'cd_after', 'cd_source', 'mode', 'style', 'source', 'products', 'mobile_layout', 'buyer_name', 'shadow', 'ribbon', 'service' ) as $key ) {
			foreach ( runline_choices( $key ) as $value => $label ) {
				$choices[ $key ][] = array(
					'value' => (string) $value,
					'label' => $label,
				);
			}
		}
		wp_add_inline_script(
			'runline-admin',
			'window.runlineAdmin = ' . wp_json_encode(
				array(
					'defaults'    => runline_default_settings(),
					'choices'     => $choices,
					'fonts'       => runline_font_stacks(),
					'maxItems'    => runline_max_items(),
					'ruleTypes'   => runline_rules_types(),
					'ruleGroups'  => runline_rules_groups(),
					'postTypes'   => runline_admin_post_types(),
					'roles'       => wp_roles()->get_names(),
					'languages'   => runline_rules_languages(),
					'timezone'    => wp_timezone_string(),
					'tzOffset'    => (int) ( wp_timezone()->getOffset( new DateTime( 'now', wp_timezone() ) ) / 60 ),
					'daysFormat'  => runline_countdown_days_format(),
					'vars'        => runline_text_vars( true ),
					'dayslotOn'   => runline_dayslot_on(),
					'dayslotEnd'  => runline_dayslot_deadline(),
					'dayslotUrl'  => RUNLINE_DAYSLOT_URL,
					'shipping'    => array(
						'auto' => runline_free_shipping_threshold( runline_default_settings() ),
						'fmt'  => runline_price_format(),
					),
					'woo'         => class_exists( 'WooCommerce' ),
					'stats'       => runline_stats_on(),
					'homeUrl'     => home_url( '/' ),
					'adminUrl'    => runline_admin_url(),
					'settingsUrl' => admin_url( 'admin.php?page=runline-settings' ),
					'designs'     => runline_designs(),
					'categories'  => runline_design_categories(),
					'lookKeys'    => RUNLINE_LOOK_KEYS,
					'dayslot'     => function_exists( 'runline_dayslot_hint' ) && runline_dayslot_hint() ? RUNLINE_DAYSLOT_URL : '',
				)
			) . ';',
			'before'
		);

		// The list of bars comes with the page, so it shows without waiting.
		$preload = array_reduce( array( '/' . RUNLINE_REST_NS . '/bars' ), 'rest_preload_api_request', array() );
		wp_add_inline_script(
			'wp-api-fetch',
			'wp.apiFetch.use( wp.apiFetch.createPreloadingMiddleware( ' . wp_json_encode( $preload ) . ' ) );',
			'after'
		);
	}
);

/**
 * Settings page: things for the whole plugin.
 */
add_action(
	'admin_init',
	function () {
		register_setting(
			'runline',
			'runline_options',
			array(
				'type'              => 'array',
				'sanitize_callback' => function ( $value ) {
					return array(
						'delete_data'    => ! empty( $value['delete_data'] ),
						'one_per_place'  => ! empty( $value['one_per_place'] ),
						'push_header'    => ! empty( $value['push_header'] ),
						'stats'          => ! empty( $value['stats'] ),
						'mailchimp_key'  => isset( $value['mailchimp_key'] ) ? sanitize_text_field( $value['mailchimp_key'] ) : '',
						'mailerlite_key' => isset( $value['mailerlite_key'] ) ? sanitize_text_field( $value['mailerlite_key'] ) : '',
						'brevo_key'      => isset( $value['brevo_key'] ) ? sanitize_text_field( $value['brevo_key'] ) : '',
						'kit_key'        => isset( $value['kit_key'] ) ? sanitize_text_field( $value['kit_key'] ) : '',
						'klaviyo_key'    => isset( $value['klaviyo_key'] ) ? sanitize_text_field( $value['klaviyo_key'] ) : '',
						'omnisend_key'   => isset( $value['omnisend_key'] ) ? sanitize_text_field( $value['omnisend_key'] ) : '',
						'webhook_key'    => isset( $value['webhook_key'] ) ? esc_url_raw( trim( $value['webhook_key'] ), array( 'https', 'http' ) ) : '',
						'analytics'      => ! empty( $value['analytics'] ),
						'language'       => isset( $value['language'] ) && isset( runline_languages()[ $value['language'] ] ) ? $value['language'] : '',
					);
				},
				'default'           => array(
					'delete_data'   => false,
					'one_per_place' => false,
					'push_header'   => false,
					'stats'         => true,
					'analytics'     => true,
				),
			)
		);
	}
);

function runline_settings_page() {
	$options = runline_options();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Runline settings', 'runline' ); ?></h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'runline' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="runline-language"><?php esc_html_e( 'Language of Runline', 'runline' ); ?></label></th>
					<td>
						<select id="runline-language" name="runline_options[language]">
							<option value=""><?php esc_html_e( 'Same as WordPress', 'runline' ); ?></option>
							<?php foreach ( runline_languages() as $locale => $name ) : ?>
								<option value="<?php echo esc_attr( $locale ); ?>" lang="<?php echo esc_attr( str_replace( '_', '-', $locale ) ); ?>" <?php selected( $options['language'], $locale ); ?>><?php echo esc_html( $name ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'The screens of Runline in the admin (editor, list of bars, help, block). What visitors see stays in the language of the site.', 'runline' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Several bars in one place', 'runline' ); ?></th>
					<td>
						<label><input type="checkbox" name="runline_options[one_per_place]" value="1" <?php checked( $options['one_per_place'] ); ?>> <?php esc_html_e( 'Show only one bar at the top and one at the bottom: the one with the highest priority that fits the page and the visitor', 'runline' ); ?></label>
						<p class="description"><?php esc_html_e( 'Off: all matching bars show one under another, in the order of their priority.', 'runline' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Fixed header of the theme', 'runline' ); ?></th>
					<td>
						<label><input type="checkbox" name="runline_options[push_header]" value="1" <?php checked( $options['push_header'] ); ?>> <?php esc_html_e( 'Move a fixed (sticky) header of the theme below the top bars', 'runline' ); ?></label>
						<p class="description"><?php esc_html_e( 'Switch this on if the header of your theme stays at the top while scrolling and covers the bar.', 'runline' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Statistics', 'runline' ); ?></th>
					<td>
						<label><input type="checkbox" name="runline_options[stats]" value="1" <?php checked( $options['stats'] ); ?>> <?php esc_html_e( 'Count views and clicks of the bars', 'runline' ); ?></label>
						<p class="description"><?php esc_html_e( 'Only numbers per day are stored, without cookies. Against fake views and clicks the site keeps a scrambled code of each visitor (not the IP address) for one day.', 'runline' ); ?> <?php esc_html_e( 'The browser sends one small request to your site the first time a visitor sees the bars in a session (all bars of the page together), and one for each click.', 'runline' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Google Analytics and Meta Pixel', 'runline' ); ?></th>
					<td>
						<label><input type="checkbox" name="runline_options[analytics]" value="1" <?php checked( $options['analytics'] ); ?>> <?php esc_html_e( 'Send views, clicks, coupon copies and signups of the bars as events to Google Analytics 4, Google Tag Manager and Meta Pixel', 'runline' ); ?></label>
						<p class="description"><?php esc_html_e( 'Only on sites where these tools are already installed (Runline adds no tracking code of its own). Events: runline_view, runline_click, runline_coupon_copy, runline_signup, with the bar ID.', 'runline' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'E-mail services', 'runline' ); ?></th>
					<td>
						<?php
						foreach ( array(
							'mailchimp'  => 'Mailchimp',
							'mailerlite' => 'MailerLite',
							'brevo'      => 'Brevo',
							'kit'        => 'Kit (ConvertKit)',
							'klaviyo'    => 'Klaviyo',
							'omnisend'   => 'Omnisend',
						) as $service => $service_name ) :
							?>
							<p>
								<label>
									<?php
									/* translators: %s: name of an e-mail service. */
									echo esc_html( sprintf( __( '%s API key', 'runline' ), $service_name ) );
									?>
									<br><input type="password" class="regular-text" autocomplete="off" name="runline_options[<?php echo esc_attr( $service ); ?>_key]" value="<?php echo esc_attr( $options[ $service . '_key' ] ); ?>">
								</label>
							</p>
						<?php endforeach; ?>
						<p>
							<label>
								<?php esc_html_e( 'Webhook address (Zapier, Make, n8n…)', 'runline' ); ?>
								<br><input type="url" class="regular-text" autocomplete="off" placeholder="https://hooks.zapier.com/…" name="runline_options[webhook_key]" value="<?php echo esc_attr( $options['webhook_key'] ); ?>">
							</label>
						</p>
						<p class="description"><?php esc_html_e( 'Needed only if the signup form of a bar sends addresses to that service. When a visitor subscribes, the address is sent from your site to the chosen service (Mailchimp: mailchimp.com, MailerLite: mailerlite.com, Brevo: brevo.com) under its terms and privacy policy.', 'runline' ); ?> <?php esc_html_e( 'Kit: kit.com, Klaviyo: klaviyo.com, Omnisend: omnisend.com, webhook: the address you enter. FluentCRM and MailPoet are WordPress plugins: the address stays on your site.', 'runline' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'When the plugin is deleted', 'runline' ); ?></th>
					<td>
						<label><input type="checkbox" name="runline_options[delete_data]" value="1" <?php checked( $options['delete_data'] ); ?>> <?php esc_html_e( 'Also delete all bars and settings', 'runline' ); ?></label>
						<p class="description"><?php esc_html_e( 'Off: your bars stay in the database and come back if you install Runline again.', 'runline' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=runline-help' ) ); ?>"><?php esc_html_e( 'Shortcode, variables and answers to common questions: Runline → Help', 'runline' ); ?></a></p>
	</div>
	<?php
}
