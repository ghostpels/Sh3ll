<?php
/**
 * Statistics: views and clicks of each bar per day (and per A/B variant). No personal data, no cookies:
 * the browser sends a small note when a bar is shown and when a link, the button or the coupon is clicked.
 */

defined( 'ABSPATH' ) || exit;

define( 'RUNLINE_DB_VERSION', '3' ); // 3 = subscribers: retry, tries, consent (1.2.1).

function runline_stats_table() {
	global $wpdb;
	return $wpdb->prefix . 'runline_stats';
}

/**
 * Creates or updates the table (on activation and after an update of the plugin).
 */
function runline_stats_install() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$table   = runline_stats_table();
	$charset = $wpdb->get_charset_collate();
	dbDelta(
		"CREATE TABLE {$table} (
			bar_id bigint(20) unsigned NOT NULL,
			day date NOT NULL,
			variant char(1) NOT NULL DEFAULT 'a',
			views int(10) unsigned NOT NULL DEFAULT 0,
			clicks int(10) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (bar_id,day,variant)
		) {$charset};"
	);
	do_action( 'runline_install' );
	update_option( 'runline_db_version', RUNLINE_DB_VERSION, false );
}

add_action(
	'plugins_loaded',
	function () {
		if ( RUNLINE_DB_VERSION !== get_option( 'runline_db_version' ) ) {
			runline_stats_install();
		}
	}
);

function runline_stats_on() {
	return (bool) runline_options()['stats'];
}

/**
 * Adds a view or a click.
 *
 * @param int    $bar_id  Bar ID.
 * @param string $type    "view" or "click".
 * @param string $variant "a" or "b".
 */
function runline_stats_add( $bar_id, $type, $variant = 'a' ) {
	global $wpdb;
	$column  = 'click' === $type ? 'clicks' : 'views';
	$variant = 'b' === $variant ? 'b' : 'a';
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- a counter; nothing to cache.
	$wpdb->query(
		$wpdb->prepare(
			'INSERT INTO %i (bar_id, day, variant, %i) VALUES (%d, %s, %s, 1) ON DUPLICATE KEY UPDATE %i = %i + 1',
			runline_stats_table(),
			$column,
			$bar_id,
			current_time( 'Y-m-d' ),
			$variant,
			$column,
			$column
		)
	);
}

/**
 * Statistics of one bar for the last days: { days: [ { day, views, clicks } ], variants: { a: {…}, b: {…} } }.
 *
 * @param int $bar_id Bar ID.
 * @param int $days   Number of days, today included.
 */
function runline_stats_get( $bar_id, $days = 30 ) {
	global $wpdb;
	$from   = gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) ) - ( $days - 1 ) * DAY_IN_SECONDS );
	$rows   = $wpdb->get_results( $wpdb->prepare( 'SELECT day, variant, views, clicks FROM %i WHERE bar_id = %d AND day >= %s', runline_stats_table(), $bar_id, $from ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- statistics of the admin screen.
	$by_day = array();
	for ( $i = $days - 1; $i >= 0; $i-- ) {
		$day            = gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) ) - $i * DAY_IN_SECONDS );
		$by_day[ $day ] = array(
			'day'    => $day,
			'views'  => 0,
			'clicks' => 0,
		);
	}
	$variants = array(
		'a' => array(
			'views'  => 0,
			'clicks' => 0,
		),
		'b' => array(
			'views'  => 0,
			'clicks' => 0,
		),
	);
	foreach ( (array) $rows as $row ) {
		if ( isset( $by_day[ $row['day'] ] ) ) {
			$by_day[ $row['day'] ]['views']  += (int) $row['views'];
			$by_day[ $row['day'] ]['clicks'] += (int) $row['clicks'];
		}
		$variants[ $row['variant'] ]['views']  += (int) $row['views'];
		$variants[ $row['variant'] ]['clicks'] += (int) $row['clicks'];
	}
	return array(
		'days'     => array_values( $by_day ),
		'variants' => $variants,
	);
}

/**
 * Totals of the last 30 days for all bars: bar ID => { views, clicks }.
 */
function runline_stats_totals() {
	global $wpdb;
	$from = gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) ) - 29 * DAY_IN_SECONDS );
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT bar_id, SUM(views) AS views, SUM(clicks) AS clicks FROM %i WHERE day >= %s GROUP BY bar_id', runline_stats_table(), $from ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- list of bars in the admin.
	$out  = array();
	foreach ( (array) $rows as $row ) {
		$out[ (int) $row['bar_id'] ] = array(
			'views'  => (int) $row['views'],
			'clicks' => (int) $row['clicks'],
		);
	}
	return $out;
}

/**
 * Deletes the statistics of a bar (button "Reset" and deleting the bar).
 */
function runline_stats_reset( $bar_id ) {
	global $wpdb;
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- deleting rows of our table.
	$wpdb->delete( runline_stats_table(), array( 'bar_id' => (int) $bar_id ), array( '%d' ) );
}

add_action(
	'before_delete_post',
	function ( $post_id ) {
		if ( RUNLINE_POST_TYPE === get_post_type( $post_id ) ) {
			runline_stats_reset( $post_id );
		}
	}
);

/**
 * Limits of the public /track endpoint, checked on the server (the once-per-session guard of the browser can be
 * skipped by calling the endpoint directly). For one visitor (address + browser) and one bar: a view counts once per
 * RUNLINE_TRACK_WINDOW, a click only after a view of that bar and at most RUNLINE_TRACK_CLICKS times per window; one
 * visitor may send at most RUNLINE_TRACK_MAX notes per window. The state is one transient per visitor (a hash, not the
 * address), kept for a day.
 */
if ( ! defined( 'RUNLINE_TRACK_WINDOW' ) ) {
	define( 'RUNLINE_TRACK_WINDOW', 30 * MINUTE_IN_SECONDS );
}
if ( ! defined( 'RUNLINE_TRACK_CLICKS' ) ) {
	define( 'RUNLINE_TRACK_CLICKS', 3 );
}
if ( ! defined( 'RUNLINE_TRACK_MAX' ) ) {
	define( 'RUNLINE_TRACK_MAX', 120 );
}
// One address whatever the browser says (a changed User-Agent does not get round it).
if ( ! defined( 'RUNLINE_TRACK_IP_MAX' ) ) {
	define( 'RUNLINE_TRACK_IP_MAX', 600 );
}

/**
 * Transient name of the visitor's /track state.
 */
function runline_track_key() {
	// The browser is part of the key, so people behind one shared address (an office, a mobile network) count apart.
	$agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
	return 'runline_track_' . substr( hash_hmac( 'sha256', runline_client_ip() . '|' . $agent, wp_salt( 'nonce' ) ), 0, 32 );
}

/**
 * Transient name of the notes count of the visitor's address, whatever the browser.
 */
function runline_track_ip_key() {
	return 'runline_track_ip_' . substr( hash_hmac( 'sha256', runline_client_ip(), wp_salt( 'nonce' ) ), 0, 32 );
}

/**
 * Whether a note of this visitor counts, and remembers it. $state is the visitor's state (see runline_track_key()).
 *
 * @param array  $state State, changed in place.
 * @param int    $bar   Bar ID.
 * @param string $type  "view" or "click".
 * @param int    $now   Time.
 */
function runline_track_allowed( &$state, $bar, $type, $now ) {
	$fresh = function ( $time ) use ( $now ) {
		return $time && $now - $time < RUNLINE_TRACK_WINDOW;
	};
	if ( 'view' === $type ) {
		if ( isset( $state['v'][ $bar ] ) && $fresh( $state['v'][ $bar ] ) ) {
			return false;
		}
		$state['v'][ $bar ] = $now;
		return true;
	}
	// A click without a view of the bar from the same address today is not a click of a visitor.
	if ( empty( $state['v'][ $bar ] ) ) {
		return false;
	}
	$clicks = isset( $state['c'][ $bar ] ) && $fresh( $state['c'][ $bar ][1] ) ? $state['c'][ $bar ] : array( 0, $now );
	if ( $clicks[0] >= RUNLINE_TRACK_CLICKS ) {
		return false;
	}
	$state['c'][ $bar ] = array( $clicks[0] + 1, $clicks[1] );
	return true;
}

/**
 * A note from a visitor's browser. Bars that are off, unknown IDs, repeated IDs and notes over the limits above are
 * skipped quietly.
 *
 * @param WP_REST_Request $request Request.
 */
function runline_rest_track( WP_REST_Request $request ) {
	$done = new WP_REST_Response( null, 204 );
	if ( ! runline_stats_on() ) {
		return $done;
	}
	$now   = time();
	$key   = runline_track_key();
	$state = get_transient( $key );
	$state = is_array( $state ) ? $state : array();
	$state = array_merge(
		array(
			'n' => array( 0, $now ),
			'v' => array(),
			'c' => array(),
		),
		$state
	);
	if ( $now - $state['n'][1] >= RUNLINE_TRACK_WINDOW ) {
		$state['n'] = array( 0, $now );
	}
	$ip_key = runline_track_ip_key();
	$by_ip  = get_transient( $ip_key );
	$by_ip  = is_array( $by_ip ) && $now - $by_ip[1] < RUNLINE_TRACK_WINDOW ? $by_ip : array( 0, $now );
	if ( $state['n'][0] >= RUNLINE_TRACK_MAX || $by_ip[0] >= RUNLINE_TRACK_IP_MAX ) {
		return new WP_REST_Response( null, 429 );
	}
	++$state['n'][0];
	set_transient( $ip_key, array( $by_ip[0] + 1, $by_ip[1] ), RUNLINE_TRACK_WINDOW );
	$list = (array) $request['bars'];
	if ( 'click' === $request['type'] || ! $list ) {
		$list = array(
			array(
				'bar'     => (int) $request['bar'],
				'variant' => (string) $request['variant'],
			),
		);
	}
	$seen = array();
	foreach ( array_slice( $list, 0, 10 ) as $item ) {
		$bar = isset( $item['bar'] ) ? (int) $item['bar'] : 0;
		if ( ! $bar || isset( $seen[ $bar ] ) || RUNLINE_POST_TYPE !== get_post_type( $bar ) || '1' !== get_post_meta( $bar, RUNLINE_ACTIVE_META, true ) ) {
			continue;
		}
		$seen[ $bar ] = true;
		if ( runline_track_allowed( $state, $bar, (string) $request['type'], $now ) ) {
			runline_stats_add( $bar, (string) $request['type'], isset( $item['variant'] ) ? (string) $item['variant'] : 'a' );
		}
	}
	set_transient( $key, $state, DAY_IN_SECONDS );
	return $done;
}

add_action(
	'rest_api_init',
	function () {
		// Notes from the browsers of visitors: public, but only for bars that are switched on. A click comes alone
		// ({ bar, type: "click", variant }); the views of a page come together ({ type: "view", bars: [ { bar, variant } ] }),
		// once per browser session for each bar.
		register_rest_route(
			RUNLINE_REST_NS,
			'/track',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => 'runline_rest_track',
				'permission_callback' => '__return_true',
				'args'                => array(
					'type'    => array(
						'type'     => 'string',
						'enum'     => array( 'view', 'click' ),
						'required' => true,
					),
					'bar'     => array(
						'type' => 'integer',
					),
					'variant' => array(
						'type'    => 'string',
						'enum'    => array( 'a', 'b' ),
						'default' => 'a',
					),
					'bars'    => array(
						'type'     => 'array',
						'maxItems' => 10,
						'items'    => array(
							'type'       => 'object',
							'properties' => array(
								'bar'     => array(
									'type'     => 'integer',
									'required' => true,
								),
								'variant' => array(
									'type' => 'string',
									'enum' => array( 'a', 'b' ),
								),
							),
						),
					),
				),
			)
		);
		register_rest_route(
			RUNLINE_REST_NS,
			'/stats',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => function ( WP_REST_Request $request ) {
						return rest_ensure_response( runline_stats_get( (int) $request['bar'], 30 ) );
					},
					'permission_callback' => function () {
						return current_user_can( 'manage_options' );
					},
					'args'                => array(
						'bar' => array(
							'type'     => 'integer',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => function ( WP_REST_Request $request ) {
						runline_stats_reset( (int) $request['bar'] );
						return rest_ensure_response( array( 'reset' => true ) );
					},
					'permission_callback' => function () {
						return current_user_can( 'manage_options' );
					},
					'args'                => array(
						'bar' => array(
							'type'     => 'integer',
							'required' => true,
						),
					),
				),
			)
		);
	}
);
