<?php
/**
 * Elementor widget "Runline bar".
 */

defined( 'ABSPATH' ) || exit;

/**
 * One of the Runline bars in an Elementor page: the same HTML as the shortcode.
 */
class Runline_Elementor_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'runline';
	}

	public function get_title() {
		return __( 'Runline bar', 'runline' );
	}

	public function get_icon() {
		return 'eicon-animation-text';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_keywords() {
		return array( 'marquee', 'ticker', 'announcement', 'scrolling', 'runline' );
	}

	public function get_script_depends() {
		return array( 'runline' );
	}

	public function get_style_depends() {
		return array( 'runline' );
	}

	/**
	 * Bars to choose from: ID => name ("0" = the bar that is switched on).
	 */
	private function bar_options() {
		$options = array( '0' => __( 'The bar that is switched on', 'runline' ) );
		$ids     = get_posts(
			array(
				'post_type'      => RUNLINE_POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 500,
				'fields'         => 'ids',
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		foreach ( $ids as $id ) {
			$title = get_post_field( 'post_title', $id, 'raw' );
			if ( '1' !== get_post_meta( $id, RUNLINE_ACTIVE_META, true ) ) {
				/* translators: %s: bar name. */
				$title = sprintf( __( '%s (off)', 'runline' ), $title );
			}
			$options[ (string) $id ] = $title;
		}
		return $options;
	}

	protected function register_controls() {
		$this->start_controls_section(
			'runline_section',
			array( 'label' => __( 'Bar', 'runline' ) )
		);
		$this->add_control(
			'bar_id',
			array(
				'label'   => __( 'Which bar', 'runline' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => $this->bar_options(),
				'default' => '0',
			)
		);
		$this->add_control(
			'runline_help',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s <a href="%2$s" target="_blank">%3$s</a>',
					esc_html__( 'Texts, colours and speed are set in Runline.', 'runline' ),
					esc_url( admin_url( 'admin.php?page=runline' ) ),
					esc_html__( 'Open Runline', 'runline' )
				),
				'content_classes' => 'elementor-descriptor',
			)
		);
		$this->end_controls_section();
	}

	protected function render() {
		$id   = (int) $this->get_settings_for_display( 'bar_id' );
		$html = runline_shortcode( array( 'id' => $id ) );
		if ( '' === $html && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			// Only the editor sees this: a switched-off bar shows nothing on the site.
			$html = '<p class="runline-elementor-empty">' . esc_html__( 'This bar is switched off or has no messages, so the site does not show it. Switch it on in Runline.', 'runline' ) . '</p>';
		}
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in runline_render_bar().
	}
}
