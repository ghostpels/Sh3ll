<?php
/**
 * Ready designs: a design is a set of settings (look, motion, sample texts) on top of the defaults.
 * The gallery starts a new bar from one; "Change design" in the editor takes only the look (RUNLINE_LOOK_KEYS).
 * Every design passes WCAG AA contrast (tests/run-tests.php checks it).
 */

defined( 'ABSPATH' ) || exit;

/**
 * Settings a design changes on an existing bar (texts, place and pages stay as they are).
 */
const RUNLINE_LOOK_KEYS = array( 'bg', 'bg2', 'bg_angle', 'color', 'link_color', 'link_hover', 'label_bg', 'label_color', 'font', 'font_size', 'font_size_mobile', 'font_weight', 'uppercase', 'height', 'gap', 'separator', 'speed', 'speed_mobile', 'direction', 'mode', 'interval', 'style', 'border_width', 'border_color', 'shadow', 'ribbon', 'tilt', 'ribbon2', 'radius', 'width', 'max_width' );

/**
 * Categories of the gallery: key => name.
 */
function runline_design_categories() {
	return array(
		'shop'      => __( 'Shop & sales', 'runline' ),
		'marketing' => __( 'Coupons & signups', 'runline' ),
		'reviews'   => __( 'Reviews & trust', 'runline' ),
		'holidays'  => __( 'Holidays', 'runline' ),
		'news'      => __( 'News & blog', 'runline' ),
		'landing'   => __( 'Landing pages', 'runline' ),
		'minimal'   => __( 'Minimal', 'runline' ),
		'niche'     => __( 'Flowers, cafés, events', 'runline' ),
	);
}

/**
 * One message of a design.
 */
function runline_design_item( $icon, $text ) {
	return array(
		'text'    => $text,
		'url'     => '',
		'new_tab' => false,
		'icon'    => $icon,
	);
}

/**
 * All designs: list of { id, name, category, settings } with full, cleaned settings.
 */
function runline_designs() {
	$designs = array(
		// Shop & sales.
		array(
			'id'       => 'black-friday',
			'name'     => __( 'Black Friday', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#000000',
				'color'       => '#ffffff',
				'label'       => __( 'BLACK FRIDAY', 'runline' ),
				'label_bg'    => '#facc15',
				'label_color' => '#000000',
				'separator'   => '★',
				'font_weight' => '800',
				'uppercase'   => true,
				'height'      => 44,
				'speed'       => 70,
				'items'       => array(
					runline_design_item( '🔥', __( '−50% on everything', 'runline' ) ),
					runline_design_item( '⏰', __( 'Ends Sunday at midnight', 'runline' ) ),
					runline_design_item( '🚚', __( 'Free shipping today', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'free-shipping',
			'name'     => __( 'Free shipping', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#ecfdf5',
				'color'       => '#065f46',
				'separator'   => '•',
				'font_weight' => '600',
				'items'       => array(
					runline_design_item( '🚚', __( 'Free shipping on orders over $50', 'runline' ) ),
					runline_design_item( '📦', __( 'Delivery in 1–2 days', 'runline' ) ),
					runline_design_item( '↩️', __( '30-day free returns', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'flash-sale',
			'name'     => __( 'Flash sale', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#b91c1c',
				'color'       => '#ffffff',
				'label'       => __( 'SALE', 'runline' ),
				'label_bg'    => '#ffffff',
				'label_color' => '#b91c1c',
				'separator'   => '✦',
				'font_weight' => '800',
				'uppercase'   => true,
				'speed'       => 90,
				'items'       => array(
					runline_design_item( '⚡', __( 'Flash sale: −30% for 24 hours', 'runline' ) ),
					runline_design_item( '🏷️', __( 'Use code FLASH30 at checkout', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'new-collection',
			'name'     => __( 'New collection', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#fdf2f8',
				'color'       => '#831843',
				'label'       => __( 'NEW', 'runline' ),
				'label_bg'    => '#be185d',
				'label_color' => '#ffffff',
				'separator'   => '·',
				'font'        => 'serif',
				'font_size'   => 16,
				'items'       => array(
					runline_design_item( '✨', __( 'The spring collection is here', 'runline' ) ),
					runline_design_item( '🎁', __( 'Code WELCOME10: −10% on your first order', 'runline' ) ),
				),
			),
		),
		// Holidays.
		array(
			'id'       => 'christmas',
			'name'     => __( 'Christmas', 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'          => '#14532d',
				'color'       => '#ffffff',
				'label'       => __( 'CHRISTMAS', 'runline' ),
				'label_bg'    => '#b91c1c',
				'label_color' => '#ffffff',
				'separator'   => '❄',
				'font_weight' => '600',
				'items'       => array(
					runline_design_item( '🎄', __( 'Merry Christmas!', 'runline' ) ),
					runline_design_item( '🎁', __( 'Order gifts by December 20 for delivery before Christmas', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'new-year',
			'name'     => __( 'New Year', 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'          => '#0f172a',
				'color'       => '#fde68a',
				'separator'   => '✦',
				'font'        => 'serif',
				'font_size'   => 17,
				'font_weight' => '600',
				'items'       => array(
					runline_design_item( '🥂', __( 'Happy New Year!', 'runline' ) ),
					runline_design_item( '🎆', __( 'New Year sale: −25% until January 7', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'valentine',
			'name'     => __( 'Valentine\'s Day', 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'          => '#fff1f2',
				'color'       => '#be123c',
				'separator'   => '♥',
				'font_weight' => '600',
				'items'       => array(
					runline_design_item( '❤️', __( 'Valentine\'s Day gifts for the one you love', 'runline' ) ),
					runline_design_item( '💌', __( 'Free gift card with every order', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'easter',
			'name'     => __( 'Easter', 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'          => '#fefce8',
				'color'       => '#713f12',
				'separator'   => '✿',
				'font_weight' => '600',
				'items'       => array(
					runline_design_item( '🐣', __( 'Happy Easter!', 'runline' ) ),
					runline_design_item( '🌷', __( 'Spring decorations — order before the holidays', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'halloween',
			'name'     => __( 'Halloween', 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'          => '#1c1917',
				'color'       => '#fb923c',
				'label'       => __( 'BOO!', 'runline' ),
				'label_bg'    => '#fb923c',
				'label_color' => '#1c1917',
				'separator'   => '•',
				'font_weight' => '700',
				'uppercase'   => true,
				'items'       => array(
					runline_design_item( '🎃', __( 'Spooky sale: −31% on everything', 'runline' ) ),
					runline_design_item( '👻', __( 'Only until October 31', 'runline' ) ),
				),
			),
		),
		// News & blog.
		array(
			'id'       => 'breaking',
			'name'     => __( 'Breaking news', 'runline' ),
			'category' => 'news',
			'settings' => array(
				'bg'          => '#ffffff',
				'color'       => '#111827',
				'label'       => __( 'BREAKING', 'runline' ),
				'label_bg'    => '#b91c1c',
				'label_color' => '#ffffff',
				'separator'   => '|',
				'font'        => 'system',
				'font_weight' => '600',
				'speed'       => 55,
				'items'       => array(
					runline_design_item( '', __( 'We are open on Saturday from 10:00 to 16:00', 'runline' ) ),
					runline_design_item( '', __( 'New products added every week', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'news-ticker',
			'name'     => __( 'News ticker', 'runline' ),
			'category' => 'news',
			'settings' => array(
				'bg'          => '#1e3a8a',
				'color'       => '#ffffff',
				'label'       => __( 'NEWS', 'runline' ),
				'label_bg'    => '#fbbf24',
				'label_color' => '#1e3a8a',
				'separator'   => '•',
				'font'        => 'system',
				'items'       => array(
					runline_design_item( '📣', __( 'Our shop turns 5 — thank you!', 'runline' ) ),
					runline_design_item( '📰', __( 'Read the latest post on our blog', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'blog-latest',
			'name'     => __( 'Latest on the blog', 'runline' ),
			'category' => 'news',
			'settings' => array(
				'bg'          => '#f8fafc',
				'color'       => '#334155',
				'link_color'  => '#1d4ed8',
				'label'       => __( 'LATEST', 'runline' ),
				'label_bg'    => '#334155',
				'label_color' => '#ffffff',
				'separator'   => '/',
				'font'        => 'serif',
				'font_size'   => 16,
				'items'       => array(
					runline_design_item( '', __( '10 ideas for a garden party', 'runline' ) ),
					runline_design_item( '', __( 'How to choose the perfect gift', 'runline' ) ),
				),
			),
		),
		// Landing pages.
		array(
			'id'       => 'big-type',
			'name'     => __( 'Big type', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'               => '#111111',
				'color'            => '#ffffff',
				'separator'        => '✦',
				'font_size'        => 32,
				'font_size_mobile' => 22,
				'font_weight'      => '800',
				'uppercase'        => true,
				'height'           => 72,
				'gap'              => 48,
				'speed'            => 80,
				'speed_mobile'     => 60,
				'closable'         => false,
				'items'            => array(
					runline_design_item( '', __( 'Design', 'runline' ) ),
					runline_design_item( '', __( 'Build', 'runline' ) ),
					runline_design_item( '', __( 'Launch', 'runline' ) ),
					runline_design_item( '', __( 'Repeat', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'lime',
			'name'     => __( 'Lime', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'               => '#d9f99d',
				'color'            => '#1a2e05',
				'separator'        => '●',
				'font_size'        => 24,
				'font_size_mobile' => 18,
				'font_weight'      => '700',
				'uppercase'        => true,
				'height'           => 56,
				'gap'              => 40,
				'closable'         => false,
				'items'            => array(
					runline_design_item( '', __( 'Fast', 'runline' ) ),
					runline_design_item( '', __( 'Simple', 'runline' ) ),
					runline_design_item( '', __( 'No code', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'terminal',
			'name'     => __( 'Terminal', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'           => '#0a0a0a',
				'color'        => '#4ade80',
				'separator'    => '//',
				'font'         => 'mono',
				'font_size'    => 14,
				'font_weight'  => '500',
				'uppercase'    => true,
				'speed'        => 50,
				'speed_mobile' => 40,
				'items'        => array(
					runline_design_item( '>', __( 'Version 2.0 is live', 'runline' ) ),
					runline_design_item( '>', __( 'Faster, lighter, better', 'runline' ) ),
				),
			),
		),
		// Minimal.
		array(
			'id'       => 'minimal-dark',
			'name'     => __( 'Minimal dark', 'runline' ),
			'category' => 'minimal',
			'settings' => array(
				'bg'               => '#111827',
				'color'            => '#e5e7eb',
				'separator'        => '·',
				'font_size'        => 13,
				'font_size_mobile' => 12,
				'font_weight'      => '400',
				'height'           => 32,
				'gap'              => 32,
				'speed'            => 45,
				'speed_mobile'     => 35,
				'items'            => array(
					runline_design_item( '', __( 'Free shipping over $50', 'runline' ) ),
					runline_design_item( '', __( 'Easy returns', 'runline' ) ),
					runline_design_item( '', __( 'Secure payment', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'minimal-light',
			'name'     => __( 'Minimal light', 'runline' ),
			'category' => 'minimal',
			'settings' => array(
				'bg'               => '#f3f4f6',
				'color'            => '#374151',
				'separator'        => '·',
				'font_size'        => 13,
				'font_size_mobile' => 12,
				'font_weight'      => '400',
				'height'           => 32,
				'gap'              => 32,
				'speed'            => 45,
				'speed_mobile'     => 35,
				'items'            => array(
					runline_design_item( '', __( 'Free shipping over $50', 'runline' ) ),
					runline_design_item( '', __( 'Easy returns', 'runline' ) ),
					runline_design_item( '', __( 'Secure payment', 'runline' ) ),
				),
			),
		),
		// Flowers, cafés, events.
		array(
			'id'       => 'flowers',
			'name'     => __( 'Flower shop', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#fdf4ff',
				'color'       => '#86198f',
				'separator'   => '✿',
				'font'        => 'serif',
				'font_size'   => 16,
				'font_weight' => '600',
				'items'       => array(
					runline_design_item( '🌸', __( 'Fresh flowers delivered today', 'runline' ) ),
					runline_design_item( '💐', __( 'Order before 14:00 for same-day delivery', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'cafe',
			'name'     => __( 'Café', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'        => '#3f2a1d',
				'color'     => '#fef3c7',
				'separator' => '•',
				'font'      => 'serif',
				'font_size' => 16,
				'items'     => array(
					runline_design_item( '☕', __( 'Open daily 8:00–20:00', 'runline' ) ),
					runline_design_item( '🥐', __( 'Fresh croissants every morning', 'runline' ) ),
					runline_design_item( '🛵', __( 'Order online, pick up in 10 minutes', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'party',
			'name'     => __( 'Party & balloons', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#7c3aed',
				'color'       => '#ffffff',
				'label'       => __( 'PARTY', 'runline' ),
				'label_bg'    => '#fde047',
				'label_color' => '#4c1d95',
				'separator'   => '🎈',
				'font_weight' => '700',
				'items'       => array(
					runline_design_item( '🎉', __( 'Balloons and decorations for every party', 'runline' ) ),
					runline_design_item( '🚚', __( 'Delivery on the day of your event', 'runline' ) ),
				),
			),
		),
	);

	$designs  = array_merge( $designs, runline_more_designs(), runline_extra_designs(), runline_designs_2026(), runline_designs_features() );
	$defaults = runline_default_settings();
	foreach ( $designs as &$design ) {
		$design['settings'] = runline_sanitize_settings( array_merge( $defaults, array( 'label' => '' ), $design['settings'] ) );
	}
	unset( $design );
	return apply_filters( 'runline_designs', $designs );
}
