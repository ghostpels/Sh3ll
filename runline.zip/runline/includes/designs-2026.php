<?php
/**
 * Designs added in 1.1: holidays of the year, parties, more trades, new looks, and designs that show the new
 * features (a timer every day, a personal timer, a coupon for subscribing).
 * Merged into runline_designs(); every one passes WCAG AA contrast (tests/run-tests.php).
 */

defined( 'ABSPATH' ) || exit;

/**
 * The designs of 1.1.
 */
function runline_designs_2026() {
	$home   = home_url( '/' );
	$item   = 'runline_design_item';
	$button = function ( $text, $bg, $color, $radius = 4, $pulse = false ) use ( $home ) {
		return array(
			'on'     => true,
			'text'   => $text,
			'url'    => $home,
			'bg'     => $bg,
			'color'  => $color,
			'radius' => $radius,
			'pulse'  => $pulse,
		);
	};

	return array(
		// Shop & sales.
		array(
			'id'       => 'order-cutoff',
			'name'     => __( 'Order today, ships today', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#14532d',
				'color'       => '#ffffff',
				'font'        => 'g:Inter',
				'font_weight' => '700',
				'separator'   => '•',
				'countdown'   => array(
					'on'         => true,
					'source'     => 'daily',
					'daily'      => '14:00',
					'daily_days' => array( 1, 2, 3, 4, 5 ),
					'place'      => 'text',
					'bg'         => '#bbf7d0',
					'color'      => '#14532d',
				),
				'items'       => array(
					$item( '🚚', __( 'Order in {countdown} — we ship today', 'runline' ) ),
					$item( '📦', __( 'Orders after 14:00 go out the next working day', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'cyber-week',
			'name'     => __( 'Cyber Week', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#020617',
				'bg2'         => '#1e1b4b',
				'color'       => '#7dd3fc',
				'font'        => 'g:Space Grotesk',
				'font_weight' => '700',
				'uppercase'   => true,
				'separator'   => '⚡',
				'label'       => __( 'Cyber Week', 'runline' ),
				'label_bg'    => '#7dd3fc',
				'label_color' => '#020617',
				'items'       => array(
					$item( '', __( 'Seven days of deals: a new offer every day', 'runline' ) ),
					$item( '', __( 'Up to −50% online only', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'after-christmas',
			'name'     => __( 'After-Christmas sale', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#7f1d1d',
				'color'       => '#fff7ed',
				'font'        => 'g:Poppins',
				'font_weight' => '600',
				'separator'   => '❄',
				'button'      => $button( __( 'Shop the sale', 'runline' ), '#fff7ed', '#7f1d1d', 20 ),
				'items'       => array(
					$item( '🎁', __( 'After-Christmas sale: everything −40%', 'runline' ) ),
					$item( '↩️', __( 'Easy exchanges for gifts until January 31', 'runline' ) ),
				),
			),
		),
		// Coupons & signups.
		array(
			'id'       => 'personal-offer',
			'name'     => __( 'Personal 15-minute offer', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'          => '#4c0519',
				'color'       => '#ffe4e6',
				'font'        => 'g:Rubik',
				'font_weight' => '600',
				'countdown'   => array(
					'on'      => true,
					'source'  => 'visitor',
					'minutes' => 15,
					'place'   => 'right',
					'prefix'  => __( 'Only for you:', 'runline' ),
					'after'   => 'hide',
					'bg'      => '#fda4af',
					'color'   => '#4c0519',
				),
				'coupon'      => array(
					'on'    => true,
					'code'  => 'NOW10',
					'bg'    => '#ffe4e6',
					'color' => '#4c0519',
				),
				'items'       => array(
					$item( '⏳', __( 'Your welcome offer: −10% with this code', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'welcome-gift',
			'name'     => __( 'Subscribe for a gift', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'          => '#fef3c7',
				'color'       => '#78350f',
				'font'        => 'g:Nunito',
				'font_weight' => '700',
				'signup'      => array(
					'on'          => true,
					'placeholder' => __( 'Your e-mail', 'runline' ),
					'button'      => __( 'Get my gift', 'runline' ),
					'success'     => __( 'Welcome! Here is your code:', 'runline' ),
					'coupon'      => 'WELCOME15',
				),
				'items'       => array(
					$item( '🎁', __( 'Join our newsletter and get −15% on your first order', 'runline' ) ),
				),
			),
		),
		// Holidays.
		array(
			'id'       => 'grandparents-day',
			'name'     => __( "Grandparents' Day", 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'          => '#fff1f2',
				'color'       => '#881337',
				'font'        => 'g:Merriweather',
				'font_weight' => '700',
				'separator'   => '♥',
				'items'       => array(
					$item( '💐', __( "Grandparents' Day: gifts for grandma and grandpa", 'runline' ) ),
					$item( '🚚', __( 'Order by January 19 — it arrives in time', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'womens-day',
			'name'     => __( "Women's Day (March 8)", 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'          => '#a21caf',
				'bg2'         => '#be185d',
				'color'       => '#ffffff',
				'font'        => 'g:Poppins',
				'font_weight' => '600',
				'separator'   => '🌷',
				'items'       => array(
					$item( '💐', __( "March 8: flowers and gifts for the women you love", 'runline' ) ),
					$item( '🎀', __( 'Free gift wrapping all week', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'childrens-day',
			'name'     => __( "Children's Day", 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'          => '#1d4ed8',
				'bg2'         => '#7c3aed',
				'color'       => '#ffffff',
				'font'        => 'g:Nunito',
				'font_weight' => '800',
				'font_size'   => 16,
				'separator'   => '🎈',
				'items'       => array(
					$item( '🧸', __( "Children's Day: toys, balloons and sweet surprises", 'runline' ) ),
					$item( '🎉', __( 'A small gift in every order for kids', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'teachers-day',
			'name'     => __( "Teacher's Day", 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'          => '#ecfdf5',
				'color'       => '#064e3b',
				'font'        => 'g:Merriweather',
				'font_weight' => '700',
				'separator'   => '✎',
				'items'       => array(
					$item( '🍎', __( "Teacher's Day: say thank you with flowers or a small gift", 'runline' ) ),
					$item( '💌', __( 'A card with your own words for free', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'advent',
			'name'     => __( 'Advent calendar', 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'          => '#14532d',
				'color'       => '#fef9c3',
				'font'        => 'g:Playfair Display',
				'font_size'   => 17,
				'font_weight' => '700',
				'separator'   => '✦',
				'label'       => __( 'Advent', 'runline' ),
				'label_bg'    => '#b91c1c',
				'label_color' => '#ffffff',
				'items'       => array(
					$item( '🎄', __( 'A new surprise every day until Christmas — look in again tomorrow', 'runline' ) ),
					$item( '🎁', __( "Today's surprise is waiting in the shop", 'runline' ) ),
				),
			),
		),
		// Flowers, cafés, events.
		array(
			'id'       => 'birthday',
			'name'     => __( 'Birthday party', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#fdf4ff',
				'color'       => '#86198f',
				'font'        => 'g:Nunito',
				'font_weight' => '800',
				'separator'   => '🎉',
				'button'      => $button( __( 'Plan the party', 'runline' ), '#86198f', '#ffffff', 20, true ),
				'items'       => array(
					$item( '🎂', __( 'Birthday sets: balloons, decorations and a cake topper', 'runline' ) ),
					$item( '🎈', __( 'Delivery and set-up on the day', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'baby-shower',
			'name'     => __( 'Baby shower', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#e0f2fe',
				'bg2'         => '#fce7f3',
				'color'       => '#1e3a8a',
				'font'        => 'g:Nunito',
				'font_weight' => '700',
				'separator'   => '♡',
				'items'       => array(
					$item( '🍼', __( 'Baby shower decorations ready in two days', 'runline' ) ),
					$item( '🎀', __( 'Pastel balloon sets in pink, blue and mint', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'gender-reveal',
			'name'     => __( 'Gender reveal', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#be185d',
				'bg2'         => '#1d4ed8',
				'color'       => '#ffffff',
				'font'        => 'g:Poppins',
				'font_weight' => '700',
				'separator'   => '?',
				'items'       => array(
					$item( '🎈', __( 'Boy or girl? Gender reveal balloons with a surprise inside', 'runline' ) ),
					$item( '💗', __( 'Pink or blue confetti — only we know', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'wedding-season',
			'name'     => __( 'Wedding season', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#fffbeb',
				'color'       => '#713f12',
				'font'        => 'g:Playfair Display',
				'font_size'   => 16,
				'font_weight' => '700',
				'separator'   => '✧',
				'border_width' => 1,
				'border_color' => '#d6b25e',
				'items'       => array(
					$item( '💍', __( 'Wedding season: decorations for the ceremony and the party', 'runline' ) ),
					$item( '📅', __( 'Book your date early — weekends go fast', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'graduation',
			'name'     => __( 'Graduation', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#172554',
				'color'       => '#fde68a',
				'font'        => 'g:Montserrat',
				'font_weight' => '700',
				'separator'   => '★',
				'items'       => array(
					$item( '🎓', __( 'Graduation gifts and party sets — congratulations, class of the year!', 'runline' ) ),
					$item( '🥂', __( 'Order for the big day with delivery to the party', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'fitness',
			'name'     => __( 'Fitness club', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#0a0a0a',
				'color'       => '#bef264',
				'font'        => 'g:Oswald',
				'font_size'   => 17,
				'font_weight' => '700',
				'uppercase'   => true,
				'separator'   => '/',
				'button'      => $button( __( 'Free first class', 'runline' ), '#bef264', '#0a0a0a', 0 ),
				'items'       => array(
					$item( '', __( 'New year, new you: no joining fee this month', 'runline' ) ),
					$item( '', __( 'Open every day from 6:00', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'book-online',
			'name'     => __( 'Book an appointment', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#134e4a',
				'color'       => '#ffffff',
				'font'        => 'g:DM Sans',
				'font_weight' => '600',
				'separator'   => '·',
				'button'      => $button( __( 'Book online', 'runline' ), '#ccfbf1', '#134e4a', 20 ),
				'items'       => array(
					$item( '📅', __( 'Free appointments this week — book online in a minute', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'real-estate',
			'name'     => __( 'Real estate', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#0f172a',
				'color'       => '#e2e8f0',
				'font'        => 'g:Manrope',
				'font_weight' => '600',
				'separator'   => '|',
				'label'       => __( 'New', 'runline' ),
				'label_bg'    => '#facc15',
				'label_color' => '#0f172a',
				'items'       => array(
					$item( '🏡', __( 'New listings every week — sign up for alerts', 'runline' ) ),
					$item( '🔑', __( 'Free valuation of your home', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'courses',
			'name'     => __( 'Courses and school', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#eef2ff',
				'color'       => '#3730a3',
				'font'        => 'g:Raleway',
				'font_weight' => '700',
				'separator'   => '•',
				'items'       => array(
					$item( '📚', __( 'Enrolment is open: new groups start next month', 'runline' ) ),
					$item( '🎓', __( 'The first lesson is free', 'runline' ) ),
				),
			),
		),
		// News & blog.
		array(
			'id'       => 'maintenance',
			'name'     => __( 'Maintenance notice', 'runline' ),
			'category' => 'news',
			'settings' => array(
				'bg'          => '#fef3c7',
				'color'       => '#78350f',
				'font'        => 'system',
				'font_weight' => '600',
				'mode'        => 'static',
				'items'       => array(
					$item( '🛠️', __( 'Planned maintenance on Sunday 2:00–4:00 — the site may be slow', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'holiday-delays',
			'name'     => __( 'Holiday delivery times', 'runline' ),
			'category' => 'news',
			'settings' => array(
				'bg'          => '#1e3a8a',
				'color'       => '#ffffff',
				'font'        => 'g:Inter',
				'font_weight' => '600',
				'separator'   => '•',
				'label'       => __( 'Info', 'runline' ),
				'label_bg'    => '#facc15',
				'label_color' => '#1e3a8a',
				'items'       => array(
					$item( '📦', __( 'Over the holidays delivery can take 1–2 days longer', 'runline' ) ),
					$item( '🕐', __( 'Last orders before the break: December 21', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'newspaper',
			'name'     => __( 'Newspaper', 'runline' ),
			'category' => 'news',
			'settings' => array(
				'bg'          => '#f5f5f0',
				'color'       => '#111111',
				'font'        => 'g:Merriweather',
				'font_size'   => 15,
				'font_weight' => '700',
				'separator'   => '—',
				'label'       => __( 'Extra', 'runline' ),
				'label_bg'    => '#111111',
				'label_color' => '#f5f5f0',
				'border_width' => 2,
				'border_color' => '#111111',
				'items'       => array(
					$item( '', __( 'Today in the shop: new arrivals, restocks and a weekend surprise', 'runline' ) ),
					$item( '', __( 'Read all about it in our newsletter', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'stock-ticker',
			'name'     => __( 'Stock ticker', 'runline' ),
			'category' => 'news',
			'settings' => array(
				'bg'          => '#000000',
				'color'       => '#4ade80',
				'font'        => 'mono',
				'font_size'   => 14,
				'font_weight' => '700',
				'uppercase'   => true,
				'separator'   => '▲',
				'label'       => __( 'Live', 'runline' ),
				'label_bg'    => '#dc2626',
				'label_color' => '#ffffff',
				'items'       => array(
					$item( '', __( 'Balloons +12%', 'runline' ) ),
					$item( '', __( 'Gift boxes +8%', 'runline' ) ),
					$item( '', __( 'Happy customers +100%', 'runline' ) ),
				),
			),
		),
		// Landing pages.
		array(
			'id'       => 'cinema-lights',
			'name'     => __( 'Cinema marquee', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'           => '#450a0a',
				'color'        => '#fde047',
				'font'         => 'g:Bebas Neue',
				'font_size'    => 26,
				'font_size_mobile' => 20,
				'uppercase'    => true,
				'height'       => 56,
				'separator'    => '✦',
				'border_width' => 3,
				'border_color' => '#fde047',
				'items'        => array(
					$item( '', __( 'Now showing: our new collection', 'runline' ) ),
					$item( '', __( 'Premiere tonight', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'retro-pixel',
			'name'     => __( 'Retro pixel', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'          => '#1e1b4b',
				'color'       => '#a3e635',
				'font'        => 'mono',
				'font_size'   => 15,
				'font_weight' => '700',
				'uppercase'   => true,
				'separator'   => '■',
				'items'       => array(
					$item( '👾', __( 'Level up: new items unlocked', 'runline' ) ),
					$item( '🕹️', __( 'Press start to shop', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'glass',
			'name'     => __( 'Glass', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'        => '#e0e7ff',
				'bg2'       => '#fce7f3',
				'color'     => '#1e1b4b',
				'font'      => 'g:Manrope',
				'font_weight' => '700',
				'width'     => 'boxed',
				'max_width' => 760,
				'radius'    => 40,
				'shadow'    => 'soft',
				'separator' => '·',
				'items'     => array(
					$item( '✨', __( 'Something beautiful just arrived', 'runline' ) ),
					$item( '🛍️', __( 'Free delivery this weekend', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'handwritten',
			'name'     => __( 'Handwritten', 'runline' ),
			'category' => 'landing',
			'settings' => array(
				'bg'          => '#fffbeb',
				'color'       => '#7c2d12',
				'font'        => 'g:Lobster',
				'font_size'   => 19,
				'font_weight' => '400',
				'separator'   => '~',
				'items'       => array(
					$item( '', __( 'Made with love, packed by hand', 'runline' ) ),
					$item( '', __( 'Thank you for shopping small', 'runline' ) ),
				),
			),
		),
		// Minimal.
		array(
			'id'       => 'pastel-confetti',
			'name'     => __( 'Pastel confetti', 'runline' ),
			'category' => 'minimal',
			'settings' => array(
				'bg'          => '#fefce8',
				'color'       => '#713f12',
				'font'        => 'g:Nunito',
				'font_weight' => '700',
				'separator'   => '🎊',
				'items'       => array(
					$item( '', __( 'Party season is here', 'runline' ) ),
					$item( '', __( 'Free delivery from 150', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'eco',
			'name'     => __( 'Eco shop', 'runline' ),
			'category' => 'minimal',
			'settings' => array(
				'bg'          => '#ecfccb',
				'color'       => '#365314',
				'font'        => 'g:Work Sans',
				'font_weight' => '600',
				'separator'   => '🌿',
				'items'       => array(
					$item( '', __( 'Plastic-free packaging', 'runline' ) ),
					$item( '', __( 'We plant a tree for every order', 'runline' ) ),
				),
			),
		),
	);
}
