<?php
/**
 * Designs that show the features of 1.1, each ready to use: contact buttons, opening hours ({open_now}), the cart
 * ({cart_total}, {cart_count}), the country ({visitor_country}), bars that come in later (seconds, scrolling),
 * first / returning visitors and pages seen, messages with their own dates, confetti.
 * Merged into runline_designs(); every one passes WCAG AA contrast (tests/run-tests.php).
 */

defined( 'ABSPATH' ) || exit;

/**
 * The next time (this year or next) a yearly period starts and ends: from "MM-DD" to "MM-DD", as "YYYY-MM-DD".
 * A period that is over this year is given for next year, so a message with dates is never already over.
 *
 * @param string $from "MM-DD".
 * @param string $to   "MM-DD".
 * @return array { from, to }
 */
function runline_design_period( $from, $to ) {
	$year = (int) wp_date( 'Y' );
	if ( wp_date( 'm-d' ) > $to ) {
		++$year;
	}
	return array(
		'from' => $year . '-' . $from,
		'to'   => $year . '-' . $to,
	);
}

/**
 * The feature designs of 1.1.
 */
function runline_designs_features() {
	$item   = 'runline_design_item';
	$dated  = function ( $icon, $text, $from, $to ) use ( $item ) {
		return array_merge( $item( $icon, $text ), runline_design_period( $from, $to ) );
	};
	$coupon = function ( $code, $bg, $color ) {
		return array(
			'on'       => true,
			'code'     => $code,
			'bg'       => $bg,
			'color'    => $color,
			'confetti' => true,
		);
	};
	// Example numbers from the range kept for fiction (+1 555 01xx): replace them with yours.
	$contact = array(
		'on'        => true,
		'whatsapp'  => '+15550100200',
		'phone'     => '+15550100200',
		'messenger' => '',
	);

	return array(
		// Flowers, cafés, events.
		array(
			'id'       => 'whatsapp-us',
			'name'     => __( 'Write to us on WhatsApp', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#065f46',
				'color'       => '#ffffff',
				'font'        => 'g:DM Sans',
				'font_weight' => '600',
				'separator'   => '•',
				'contact'     => $contact,
				'items'       => array(
					$item( '💬', __( 'Questions about your order? Write to us on WhatsApp or call', 'runline' ) ),
					$item( '⚡', __( 'We answer within 15 minutes', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'open-now',
			'name'     => __( 'Open now / closed', 'runline' ),
			'category' => 'niche',
			'settings' => array(
				'bg'          => '#1c1917',
				'color'       => '#fef3c7',
				'font'        => 'g:Work Sans',
				'font_weight' => '600',
				'separator'   => '·',
				'contact'     => array_merge( $contact, array( 'whatsapp' => '' ) ),
				'hours'       => array(
					'days'   => array( 1, 2, 3, 4, 5, 6 ),
					'from'   => '09:00',
					'to'     => '19:00',
					'open'   => __( 'Open now', 'runline' ),
					'closed' => __( 'Closed now', 'runline' ),
				),
				'items'       => array(
					$item( '🕘', __( '{open_now} — Mon–Sat 9:00–19:00', 'runline' ) ),
					$item( '📍', __( 'Pick up in the shop or order with delivery', 'runline' ) ),
				),
			),
		),
		// Holidays: a whole year of messages that show and hide by their dates.
		array(
			'id'       => 'holiday-calendar',
			'name'     => __( 'Holidays all year (messages with dates)', 'runline' ),
			'category' => 'holidays',
			'settings' => array(
				'bg'          => '#312e81',
				'color'       => '#ffffff',
				'font'        => 'g:Poppins',
				'font_weight' => '600',
				'separator'   => '✦',
				'items'       => array(
					$item( '🎈', __( 'Balloons and decorations for every celebration', 'runline' ) ),
					$dated( '💐', __( "Grandparents' Day on January 21–22: order your gifts now", 'runline' ), '01-10', '01-22' ),
					$dated( '❤️', __( "Valentine's Day: gifts for the one you love", 'runline' ), '02-01', '02-14' ),
					$dated( '🌷', __( "March 8: flowers and gifts for the women you love", 'runline' ), '03-01', '03-08' ),
					$dated( '🧸', __( "Children's Day: toys, balloons and sweet surprises", 'runline' ), '05-20', '06-01' ),
					$dated( '🎃', __( 'Halloween decorations are here', 'runline' ), '10-15', '10-31' ),
					$dated( '🎁', __( 'Order by December 20 — it arrives before Christmas', 'runline' ), '12-01', '12-20' ),
				),
			),
		),
		// Coupons & signups: for whom and when.
		array(
			'id'       => 'first-visit',
			'name'     => __( 'First visit: welcome coupon', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'          => '#0f766e',
				'color'       => '#ffffff',
				'font'        => 'g:Nunito',
				'font_weight' => '700',
				'coupon'      => $coupon( 'HELLO10', '#ccfbf1', '#134e4a' ),
				'rules'       => array(
					'show' => array(
						array(
							'type'  => 'new_visit',
							'value' => null,
						),
					),
					'hide' => array(),
				),
				'items'       => array(
					$item( '👋', __( 'First time here? −10% on your first order', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'welcome-back',
			'name'     => __( 'Welcome back (returning visitors)', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'          => '#1e3a8a',
				'color'       => '#ffffff',
				'font'        => 'g:Manrope',
				'font_weight' => '700',
				'separator'   => '•',
				'rules'       => array(
					'show' => array(
						array(
							'type'  => 'returning',
							'value' => null,
						),
					),
					'hide' => array(),
				),
				'items'       => array(
					$item( '💙', __( 'Welcome back! Nice to see you again', 'runline' ) ),
					$item( '✨', __( 'New this week: fresh arrivals in the shop', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'scroll-offer',
			'name'     => __( 'Offer after scrolling', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'          => '#7c2d12',
				'color'       => '#ffedd5',
				'font'        => 'g:Rubik',
				'font_weight' => '600',
				'position'    => 'bottom',
				'appear'      => array(
					'delay'  => 0,
					'scroll' => 40,
				),
				'coupon'      => $coupon( 'SCROLL10', '#ffedd5', '#7c2d12' ),
				'items'       => array(
					$item( '👀', __( 'Still looking? Here is −10% for you', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'late-newsletter',
			'name'     => __( 'Newsletter after 10 seconds', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'          => '#faf5ff',
				'color'       => '#581c87',
				'font'        => 'g:Nunito',
				'font_weight' => '700',
				'appear'      => array(
					'delay'  => 10,
					'scroll' => 0,
				),
				'button'      => array(
					'on'     => false,
					'bg'     => '#581c87',
					'color'  => '#ffffff',
					'radius' => 20,
				),
				'signup'      => array(
					'on'          => true,
					'placeholder' => __( 'Your e-mail', 'runline' ),
					'button'      => __( 'Join', 'runline' ),
					'success'     => __( 'Thank you! Here is your code:', 'runline' ),
					'coupon'      => 'NEWS10',
				),
				'items'       => array(
					$item( '💌', __( 'Join our newsletter and get −10%', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'engaged-visitor',
			'name'     => __( 'After 3 pages: a little push', 'runline' ),
			'category' => 'marketing',
			'settings' => array(
				'bg'          => '#a21caf',
				'color'       => '#ffffff',
				'font'        => 'g:Poppins',
				'font_weight' => '600',
				'coupon'      => $coupon( 'LIKEIT', '#fdf4ff', '#701a75' ),
				'rules'       => array(
					'show' => array(
						array(
							'type'  => 'pages_seen',
							'value' => 3,
						),
					),
					'hide' => array(),
				),
				'items'       => array(
					$item( '😍', __( 'Like what you see? Take −10% with this code', 'runline' ) ),
				),
			),
		),
		// Shop & sales: the cart and the country of the visitor.
		array(
			'id'       => 'cart-reminder',
			'name'     => __( 'Cart reminder (WooCommerce)', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#111827',
				'color'       => '#ffffff',
				'font'        => 'g:Inter',
				'font_weight' => '600',
				'separator'   => '•',
				'rules'       => array(
					'show' => array(
						array(
							'type'  => 'returning',
							'value' => null,
						),
					),
					'hide' => array(),
				),
				'items'       => array(
					$item( '🛒', __( 'In your cart: {cart_count} items for {cart_total} — finish your order', 'runline' ) ),
					$item( '🔒', __( 'Safe payment and quick delivery', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'next-delivery',
			'name'     => __( 'Next delivery date (with Dayslot)', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#14532d',
				'color'       => '#ffffff',
				'font'        => 'g:DM Sans',
				'font_weight' => '600',
				'separator'   => '•',
				'items'       => array(
					$item( '🚚', __( 'Next delivery: {delivery_date}', 'runline' ) ),
					$item( '📅', __( 'Choose your delivery day and time at checkout', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'order-in-time',
			'name'     => __( 'Order in time for the next delivery (with Dayslot)', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#0b3b2e',
				'color'       => '#ffffff',
				'font'        => 'g:Inter',
				'font_weight' => '600',
				'separator'   => '•',
				'countdown'   => array(
					'on'     => true,
					'source' => 'dayslot',
					'place'  => 'text',
					'after'  => 'hide',
					'bg'     => '#facc15',
					'color'  => '#111827',
				),
				'items'       => array(
					$item( '⏰', __( 'Order in {countdown} — delivery {delivery_date}', 'runline' ) ),
					$item( '🚚', __( 'You choose the delivery time at checkout', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'places-left',
			'name'     => __( 'Few delivery places left (with Dayslot)', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#7f1d1d',
				'color'       => '#ffffff',
				'font'        => 'g:Rubik',
				'font_weight' => '600',
				'mode'        => 'static',
				'separator'   => '•',
				'items'       => array(
					$item( '🔥', __( 'Delivery places left for {delivery_date}: {places_left} — book your date now', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'pickup-date',
			'name'     => __( 'Next pickup date (with Dayslot)', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#1e293b',
				'color'       => '#ffffff',
				'font'        => 'g:Manrope',
				'font_weight' => '700',
				'mode'        => 'static',
				'separator'   => '•',
				'items'       => array(
					$item( '🛍️', __( 'Pick up your order in our shop: {pickup_date} — choose the day at checkout', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'no-delivery-tomorrow',
			'name'     => __( 'No delivery tomorrow (with Dayslot)', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#78350f',
				'color'       => '#ffffff',
				'font'        => 'g:Nunito',
				'font_weight' => '700',
				'separator'   => '•',
				'rules'       => array(
					'show' => array(
						array(
							'type'  => 'ds_off_tomorrow',
							'value' => null,
						),
					),
					'hide' => array(),
				),
				'items'       => array(
					$item( '📢', __( 'We do not deliver tomorrow — plan your order ahead', 'runline' ) ),
					$item( '🚚', __( 'Next delivery: {delivery_date}', 'runline' ) ),
				),
			),
		),
		array(
			'id'       => 'we-ship-to-you',
			'name'     => __( 'We ship to your country', 'runline' ),
			'category' => 'shop',
			'settings' => array(
				'bg'          => '#0c4a6e',
				'color'       => '#ffffff',
				'font'        => 'g:Montserrat',
				'font_weight' => '600',
				'separator'   => '•',
				'items'       => array(
					$item( '🌍', __( 'We ship to {visitor_country} too', 'runline' ) ),
					$item( '📦', __( 'Tracked delivery in 2–5 days', 'runline' ) ),
				),
			),
		),
	);
}
