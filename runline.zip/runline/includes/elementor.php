<?php
/**
 * Elementor widget "Runline bar" (only when Elementor is active).
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'elementor/widgets/register',
	function ( $widgets_manager ) {
		require_once RUNLINE_DIR . 'includes/class-runline-elementor-widget.php';
		$widgets_manager->register( new Runline_Elementor_Widget() );
	}
);

// Elementor renders widgets again while you edit: set up the new bar each time.
add_action(
	'elementor/frontend/after_enqueue_scripts',
	function () {
		wp_add_inline_script(
			'runline',
			'window.jQuery && jQuery( window ).on( "elementor/frontend/init", function () { window.elementorFrontend.hooks.addAction( "frontend/element_ready/runline.default", function ( scope ) { if ( window.runlineInit ) { window.runlineInit( scope[ 0 ] ); } } ); } );'
		);
	}
);
