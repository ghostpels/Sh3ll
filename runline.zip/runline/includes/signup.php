<?php
/**
 * E-mail signup in a bar: subscribers are kept in WordPress (Runline → Subscribers, CSV export) and, when an API key
 * is set in Runline → Settings, also sent to Mailchimp, MailerLite or Brevo.
 */

defined( 'ABSPATH' ) || exit;

function runline_subscribers_table() {
	global $wpdb;
	return $wpdb->prefix . 'runline_subscribers';
}

/**
 * The table of subscribers (created with the statistics table).
 */
function runline_signup_install() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$table = runline_subscribers_table();
	// sent_to: the service that has the address. retry: the service it still has to go to (sending failed), tries:
	// how many times it was tried. consent / consent_at: the text of the consent box the visitor ticked, and when.
	dbDelta(
		"CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			email varchar(190) NOT NULL,
			bar_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created datetime NOT NULL,
			sent_to varchar(20) NOT NULL DEFAULT '',
			retry varchar(20) NOT NULL DEFAULT '',
			tries tinyint(3) unsigned NOT NULL DEFAULT 0,
			consent varchar(255) NOT NULL DEFAULT '',
			consent_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY email (email),
			KEY retry (retry)
		) {$wpdb->get_charset_collate()};"
	);
	// After a new activation: addresses still waiting for the e-mail service.
	if ( $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM %i WHERE retry <> %s LIMIT 1', $table, '' ) ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		runline_signup_schedule_retry();
	}
}
add_action( 'runline_install', 'runline_signup_install' );

/**
 * E-mail services: key => name.
 */
function runline_signup_services() {
	return array(
		'local'      => __( 'Only in WordPress', 'runline' ),
		'mailchimp'  => 'Mailchimp',
		'mailerlite' => 'MailerLite',
		'brevo'      => 'Brevo',
		'kit'        => 'Kit (ConvertKit)',
		'klaviyo'    => 'Klaviyo',
		'omnisend'   => 'Omnisend',
		'fluentcrm'  => __( 'FluentCRM (plugin)', 'runline' ),
		'mailpoet'   => __( 'MailPoet (plugin)', 'runline' ),
		'webhook'    => __( 'Webhook (Zapier, Make…)', 'runline' ),
	);
}

if ( ! defined( 'RUNLINE_SIGNUP_TRIES' ) ) {
	define( 'RUNLINE_SIGNUP_TRIES', 6 ); // Sending to the e-mail service: the first try + 5 more, one per hour.
}

/**
 * Adds a subscriber: in WordPress and, if set, in the e-mail service of the bar.
 *
 * The address is kept in WordPress even when the service fails (it is down, the key expired…): it is sent again
 * later (runline_signup_retry), and Runline → Subscribers shows the error. Only when the address could be kept
 * nowhere — not in the table and not in the service — the signup fails.
 *
 * @param int    $bar_id  Bar ID.
 * @param string $email   E-mail address (valid).
 * @param array  $signup  Signup settings of the bar.
 * @param bool   $consent The visitor ticked the consent box.
 * @return array|WP_Error { saved: kept in WordPress, sent: taken by the e-mail service }.
 */
function runline_signup_add( $bar_id, $email, $signup, $consent = false ) {
	global $wpdb;
	$service = (string) $signup['service'];
	$sent    = '';
	$retry   = '';
	if ( 'local' !== $service && '' !== $service ) {
		$result = runline_signup_send( $service, $signup['list'], $email );
		if ( is_wp_error( $result ) ) {
			runline_signup_note_error( $service, $result );
			$retry = $service;
		} else {
			$sent = $service;
		}
	}
	$text = $consent && '' !== (string) $signup['consent'] ? mb_substr( wp_strip_all_tags( (string) $signup['consent'] ), 0, 255 ) : '';
	$when = '' !== $text ? current_time( 'mysql' ) : ''; // '' = no consent asked: NULL in the table.
	// A second signup of the same address: the newest bar, consent and result count (a failed try does not erase
	// that an earlier one reached the service).
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- our own table.
	$saved = false !== $wpdb->query(
		$wpdb->prepare(
			"INSERT INTO %i (email, bar_id, created, sent_to, retry, tries, consent, consent_at) VALUES (%s, %d, %s, %s, %s, %d, %s, NULLIF(%s, ''))
			ON DUPLICATE KEY UPDATE bar_id = VALUES(bar_id), sent_to = IF(VALUES(sent_to) = '', sent_to, VALUES(sent_to)),
			retry = VALUES(retry), tries = VALUES(tries), consent = IF(VALUES(consent) = '', consent, VALUES(consent)),
			consent_at = IFNULL(VALUES(consent_at), consent_at)",
			runline_subscribers_table(),
			$email,
			$bar_id,
			current_time( 'mysql' ),
			$sent,
			$retry,
			$retry ? 1 : 0,
			$text,
			$when
		)
	);
	if ( ! $saved && '' === $sent ) {
		return new WP_Error( 'runline_signup_failed', 'The address was kept nowhere.' );
	}
	if ( ! $saved ) {
		// In the service, but not in WordPress (no table?): say so to the admin; the visitor is subscribed.
		update_option( 'runline_signup_error', 'WordPress: ' . ( $wpdb->last_error ? $wpdb->last_error : 'the subscribers table' ), false );
	}
	if ( $retry && $saved ) {
		runline_signup_schedule_retry();
	}
	do_action( 'runline_subscribed', $email, $bar_id, $signup );
	return array(
		'saved' => $saved,
		'sent'  => '' !== $sent,
	);
}

/**
 * Keeps the last error of an e-mail service for Runline → Subscribers (only the admin sees it).
 *
 * @param string   $service Service key.
 * @param WP_Error $error   Error.
 */
function runline_signup_note_error( $service, $error ) {
	update_option( 'runline_signup_error', $service . ': ' . mb_substr( $error->get_error_message(), 0, 300 ), false );
}

/**
 * Sends the addresses that the e-mail service did not take again in an hour (WP-Cron).
 */
function runline_signup_schedule_retry() {
	if ( ! wp_next_scheduled( 'runline_signup_retry' ) ) {
		wp_schedule_single_event( time() + HOUR_IN_SECONDS, 'runline_signup_retry' );
	}
}

/**
 * Sends again up to 20 addresses that are waiting; each gets RUNLINE_SIGNUP_TRIES tries in all.
 */
function runline_signup_retry() {
	global $wpdb;
	$table = runline_subscribers_table();
	$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT id, email, bar_id, retry, tries FROM %i WHERE retry <> %s AND tries < %d ORDER BY id LIMIT 20', $table, '', RUNLINE_SIGNUP_TRIES ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- our own table, in WP-Cron.
	foreach ( (array) $rows as $row ) {
		// The list of the bar now (it may have been corrected after the error); a deleted bar: no list.
		$list = '';
		if ( RUNLINE_POST_TYPE === get_post_type( (int) $row['bar_id'] ) ) {
			$signup = runline_get_settings( (int) $row['bar_id'] )['signup'];
			$list   = $signup['service'] === $row['retry'] ? (string) $signup['list'] : '';
		}
		$result = runline_signup_send( $row['retry'], $list, $row['email'] );
		if ( is_wp_error( $result ) ) {
			runline_signup_note_error( $row['retry'], $result );
			$wpdb->update( $table, array( 'tries' => (int) $row['tries'] + 1 ), array( 'id' => (int) $row['id'] ), array( '%d' ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		} else {
			$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$table,
				array(
					'sent_to' => $row['retry'],
					'retry'   => '',
					'tries'   => 0,
				),
				array( 'id' => (int) $row['id'] ),
				array( '%s', '%s', '%d' ),
				array( '%d' )
			);
		}
	}
	$left = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE retry <> %s AND tries < %d', $table, '', RUNLINE_SIGNUP_TRIES ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	if ( $left ) {
		runline_signup_schedule_retry();
	}
}
add_action( 'runline_signup_retry', 'runline_signup_retry' );

/**
 * Sends a subscriber to an e-mail service.
 *
 * @param string $service mailchimp | mailerlite | brevo.
 * @param string $list_id Audience / group / list ID.
 * @param string $email   E-mail address.
 * @return true|WP_Error
 */
function runline_signup_send( $service, $list_id, $email ) {
	if ( 'fluentcrm' === $service || 'mailpoet' === $service ) {
		return runline_signup_send_plugin( $service, $list_id, $email );
	}
	$options = runline_options();
	$key     = isset( $options[ $service . '_key' ] ) ? $options[ $service . '_key' ] : '';
	if ( '' === $key ) {
		return new WP_Error( 'runline_no_key', __( 'No API key in Runline → Settings.', 'runline' ) );
	}
	$json = array( 'Content-Type' => 'application/json' );
	switch ( $service ) {
		case 'mailchimp':
			$dc       = substr( $key, strrpos( $key, '-' ) + 1 );
			$response = wp_remote_post(
				'https://' . rawurlencode( $dc ) . '.api.mailchimp.com/3.0/lists/' . rawurlencode( $list_id ) . '/members',
				array(
					'timeout' => 10,
					'headers' => $json + array( 'Authorization' => 'Basic ' . base64_encode( 'runline:' . $key ) ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- HTTP basic auth.
					'body'    => wp_json_encode(
						array(
							'email_address' => $email,
							'status'        => 'pending', // Double opt-in: Mailchimp sends the confirmation e-mail.
						)
					),
				)
			);
			$ok       = array( 200, 201 );
			break;
		case 'mailerlite':
			$body = array( 'email' => $email );
			if ( '' !== $list_id ) {
				$body['groups'] = array( $list_id );
			}
			$response = wp_remote_post(
				'https://connect.mailerlite.com/api/subscribers',
				array(
					'timeout' => 10,
					'headers' => $json + array( 'Authorization' => 'Bearer ' . $key ),
					'body'    => wp_json_encode( $body ),
				)
			);
			$ok       = array( 200, 201 );
			break;
		case 'brevo':
			$body = array(
				'email'         => $email,
				'updateEnabled' => true,
			);
			if ( '' !== $list_id ) {
				$body['listIds'] = array( (int) $list_id );
			}
			$response = wp_remote_post(
				'https://api.brevo.com/v3/contacts',
				array(
					'timeout' => 10,
					'headers' => $json + array( 'api-key' => $key ),
					'body'    => wp_json_encode( $body ),
				)
			);
			$ok       = array( 200, 201, 204 );
			break;
		case 'kit':
			// Kit API v4: the subscriber first, then (optional) the form to add them to.
			$headers  = $json + array( 'X-Kit-Api-Key' => $key );
			$response = wp_remote_post(
				'https://api.kit.com/v4/subscribers',
				array(
					'timeout' => 10,
					'headers' => $headers,
					'body'    => wp_json_encode( array( 'email_address' => $email ) ),
				)
			);
			if ( ! is_wp_error( $response ) && '' !== $list_id && in_array( (int) wp_remote_retrieve_response_code( $response ), array( 200, 201, 202 ), true ) ) {
				$response = wp_remote_post(
					'https://api.kit.com/v4/forms/' . rawurlencode( $list_id ) . '/subscribers',
					array(
						'timeout' => 10,
						'headers' => $headers,
						'body'    => wp_json_encode( array( 'email_address' => $email ) ),
					)
				);
			}
			$ok = array( 200, 201, 202 );
			break;
		case 'klaviyo':
			$job = array(
				'type'       => 'profile-subscription-bulk-create-job',
				'attributes' => array(
					'profiles' => array(
						'data' => array(
							array(
								'type'       => 'profile',
								'attributes' => array(
									'email'         => $email,
									'subscriptions' => array( 'email' => array( 'marketing' => array( 'consent' => 'SUBSCRIBED' ) ) ),
								),
							),
						),
					),
				),
			);
			if ( '' !== $list_id ) {
				$job['relationships'] = array(
					'list' => array(
						'data' => array(
							'type' => 'list',
							'id'   => $list_id,
						),
					),
				);
			}
			$response = wp_remote_post(
				'https://a.klaviyo.com/api/profile-subscription-bulk-create-jobs',
				array(
					'timeout' => 10,
					'headers' => $json + array(
						'Authorization' => 'Klaviyo-API-Key ' . $key,
						'revision'      => '2024-10-15',
						'Accept'        => 'application/vnd.api+json',
					),
					'body'    => wp_json_encode( array( 'data' => $job ) ),
				)
			);
			$ok       = array( 200, 201, 202 );
			break;
		case 'omnisend':
			$response = wp_remote_post(
				'https://api.omnisend.com/v3/contacts',
				array(
					'timeout' => 10,
					'headers' => $json + array( 'X-API-KEY' => $key ),
					'body'    => wp_json_encode(
						array(
							'identifiers' => array(
								array(
									'type'     => 'email',
									'id'       => $email,
									'channels' => array(
										'email' => array(
											'status'     => 'subscribed',
											'statusDate' => gmdate( 'c' ),
										),
									),
								),
							),
							'tags'        => '' !== $list_id ? array( $list_id ) : array( 'runline' ),
						)
					),
				)
			);
			$ok       = array( 200, 201 );
			break;
		case 'webhook':
			// $key is the address entered in Runline → Settings. wp_safe_remote_post() does not go to addresses of this
			// server or the local network; a webhook there (n8n on the same machine…) needs the filter
			// runline_webhook_local (true).
			$send = apply_filters( 'runline_webhook_local', false ) ? 'wp_remote_post' : 'wp_safe_remote_post';
			// Any port of the address the admin entered (n8n on :5678…); only the host has to be on the internet.
			$port  = (int) wp_parse_url( $key, PHP_URL_PORT );
			$ports = function ( $allowed ) use ( $port ) {
				return $port ? array_merge( (array) $allowed, array( $port ) ) : $allowed;
			};
			add_filter( 'http_allowed_safe_ports', $ports );
			try {
				$response = $send(
					$key,
					array(
						'timeout' => 10,
						'headers' => $json,
						'body'    => wp_json_encode(
							array(
								'email' => $email,
								'list'  => $list_id,
								'site'  => home_url( '/' ),
								'date'  => gmdate( 'c' ),
							)
						),
					)
				);
			} finally {
				// Only this request may use that port, also when a filter of another plugin throws.
				remove_filter( 'http_allowed_safe_ports', $ports );
			}
			$ok = range( 200, 299 );
			break;
		default:
			return true;
	}
	if ( is_wp_error( $response ) ) {
		return $response;
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	if ( 'mailchimp' === $service && 400 === $code ) {
		// Already on the list: fine. Any other 400 (wrong list, invalid address…) is an error.
		$answer = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( is_array( $answer ) && isset( $answer['title'] ) && 'Member Exists' === $answer['title'] ) {
			return true;
		}
	}
	return in_array( $code, $ok, true ) ? true : new WP_Error( 'runline_service', 'HTTP ' . $code . ' ' . wp_strip_all_tags( wp_remote_retrieve_body( $response ) ) );
}

/**
 * Sends a subscriber to an e-mail plugin on this site (FluentCRM, MailPoet).
 *
 * @param string $service fluentcrm | mailpoet.
 * @param string $list_id List ID (or empty).
 * @param string $email   E-mail address.
 * @return true|WP_Error
 */
function runline_signup_send_plugin( $service, $list_id, $email ) {
	$lists = '' !== $list_id ? array( (int) $list_id ) : array();
	if ( 'fluentcrm' === $service ) {
		if ( ! function_exists( 'FluentCrmApi' ) ) {
			return new WP_Error( 'runline_plugin', __( 'FluentCRM is not active.', 'runline' ) );
		}
		$contact = FluentCrmApi( 'contacts' )->createOrUpdate(
			array(
				'email'  => $email,
				'status' => 'pending', // FluentCRM sends its double opt-in e-mail.
				'lists'  => $lists,
			)
		);
		return $contact ? true : new WP_Error( 'runline_plugin', 'FluentCRM' );
	}
	if ( ! class_exists( '\MailPoet\API\API' ) ) {
		return new WP_Error( 'runline_plugin', __( 'MailPoet is not active.', 'runline' ) );
	}
	try {
		$api = \MailPoet\API\API::MP( 'v1' );
		if ( ! $lists ) {
			$all   = $api->getLists();
			$lists = $all ? array( (int) $all[0]['id'] ) : array();
		}
		$api->addSubscriber( array( 'email' => $email ), $lists );
	} catch ( Exception $e ) {
		// Already a subscriber: add them to the list instead.
		try {
			if ( $lists ) {
				\MailPoet\API\API::MP( 'v1' )->subscribeToLists( $email, $lists );
			}
		} catch ( Exception $e2 ) {
			return new WP_Error( 'runline_plugin', 'MailPoet: ' . $e2->getMessage() );
		}
	}
	return true;
}

add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			RUNLINE_REST_NS,
			'/subscribe',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => 'runline_rest_subscribe',
				'permission_callback' => '__return_true',
				'args'                => array(
					'bar'     => array(
						'type'     => 'integer',
						'required' => true,
					),
					'email'   => array(
						'type'     => 'string',
						'required' => true,
					),
					'consent' => array(
						'type'    => 'boolean',
						'default' => false,
					),
					'website' => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			)
		);
	}
);

/**
 * Signup from the browser of a visitor. Public (pages may be cached), protected by a hidden field and a limit of
 * 5 tries per 10 minutes per address (the address is only hashed and kept for those 10 minutes).
 */
function runline_rest_subscribe( WP_REST_Request $request ) {
	$bar = (int) $request['bar'];
	if ( RUNLINE_POST_TYPE !== get_post_type( $bar ) || '1' !== get_post_meta( $bar, RUNLINE_ACTIVE_META, true ) ) {
		return new WP_Error( 'runline_bar', __( 'This form is not available.', 'runline' ), array( 'status' => 404 ) );
	}
	$settings = runline_get_settings( $bar );
	$signup   = $settings['signup'];
	if ( ! $signup['on'] ) {
		return new WP_Error( 'runline_bar', __( 'This form is not available.', 'runline' ), array( 'status' => 404 ) );
	}
	// Bots fill in the hidden field.
	if ( '' !== (string) $request['website'] ) {
		return rest_ensure_response( array( 'ok' => true ) );
	}
	// Limits per 10 minutes: 5 tries for one address from one IP, 30 tries from one IP in all. Behind a proxy
	// (Cloudflare…) every visitor may share one IP, so the address part keeps people apart; see runline_client_ip().
	$ip    = runline_client_ip();
	$email = sanitize_email( (string) $request['email'] );
	// The IP limit first: a flood of made-up addresses from one IP stops there, without a counter for each of them.
	$keys = array(
		'runline_si_' . md5( wp_salt() . $ip ) => 30,
		'runline_su_' . md5( wp_salt() . $ip . '|' . strtolower( $email ) ) => 5,
	);
	foreach ( $keys as $limit => $max ) {
		if ( ! runline_rate_hit( $limit, $max, 10 * MINUTE_IN_SECONDS ) ) {
			return new WP_Error( 'runline_limit', __( 'Too many tries. Please wait a few minutes.', 'runline' ), array( 'status' => 429 ) );
		}
	}
	if ( ! is_email( $email ) ) {
		return new WP_Error( 'runline_email', __( 'Please enter a valid e-mail address.', 'runline' ), array( 'status' => 400 ) );
	}
	if ( '' !== $signup['consent'] && ! $request['consent'] ) {
		return new WP_Error( 'runline_consent', __( 'Please tick the box to agree.', 'runline' ), array( 'status' => 400 ) );
	}
	$result = runline_signup_add( $bar, $email, $signup, (bool) $request['consent'] );
	if ( is_wp_error( $result ) ) {
		// No details for the visitor (they are for the admin, in Runline → Subscribers), and no coupon.
		return new WP_Error( 'runline_signup_failed', __( 'Sorry, the signup did not work. Please try again later.', 'runline' ), array( 'status' => 503 ) );
	}
	// A coupon for subscribing, shown only now (it is not in the page).
	return rest_ensure_response(
		array(
			'ok'     => true,
			'coupon' => $signup['coupon'],
		)
	);
}

/**
 * Counts one try against a limit; false when the limit is reached (the try is then not counted).
 *
 * With a persistent object cache (Redis, Memcached) the counter is atomic (wp_cache_incr), so requests sent at the
 * same moment cannot slip through together. Without one it is a transient: a few parallel requests may pass the
 * limit by a little, which is fine for a limit that only slows down bots.
 *
 * @param string $key Counter key (a hash, no personal data).
 * @param int    $max Allowed tries per window.
 * @param int    $ttl Window in seconds.
 * @return bool
 */
function runline_rate_hit( $key, $max, $ttl ) {
	if ( wp_using_ext_object_cache() ) {
		wp_cache_add( $key, 0, 'runline_limits', $ttl );
		$count = wp_cache_incr( $key, 1, 'runline_limits' );
		if ( false !== $count ) {
			return $count <= $max;
		}
	}
	$count = (int) get_transient( $key );
	if ( $count >= $max ) {
		return false;
	}
	set_transient( $key, $count + 1, $ttl );
	return true;
}

/**
 * IP address of the visitor for the signup and statistics limits.
 *
 * REMOTE_ADDR, unless the request comes from a proxy we trust: then the visitor is the last address in
 * X-Forwarded-For that is not a trusted proxy itself (the addresses on the left are written by the visitor and can be
 * made up). Trusted: Cloudflare (its own ranges; then CF-Connecting-IP), a proxy on this server or the local network
 * (private address; filter runline_trust_private_proxies), and the addresses in the constant RUNLINE_TRUSTED_PROXIES
 * ("203.0.113.5, 2001:db8::/32") or the filter runline_trusted_proxies. The filter runline_client_ip has the last word.
 */
function runline_client_ip() {
	$remote = isset( $_SERVER['REMOTE_ADDR'] ) ? trim( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) ) : '';
	$remote = filter_var( $remote, FILTER_VALIDATE_IP ) ? $remote : '';
	$ip     = $remote;
	if ( $remote && runline_is_trusted_proxy( $remote ) ) {
		$cf = isset( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ? trim( sanitize_text_field( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) ) : '';
		if ( $cf && runline_is_cloudflare( $remote ) && filter_var( $cf, FILTER_VALIDATE_IP ) ) {
			$ip = $cf;
		} elseif ( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$hops = array_reverse( array_map( 'trim', explode( ',', sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) ) ) );
			foreach ( array_slice( $hops, 0, 10 ) as $hop ) {
				if ( ! filter_var( $hop, FILTER_VALIDATE_IP ) ) {
					break; // Garbage: stay with the last good address.
				}
				$ip = $hop;
				if ( ! runline_is_trusted_proxy( $hop ) ) {
					break;
				}
				if ( $cf && runline_is_cloudflare( $hop ) && filter_var( $cf, FILTER_VALIDATE_IP ) ) {
					$ip = $cf; // Cloudflare behind a proxy of the host: Cloudflare knows the visitor.
					break;
				}
			}
		}
	}
	return (string) apply_filters( 'runline_client_ip', $ip );
}

/**
 * Whether an address is a proxy whose X-Forwarded-For we may read.
 *
 * @param string $ip IP address.
 */
function runline_is_trusted_proxy( $ip ) {
	if ( runline_is_cloudflare( $ip ) ) {
		return true;
	}
	if ( apply_filters( 'runline_trust_private_proxies', true ) && runline_is_local_ip( $ip ) ) {
		return true;
	}
	$list = defined( 'RUNLINE_TRUSTED_PROXIES' ) ? (string) RUNLINE_TRUSTED_PROXIES : '';
	$list = (array) apply_filters( 'runline_trusted_proxies', array_filter( array_map( 'trim', explode( ',', $list ) ) ) );
	foreach ( $list as $range ) {
		if ( runline_ip_in_range( $ip, (string) $range ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Whether an address is of this server or the local network (loopback, private, link-local; IPv4 and IPv6). A fixed
 * list: what filter_var() counts as private or reserved differs between PHP versions (PHP 7.4 does not count ::1, but
 * counts public documentation ranges).
 *
 * @param string $ip IP address.
 */
function runline_is_local_ip( $ip ) {
	foreach ( array( '127.0.0.0/8', '10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '169.254.0.0/16', '::1/128', 'fc00::/7', 'fe80::/10' ) as $range ) {
		if ( runline_ip_in_range( $ip, $range ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Whether an address belongs to Cloudflare (https://www.cloudflare.com/ips/; filter runline_cloudflare_ranges).
 *
 * @param string $ip IP address.
 */
function runline_is_cloudflare( $ip ) {
	$ranges = apply_filters(
		'runline_cloudflare_ranges',
		array(
			'173.245.48.0/20',
			'103.21.244.0/22',
			'103.22.200.0/22',
			'103.31.4.0/22',
			'141.101.64.0/18',
			'108.162.192.0/18',
			'190.93.240.0/20',
			'188.114.96.0/20',
			'197.234.240.0/22',
			'198.41.128.0/17',
			'162.158.0.0/15',
			'104.16.0.0/13',
			'104.24.0.0/14',
			'172.64.0.0/13',
			'131.0.72.0/22',
			'2400:cb00::/32',
			'2606:4700::/32',
			'2803:f800::/32',
			'2405:b500::/32',
			'2405:8100::/32',
			'2a06:98c0::/29',
			'2c0f:f248::/32',
		)
	);
	foreach ( (array) $ranges as $range ) {
		if ( runline_ip_in_range( $ip, (string) $range ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Whether an IPv4 / IPv6 address is in a range ("192.0.2.0/24", "2001:db8::/32") or is that address.
 *
 * @param string $ip    IP address.
 * @param string $range Address or CIDR range.
 */
function runline_ip_in_range( $ip, $range ) {
	$parts = explode( '/', $range, 2 );
	$net   = filter_var( $parts[0], FILTER_VALIDATE_IP ) ? inet_pton( $parts[0] ) : false;
	$addr  = filter_var( $ip, FILTER_VALIDATE_IP ) ? inet_pton( $ip ) : false;
	if ( false === $net || false === $addr || strlen( $net ) !== strlen( $addr ) ) {
		return false;
	}
	$bits = isset( $parts[1] ) && ctype_digit( $parts[1] ) ? min( (int) $parts[1], strlen( $net ) * 8 ) : strlen( $net ) * 8;
	$full = intdiv( $bits, 8 );
	if ( substr( $addr, 0, $full ) !== substr( $net, 0, $full ) ) {
		return false;
	}
	$rest = $bits % 8;
	if ( ! $rest ) {
		return true;
	}
	$mask = chr( ( 0xff << ( 8 - $rest ) ) & 0xff );
	return ( $addr[ $full ] & $mask ) === ( $net[ $full ] & $mask );
}

/**
 * HTML of the signup form of a bar ("" when off).
 *
 * @param int   $bar_id   Bar ID.
 * @param array $settings Bar settings.
 * @param bool  $preview  Editor preview (no address to send to).
 */
function runline_signup_form( $bar_id, $settings, $preview ) {
	$s = $settings['signup'];
	if ( ! $s['on'] ) {
		return '';
	}
	$consent = '';
	if ( '' !== $s['consent'] ) {
		$consent = '<label class="runline__consent"><input type="checkbox" name="consent" value="1" required> <span>' . esc_html( $s['consent'] ) . '</span></label>';
	}
	return '<form class="runline__signup"' . ( $preview ? '' : ' data-url="' . esc_url( rest_url( RUNLINE_REST_NS . '/subscribe' ) ) . '" data-bar="' . (int) $bar_id . '" data-err="' . esc_attr__( 'Sorry, the signup did not work. Please try again later.', 'runline' ) . '"' ) . ' novalidate>'
		. '<input type="email" name="email" required placeholder="' . esc_attr( $s['placeholder'] ) . '" aria-label="' . esc_attr( $s['placeholder'] ) . '" autocomplete="email">'
		. $consent
		. '<input type="text" name="website" class="runline__hp" tabindex="-1" autocomplete="off" aria-hidden="true">'
		. '<button type="submit">' . esc_html( $s['button'] ) . '</button>'
		. '<span class="runline__signup-msg" aria-live="polite" data-ok="' . esc_attr( $s['success'] ) . '"'
		. ( '' !== $s['coupon'] ? ' data-copy="' . esc_attr( $settings['coupon']['copy'] ) . '" data-copied="' . esc_attr( $settings['coupon']['copied'] ) . '"' : '' ) . '></span>'
		. '</form>';
}

/* Admin: Runline → Subscribers. */
add_action(
	'admin_menu',
	function () {
		add_submenu_page( 'runline', __( 'Subscribers', 'runline' ), __( 'Subscribers', 'runline' ), 'manage_options', 'runline-subscribers', 'runline_subscribers_page' );
	},
	20
);

function runline_subscribers_page() {
	global $wpdb;
	$rows    = $wpdb->get_results( $wpdb->prepare( 'SELECT id, email, bar_id, created, sent_to, retry, tries FROM %i ORDER BY id DESC LIMIT 500', runline_subscribers_table() ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- our own table in the admin.
	$count   = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', runline_subscribers_table() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$waiting = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE retry <> %s', runline_subscribers_table(), '' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$error   = get_option( 'runline_signup_error' );
	$names   = runline_signup_services();
	?>
	<div class="wrap">
		<h1 class="wp-heading-inline"><?php esc_html_e( 'Subscribers', 'runline' ); ?></h1>
		<a class="page-title-action" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=runline_subscribers_csv' ), 'runline_subscribers_csv' ) ); ?>"><?php esc_html_e( 'Download CSV', 'runline' ); ?></a>
		<hr class="wp-header-end">
		<p>
			<?php
			/* translators: %d: number of subscribers. */
			echo esc_html( sprintf( __( 'Addresses left in the signup forms of your bars: %d.', 'runline' ), $count ) );
			?>
		</p>
		<?php if ( $error ) : ?>
			<div class="notice notice-warning"><p><?php echo esc_html( sprintf( /* translators: %s: error of the e-mail service. */ __( 'Last error of the e-mail service: %s', 'runline' ), $error ) ); ?></p></div>
		<?php endif; ?>
		<?php if ( $waiting ) : ?>
			<p>
				<?php
				/* translators: %d: number of addresses. */
				echo esc_html( sprintf( __( 'Addresses not yet in the e-mail service: %d. They are kept here and sent again every hour (6 tries).', 'runline' ), $waiting ) );
				?>
				<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=runline_subscribers_resend' ), 'runline_subscribers_resend' ) ); ?>"><?php esc_html_e( 'Send them now', 'runline' ); ?></a>
			</p>
			<?php
			// The hourly try runs with WP-Cron, which needs visits (or a real cron job when DISABLE_WP_CRON is set).
			$next = wp_next_scheduled( 'runline_signup_retry' );
			$due  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE retry <> %s AND tries < %d', runline_subscribers_table(), '', RUNLINE_SIGNUP_TRIES ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			if ( $due && ( ! $next || $next < time() - 2 * HOUR_IN_SECONDS ) ) :
				?>
				<p class="description"><?php esc_html_e( 'The automatic tries seem to be late: WP-Cron of this site may be switched off. Use "Send them now".', 'runline' ); ?></p>
			<?php endif; ?>
		<?php endif; ?>
		<div style="overflow-x:auto">
		<table class="widefat striped">
			<thead><tr><th><?php esc_html_e( 'E-mail', 'runline' ); ?></th><th><?php esc_html_e( 'Bar', 'runline' ); ?></th><th><?php esc_html_e( 'Date', 'runline' ); ?></th><th><?php esc_html_e( 'Sent to', 'runline' ); ?></th><th></th></tr></thead>
			<tbody>
			<?php if ( ! $rows ) : ?>
				<tr><td colspan="5"><?php esc_html_e( 'No subscribers yet.', 'runline' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( (array) $rows as $row ) : ?>
				<tr>
					<td><?php echo esc_html( $row['email'] ); ?></td>
					<td><?php echo esc_html( get_post_field( 'post_title', (int) $row['bar_id'], 'raw' ) ); ?></td>
					<td><?php echo esc_html( mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $row['created'] ) ); ?></td>
					<td>
						<?php
						if ( '' !== $row['retry'] ) {
							$name = isset( $names[ $row['retry'] ] ) ? $names[ $row['retry'] ] : $row['retry'];
							echo esc_html(
								(int) $row['tries'] < RUNLINE_SIGNUP_TRIES
									/* translators: %s: name of an e-mail service. */
									? sprintf( __( 'Waiting: %s did not take it yet', 'runline' ), $name )
									/* translators: %s: name of an e-mail service. */
									: sprintf( __( 'Not sent: %s did not take it', 'runline' ), $name )
							);
						} elseif ( '' !== $row['sent_to'] ) {
							echo esc_html( isset( $names[ $row['sent_to'] ] ) ? $names[ $row['sent_to'] ] : $row['sent_to'] );
						} else {
							echo '—';
						}
						?>
					</td>
					<td><a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=runline_subscriber_delete&id=' . (int) $row['id'] ), 'runline_subscriber_delete_' . (int) $row['id'] ) ); ?>" class="submitdelete"><?php esc_html_e( 'Delete', 'runline' ); ?></a></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		</div>
	</div>
	<?php
}

add_action(
	'admin_post_runline_subscribers_csv',
	function () {
		check_admin_referer( 'runline_subscribers_csv' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You cannot do this.', 'runline' ) );
		}
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT email, bar_id, created, sent_to, retry, consent, consent_at FROM %i ORDER BY id', runline_subscribers_table() ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=runline-subscribers-' . gmdate( 'Y-m-d' ) . '.csv' );
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- streaming the CSV.
		fputcsv( $out, array( 'email', 'bar', 'date', 'sent_to', 'not_sent_to', 'consent', 'consent_date' ) );
		// A leading = + - @ (or a tab / line break) would be a formula in spreadsheets.
		$cell = function ( $text ) {
			$text = (string) $text;
			return preg_match( '/^[=+\-@\t\r]/', $text ) ? "'" . $text : $text;
		};
		foreach ( (array) $rows as $row ) {
			fputcsv( $out, array_map( $cell, array( $row['email'], get_post_field( 'post_title', (int) $row['bar_id'], 'raw' ), $row['created'], $row['sent_to'], $row['retry'], $row['consent'], (string) $row['consent_at'] ) ) );
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}
);

add_action(
	'admin_post_runline_subscribers_resend',
	function () {
		check_admin_referer( 'runline_subscribers_resend' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You cannot do this.', 'runline' ) );
		}
		global $wpdb;
		// Everything waiting gets its tries back and is sent now (20 per run, the rest in an hour).
		$wpdb->query( $wpdb->prepare( 'UPDATE %i SET tries = 0 WHERE retry <> %s', runline_subscribers_table(), '' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		runline_signup_retry();
		wp_safe_redirect( admin_url( 'admin.php?page=runline-subscribers' ) );
		exit;
	}
);

add_action(
	'admin_post_runline_subscriber_delete',
	function () {
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the nonce is checked on the next line.
		check_admin_referer( 'runline_subscriber_delete_' . $id );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You cannot do this.', 'runline' ) );
		}
		global $wpdb;
		$wpdb->delete( runline_subscribers_table(), array( 'id' => $id ), array( '%d' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		wp_safe_redirect( admin_url( 'admin.php?page=runline-subscribers' ) );
		exit;
	}
);

// Privacy tools of WordPress (Tools → Export / Erase Personal Data) know about the subscribers.
add_filter(
	'wp_privacy_personal_data_erasers',
	function ( $erasers ) {
		$erasers['runline'] = array(
			'eraser_friendly_name' => __( 'Runline subscribers', 'runline' ),
			'callback'             => function ( $email ) {
				global $wpdb;
				$removed = (bool) $wpdb->delete( runline_subscribers_table(), array( 'email' => $email ), array( '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				return array(
					'items_removed'  => $removed,
					'items_retained' => false,
					'messages'       => array(),
					'done'           => true,
				);
			},
		);
		return $erasers;
	}
);

add_filter(
	'wp_privacy_personal_data_exporters',
	function ( $exporters ) {
		$exporters['runline'] = array(
			'exporter_friendly_name' => __( 'Runline subscribers', 'runline' ),
			'callback'               => function ( $email ) {
				global $wpdb;
				$row  = $wpdb->get_row( $wpdb->prepare( 'SELECT email, created, consent, consent_at FROM %i WHERE email = %s', runline_subscribers_table(), $email ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$data = array();
				if ( $row ) {
					$data[] = array(
						'group_id'    => 'runline',
						'group_label' => __( 'Runline subscribers', 'runline' ),
						'item_id'     => 'runline-' . md5( $email ),
						'data'        => array(
							array(
								'name'  => __( 'E-mail', 'runline' ),
								'value' => $row['email'],
							),
							array(
								'name'  => __( 'Date', 'runline' ),
								'value' => $row['created'],
							),
							array(
								'name'  => __( 'Consent', 'runline' ),
								'value' => '' !== $row['consent'] ? $row['consent'] . ' (' . $row['consent_at'] . ')' : '—',
							),
						),
					);
				}
				return array(
					'data' => $data,
					'done' => true,
				);
			},
		);
		return $exporters;
	}
);
