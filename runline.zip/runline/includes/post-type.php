<?php
/**
 * The "runline_bar" post type: one post = one bar. Only administrators can manage bars, because a bar shows on
 * every page of the site.
 */

defined( 'ABSPATH' ) || exit;

define( 'RUNLINE_POST_TYPE', 'runline_bar' );

add_action( 'init', 'runline_register_post_type' );

function runline_register_post_type() {
	$cap = 'manage_options';
	register_post_type(
		RUNLINE_POST_TYPE,
		array(
			'labels'          => array(
				'name'               => __( 'Bars', 'runline' ),
				'singular_name'      => __( 'Bar', 'runline' ),
				'menu_name'          => __( 'Runline', 'runline' ),
				'all_items'          => __( 'All bars', 'runline' ),
				'add_new'            => __( 'Add bar', 'runline' ),
				'add_new_item'       => __( 'Add bar', 'runline' ),
				'edit_item'          => __( 'Edit bar', 'runline' ),
				'new_item'           => __( 'New bar', 'runline' ),
				'search_items'       => __( 'Search bars', 'runline' ),
				'not_found'          => __( 'No bars yet.', 'runline' ),
				'not_found_in_trash' => __( 'No bars in the trash.', 'runline' ),
				'item_published'     => __( 'Bar saved.', 'runline' ),
				'item_updated'       => __( 'Bar saved.', 'runline' ),
			),
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => false, // The Runline menu is the React app (admin.php).
			'show_in_rest'    => false,
			'menu_position'   => 59,
			'menu_icon'       => 'dashicons-megaphone',
			'supports'        => array( 'title' ),
			'rewrite'         => false,
			'query_var'       => false,
			'map_meta_cap'    => true,
			'capability_type' => 'post',
			'capabilities'    => array(
				'create_posts'           => $cap,
				'edit_posts'             => $cap,
				'edit_others_posts'      => $cap,
				'edit_published_posts'   => $cap,
				'edit_private_posts'     => $cap,
				'publish_posts'          => $cap,
				'read_private_posts'     => $cap,
				'delete_posts'           => $cap,
				'delete_others_posts'    => $cap,
				'delete_published_posts' => $cap,
				'delete_private_posts'   => $cap,
			),
		)
	);
}

/**
 * Plain "Bar saved." messages instead of "Post published. View post".
 */
add_filter(
	'post_updated_messages',
	function ( $messages ) {
		$messages[ RUNLINE_POST_TYPE ] = array_fill( 1, 10, __( 'Bar saved.', 'runline' ) );
		return $messages;
	}
);
