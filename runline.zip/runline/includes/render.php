<?php
/**
 * The HTML of a bar. Used on the site and, with the same code, for the preview (src/render.js is its copy in JS;
 * tests/browser/admin-e2e.mjs compares the two).
 *
 * The server sends the items twice; the CSS animation moves the strip by one copy and starts again, so the loop has no
 * seam even without JavaScript. runline.js then adds copies for wide screens, sets the speed in pixels per second and
 * runs the countdown. assets/js/gate.js (printed inline once) checks the visitor rules before the first paint.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Countdown text for a number of seconds: "2d 03:04:05" or "03:04:05".
 */
function runline_countdown_text( $seconds ) {
	$seconds = max( 0, (int) $seconds );
	$days    = intdiv( $seconds, 86400 );
	$time    = sprintf( '%02d:%02d:%02d', intdiv( $seconds % 86400, 3600 ), intdiv( $seconds % 3600, 60 ), $seconds % 60 );
	return $days ? sprintf( runline_countdown_days_format(), $days ) . ' ' . $time : $time;
}

function runline_countdown_days_format() {
	/* translators: %d: number of days in the countdown, e.g. "2d 03:04:05". Keep it short. */
	return _x( '%dd', 'countdown days', 'runline' );
}

/**
 * The countdown element: <span class="runline__cd" data-end="ms" …>03:04:05</span>.
 */
function runline_countdown_span( $settings, $end ) {
	$countdown = $settings['countdown'];
	$left      = $end - time();
	$after     = 'text' === $countdown['after'] ? $countdown['after_text'] : '';
	$text      = $left > 0 || '' === $after ? runline_countdown_text( $left ) : $after;
	$extra = '';
	if ( 'daily' === $countdown['source'] ) {
		// The browser moves the end to the next day when the time has passed (cached pages too).
		$extra = sprintf( ' data-daily="%1$s" data-days="%2$s" data-tzo="%3$d"', esc_attr( $countdown['daily'] ), esc_attr( implode( ',', $countdown['daily_days'] ) ), runline_tz_offset() );
	} elseif ( 'visitor' === $countdown['source'] ) {
		$extra = ' data-visitor="' . (int) $countdown['minutes'] . '"';
	}
	return sprintf(
		'<span class="runline__cd" data-end="%1$d" data-d="%2$s" data-after="%3$s"%5$s>%4$s</span>',
		$end * 1000,
		esc_attr( runline_countdown_days_format() ),
		esc_attr( $after ),
		esc_html( $text ),
		$extra
	);
}

/**
 * Messages whose dates include today (site time zone). Messages without dates always stay.
 *
 * @param array $items Items.
 * @return array
 */
function runline_items_today( $items ) {
	$today = wp_date( 'Y-m-d' );
	return array_values(
		array_filter(
			$items,
			function ( $item ) use ( $today ) {
				return ( empty( $item['from'] ) || $item['from'] <= $today ) && ( empty( $item['to'] ) || $item['to'] >= $today );
			}
		)
	);
}

/**
 * The {open_now} element: "Open now" / "Closed now" by the opening hours; runline.js keeps it right every minute.
 *
 * @param array $hours Hours settings.
 */
function runline_open_span( $hours ) {
	$offset = runline_tz_offset();
	$open   = runline_is_open( $hours, time(), $offset );
	return sprintf(
		'<span class="runline__open" data-days="%1$s" data-from="%2$s" data-to="%3$s" data-tzo="%4$d" data-open="%5$s" data-closed="%6$s">%7$s</span>',
		esc_attr( implode( ',', $hours['days'] ) ),
		esc_attr( $hours['from'] ),
		esc_attr( $hours['to'] ),
		$offset,
		esc_attr( $hours['open'] ),
		esc_attr( $hours['closed'] ),
		esc_html( $open ? $hours['open'] : $hours['closed'] )
	);
}

/**
 * Contact buttons: WhatsApp, phone call, Messenger. Icons with a short name (the name is hidden on phones).
 * The same in render.js (contactHtml).
 *
 * @param array $contact Contact settings.
 */
function runline_contact_html( $contact ) {
	if ( empty( $contact['on'] ) ) {
		return '';
	}
	$links = array();
	if ( '' !== $contact['whatsapp'] ) {
		$links[] = array( 'whatsapp', 'https://wa.me/' . ltrim( $contact['whatsapp'], '+' ), 'WhatsApp' );
	}
	if ( '' !== $contact['phone'] ) {
		$links[] = array( 'phone', 'tel:' . $contact['phone'], __( 'Call', 'runline' ) );
	}
	if ( '' !== $contact['messenger'] ) {
		$links[] = array( 'messenger', 'https://m.me/' . $contact['messenger'], 'Messenger' );
	}
	if ( ! $links ) {
		return '';
	}
	$html = '<div class="runline__contact">';
	foreach ( $links as $link ) {
		$html .= '<a class="runline__ct runline__ct--' . $link[0] . '" href="' . esc_url( $link[1], array( 'https', 'tel' ) ) . '"'
			. ( 'phone' === $link[0] ? '' : ' target="_blank" rel="noopener"' ) . '>'
			. runline_contact_icon( $link[0] ) . '<span class="runline__ct-name">' . esc_html( $link[2] ) . '</span></a>';
	}
	return $html . '</div>';
}

/**
 * Icon of a contact button (SVG, the colour of the text).
 *
 * @param string $type whatsapp | phone | messenger.
 */
function runline_contact_icon( $type ) {
	$paths = array(
		'whatsapp'  => 'M12 2a10 10 0 0 0-8.7 14.9L2 22l5.3-1.4A10 10 0 1 0 12 2zm5.3 14c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.8s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.4 0 .5l-.3.5-.4.4c-.1.1-.3.3-.1.6.1.3.7 1.1 1.4 1.8 1 .9 1.8 1.1 2.1 1.3.3.1.4.1.6-.1l.8-1c.2-.3.4-.2.6-.1l1.9.9c.3.1.5.2.5.3.1.2.1.8-.2 1.4z',
		'phone'     => 'M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1z',
		'messenger' => 'M12 2C6.5 2 2 6.1 2 11.3c0 2.9 1.4 5.5 3.7 7.2V22l3.4-1.9c.9.3 1.9.4 2.9.4 5.5 0 10-4.1 10-9.2S17.5 2 12 2zm1 12.4-2.6-2.7-5 2.7 5.5-5.8 2.6 2.7 4.9-2.7z',
	);
	return '<svg class="runline__ct-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path fill="currentColor" d="' . $paths[ $type ] . '"/></svg>';
}

/**
 * HTML of a bar.
 *
 * @param int        $post_id  Bar ID.
 * @param array      $settings Bar settings.
 * @param string     $place    "top", "bottom", "manual" (shortcode, block, widget) or "preview".
 * @param array|null $gate     What the browser still checks (runline_rules_decide()), plus "group" for one bar per place.
 * @return string
 */
function runline_render_bar( $post_id, $settings, $place, $gate = null ) {
	static $count = array();

	$items = runline_items( $settings );
	if ( 'preview' !== $place ) {
		$items                   = runline_items_today( $items );
		$settings['ab']['items'] = runline_items_today( $settings['ab']['items'] );
		// Dayslot variables without a value now (no Dayslot, no free day): no "Next delivery: " without a date.
		$ds_vars                 = runline_dayslot_vars();
		$items                   = runline_dayslot_drop_items( $items, $ds_vars );
		$settings['ab']['items'] = runline_dayslot_drop_items( $settings['ab']['items'], $ds_vars );
	}
	if ( ! $items ) {
		return '';
	}

	$count[ $post_id ] = isset( $count[ $post_id ] ) ? $count[ $post_id ] + 1 : 1;
	$id                = 'runline-' . $post_id . ( $count[ $post_id ] > 1 ? '-' . $count[ $post_id ] : '' );
	$key               = $post_id . '-' . substr( md5( wp_json_encode( $items ) ), 0, 8 );
	$preview           = 'preview' === $place;
	$end               = runline_countdown_end( $settings, $preview );

	$classes = array( 'runline', 'runline--' . $place, 'runline--' . $settings['direction'], 'runline--mode-' . $settings['mode'] );
	if ( 'cards' === $settings['style'] ) {
		$classes[] = 'runline--cards';
	}
	if ( 'none' !== $settings['shadow'] ) {
		$classes[] = 'runline--shadow-' . $settings['shadow'];
	}
	if ( '' !== $settings['css_class'] ) {
		$classes = array_merge( $classes, explode( ' ', $settings['css_class'] ) );
	}
	if ( $settings['pause_hover'] ) {
		$classes[] = 'runline--pause-hover';
	}
	if ( $settings['uppercase'] ) {
		$classes[] = 'runline--upper';
	}
	if ( 'boxed' === $settings['width'] ) {
		$classes[] = 'runline--boxed';
		$classes[] = 'runline--align-' . $settings['align'];
	}
	$hide = array();
	if ( ! $preview ) {
		foreach ( $settings['devices'] as $device => $on ) {
			if ( ! $on ) {
				$hide[] = 'runline--hide-' . $device;
			}
		}
	}
	$classes = array_merge( $classes, $hide );
	// Phones: is there room (about 120 px) for the moving text next to the form, the button and the coupon?
	$stack_parts = $settings['signup']['on'] || ( $settings['button']['on'] && '' !== $settings['button']['text'] && '' !== $settings['button']['url'] ) || ( $settings['coupon']['on'] && '' !== $settings['coupon']['code'] ) || runline_contact_count( $settings['contact'] );
	$crowded     = $stack_parts && 'inline' !== $settings['mobile_layout'] && runline_mobile_crowded( $settings, $end );
	if ( $crowded ) {
		$classes[] = 'runline--m-' . $settings['mobile_layout'];
	}

	$vars = array(
		'--rl-bg'          => $settings['bg'],
		'--rl-color'       => $settings['color'],
		'--rl-link'        => $settings['link_color'] ? $settings['link_color'] : $settings['color'],
		'--rl-link-hover'  => $settings['link_hover'] ? $settings['link_hover'] : ( $settings['link_color'] ? $settings['link_color'] : $settings['color'] ),
		'--rl-label-bg'    => $settings['label_bg'],
		'--rl-label-color' => $settings['label_color'],
		'--rl-font'        => runline_font_stack( $settings['font'] ),
		'--rl-fs'          => $settings['font_size'] . 'px',
		'--rl-fs-m'        => $settings['font_size_mobile'] . 'px',
		'--rl-weight'      => $settings['font_weight'],
		'--rl-h'           => $settings['height'] . 'px',
		'--rl-gap'         => $settings['gap'] . 'px',
		// First guess of the duration for the time before runline.js measures the strip.
		'--rl-dur'         => max( 8, round( count( $items ) * 300 / $settings['speed'] ) ) . 's',
	);
	if ( 'boxed' === $settings['width'] ) {
		$vars['--rl-max'] = $settings['max_width'] . 'px';
	}
	if ( $settings['radius'] ) {
		$vars['--rl-radius'] = $settings['radius'] . 'px';
	}
	if ( '' !== $settings['bg2'] ) {
		$vars['--rl-bg-image'] = 'linear-gradient(' . $settings['bg_angle'] . 'deg,' . $settings['bg'] . ',' . $settings['bg2'] . ')';
	}
	if ( $settings['border_width'] ) {
		$vars['--rl-border'] = $settings['border_width'] . 'px solid ' . $settings['border_color'];
	}
	if ( $end ) {
		$vars['--rl-cd-bg']    = $settings['countdown']['bg'];
		$vars['--rl-cd-color'] = $settings['countdown']['color'];
	}
	$has_image = false;
	foreach ( $items as $item ) {
		$has_image = $has_image || ! empty( $item['image'] );
	}
	if ( $has_image ) {
		$vars['--rl-img-h'] = round( $settings['height'] * $settings['image_height'] / 100 ) . 'px';
	}
	if ( $settings['button']['on'] ) {
		$vars['--rl-btn-bg']     = $settings['button']['bg'];
		$vars['--rl-btn-color']  = $settings['button']['color'];
		$vars['--rl-btn-radius'] = $settings['button']['radius'] . 'px';
	}
	if ( $settings['coupon']['on'] ) {
		$vars['--rl-cp-bg']    = $settings['coupon']['bg'];
		$vars['--rl-cp-color'] = $settings['coupon']['color'];
	}
	$ship = runline_shipping_parts( $settings, $preview );
	if ( $ship ) {
		$vars['--rl-ship'] = $settings['shipping']['color'];
	}

	$style = '';
	foreach ( $vars as $name => $value ) {
		$style .= $name . ':' . $value . ';';
	}

	$cd        = $end ? runline_countdown_span( $settings, $end ) : '';
	$text_vars = array_merge(
		runline_text_vars( $preview ),
		array(
			'{countdown}'          => $cd,
			'{coupon}'             => $settings['coupon']['on'] ? '<span class="runline__cp-code">' . esc_html( $settings['coupon']['code'] ) . '</span>' : '',
			'{free_shipping_left}' => $ship ? $ship['left'] : '',
			// Filled in by runline.js from the WooCommerce cart and from the site (country).
			'{cart_total}'         => '<span class="runline__cart-total"></span>',
			'{cart_count}'         => '<span class="runline__cart-count"></span>',
			'{visitor_country}'    => '<span class="runline__country">' . esc_html__( 'your country', 'runline' ) . '</span>',
			'{open_now}'           => runline_open_span( $settings['hours'] ),
		)
	);
	$group     = runline_render_group( $items, $settings['separator'], false, $text_vars );
	$copy      = runline_render_group( $items, $settings['separator'], true, $text_vars );
	$track_b   = '';
	if ( runline_ab_active( $settings ) ) {
		// Variant B of the A/B test: the checker (gate.js) keeps one of the two strips for each visitor.
		$track_b = '<div class="runline__track" data-variant="b">'
			. runline_render_group( $settings['ab']['items'], $settings['separator'], false, $text_vars )
			. runline_render_group( $settings['ab']['items'], $settings['separator'], true, $text_vars ) . '</div>';
	}

	$gate_config = $preview ? null : runline_gate_config( $key, $settings, (array) $gate, $end );

	$html = '';
	if ( 'bottom' === $place ) {
		// Keeps the end of the page visible above the fixed bar.
		$spacer = array_merge( array( 'runline-spacer' ), $hide, $crowded && 'stack' === $settings['mobile_layout'] ? array( 'runline-spacer--stack' ) : array() );
		$html  .= '<div id="' . esc_attr( $id ) . '-spacer" class="' . esc_attr( implode( ' ', $spacer ) ) . '" style="--rl-h:' . (int) $settings['height'] . 'px;height:' . (int) $settings['height'] . 'px" aria-hidden="true"></div>';
	}

	$html .= sprintf(
		'<div id="%1$s" class="%2$s" style="%3$s" data-speed="%4$d" data-speed-m="%5$d" data-interval="%9$d" data-key="%6$s" role="region" aria-label="%7$s"%8$s>',
		esc_attr( $id ),
		esc_attr( implode( ' ', $classes ) ),
		esc_attr( $style ),
		(int) $settings['speed'],
		(int) $settings['speed_mobile'],
		esc_attr( $key ),
		esc_attr( $settings['label'] ? $settings['label'] : __( 'Announcements', 'runline' ) ),
		( ! empty( $gate['group'] ) ? ' data-group="' . esc_attr( $gate['group'] ) . '"' : '' )
		. ( ! $preview && $gate_config ? ' data-gate="' . esc_attr( wp_json_encode( $gate_config ) ) . '"' : '' )
		. ( $ship && ! $preview ? ' data-ship="' . esc_attr( wp_json_encode( $ship['data'] ) ) . '"' : '' )
		. ( ! $preview && $post_id && runline_stats_on() ? ' data-bar="' . (int) $post_id . '" data-track="' . esc_url( rest_url( RUNLINE_REST_NS . '/track' ) ) . '"' : '' )
		. ( ! $preview && $post_id && runline_options()['analytics'] ? ' data-ga="' . (int) $post_id . '"' : '' )
		. ( ! $preview && runline_uses_var( $settings, array( '{cart_total}', '{cart_count}' ) ) && class_exists( 'WooCommerce' ) ? ' data-cart="' . esc_url( rest_url( 'wc/store/v1/cart' ) ) . '"' : '' )
		. ( ! $preview && runline_uses_var( $settings, array( '{visitor_country}' ) ) ? ' data-country="' . esc_url( rest_url( RUNLINE_REST_NS . '/country' ) ) . '"' : '' ),
		(int) $settings['interval']
	);
	if ( '' !== $settings['label'] ) {
		$html .= '<div class="runline__label">' . esc_html( $settings['label'] ) . '</div>';
	}
	$fixed_cd = '';
	if ( $end && 'text' !== $settings['countdown']['place'] ) {
		$fixed_cd = '<div class="runline__countdown">'
			. ( '' !== $settings['countdown']['prefix'] ? '<span class="runline__cd-prefix">' . esc_html( $settings['countdown']['prefix'] ) . '</span> ' : '' )
			. $cd . '</div>';
	}
	if ( 'left' === $settings['countdown']['place'] ) {
		$html .= $fixed_cd;
	}
	if ( $ship ) {
		$html .= $ship['block'];
	}
	$html .= '<div class="runline__viewport"><div class="runline__track">' . $group . $copy . '</div>' . $track_b . '</div>';
	if ( $crowded && 'stack' === $settings['mobile_layout'] ) {
		// On phones the form, the button and the coupon go to a second row after this break.
		$html .= '<span class="runline__break" aria-hidden="true"></span>';
	}
	if ( 'right' === $settings['countdown']['place'] ) {
		$html .= $fixed_cd;
	}
	$coupon = $settings['coupon'];
	if ( $coupon['on'] && '' !== $coupon['code'] ) {
		$html .= '<div class="runline__coupon">'
			. ( '' !== $coupon['prefix'] ? '<span class="runline__cp-prefix">' . esc_html( $coupon['prefix'] ) . '</span> ' : '' )
			. '<span class="runline__cp-code">' . esc_html( $coupon['code'] ) . '</span> '
			. '<button type="button" class="runline__copy" data-code="' . esc_attr( $coupon['code'] ) . '" data-copied="' . esc_attr( $coupon['copied'] ) . '"' . ( $coupon['confetti'] ? ' data-confetti="1"' : '' ) . '>' . esc_html( $coupon['copy'] ) . '</button></div>';
	}
	$html  .= runline_signup_form( $post_id, $settings, $preview );
	$button = $settings['button'];
	if ( $button['on'] && '' !== $button['text'] && '' !== $button['url'] ) {
		$html .= '<a class="runline__button' . ( $button['pulse'] ? ' runline__button--pulse' : '' ) . '" href="' . esc_url( $button['url'] ) . '"' . ( $button['new_tab'] ? ' target="_blank" rel="noopener"' : '' ) . '>' . esc_html( $button['text'] ) . '</a>';
	}
	$html .= runline_contact_html( $settings['contact'] );
	if ( $ship && $settings['shipping']['progress'] ) {
		$html .= '<span class="runline__progress" aria-hidden="true"><i style="width:' . esc_attr( $ship['percent'] ) . '%"></i></span>';
	}
	if ( $settings['closable'] ) {
		$html .= '<button type="button" class="runline__close" aria-label="' . esc_attr__( 'Close', 'runline' ) . '"><span aria-hidden="true">&times;</span></button>';
	}
	$html .= '</div>';

	if ( 'none' !== $settings['ribbon'] ) {
		// A tilted ribbon (and a second one crossing it) in a box that hides what sticks out.
		$html = sprintf(
			'<div class="runline-ribbon runline-ribbon--%1$s" style="%2$s">%3$s%4$s</div>',
			esc_attr( $settings['ribbon'] ),
			esc_attr( '--rl-h:' . $settings['height'] . 'px;--rl-tilt:' . $settings['tilt'] . 'deg;--rl-ribbon2:' . $settings['ribbon2'] . ';' ),
			'crossed' === $settings['ribbon'] ? '<span class="runline-ribbon__band" aria-hidden="true"></span>' : '',
			$html
		);
	}

	if ( ! $preview ) {
		$html .= runline_gate_script( $id, $key, $settings, (array) $gate, $end );
		runline_enqueue_font( $settings );
	}

	return apply_filters( 'runline_bar_html', $html, $post_id, $settings, $place );
}

/**
 * The inline call that decides, before the first paint, whether the visitor sees the bar (closed by the visitor,
 * visitor rules, schedule, ended countdown, one bar per place). The checker itself (gate.js) is printed once per page.
 */
function runline_gate_script( $id, $key, $settings, $gate, $end ) {
	$config = runline_gate_config( $key, $settings, $gate, $end );
	if ( ! $config ) {
		return '';
	}
	// The checker is printed in <head> on pages known to have bars; a bar found later brings it to the footer
	// (before runline.js, which then checks such bars). Never inline in the content: content filters change "&".
	if ( ! did_action( 'runline_gate_printed' ) && ! wp_scripts()->get_data( 'runline', 'runline_gate' ) ) {
		wp_add_inline_script( 'runline', runline_gate_runtime(), 'before' );
		wp_script_add_data( 'runline', 'runline_gate', true );
	}
	return wp_get_inline_script_tag( 'if(window.runlineGate)runlineGate(' . wp_json_encode( $id ) . ');' );
}

/**
 * What the browser checks for a bar (see gate.js), or null when there is nothing to check.
 */
function runline_gate_config( $key, $settings, $gate, $end ) {
	$config = array( 'key' => $key );
	if ( $settings['closable'] ) {
		$config['closable']  = 1;
		$config['closeDays'] = (int) $settings['close_days'];
	}
	foreach ( array( 'show', 'hide', 'sched', 'group', 'cartUrl', 'countryUrl', 'dsOff' ) as $part ) {
		if ( ! empty( $gate[ $part ] ) ) {
			$config[ $part ] = $gate[ $part ];
		}
	}
	if ( $end && 'hide' === $settings['countdown']['after'] ) {
		if ( 'visitor' === $settings['countdown']['source'] ) {
			// Personal timer: ended for this visitor = minutes since the first visit (kept in the browser).
			$config['cdVisitor'] = (int) $settings['countdown']['minutes'];
		} elseif ( 'daily' !== $settings['countdown']['source'] ) {
			$config['cdEnd'] = $end * 1000;
		}
	}
	if ( $settings['appear']['delay'] || $settings['appear']['scroll'] ) {
		$config['appear'] = array( (int) $settings['appear']['delay'], (int) $settings['appear']['scroll'] );
	}
	if ( runline_ab_active( $settings ) ) {
		$config['ab'] = (int) $settings['ab']['split'];
	}
	if ( $settings['signup']['on'] && $settings['signup']['hide_after'] ) {
		$config['signup'] = 1;
	}
	return 1 === count( $config ) ? null : $config;
}

/**
 * Whether a bar runs an A/B test (written messages and a second set of them).
 */
function runline_ab_active( $settings ) {
	return ! empty( $settings['ab']['on'] ) && ! empty( $settings['ab']['items'] ) && 'manual' === $settings['source']['type'];
}

/**
 * The checker (assets/js/gate.js, minified when available).
 */
function runline_gate_runtime() {
	$file = RUNLINE_DIR . 'assets/js/gate.min.js';
	$file = file_exists( $file ) ? $file : RUNLINE_DIR . 'assets/js/gate.js';
	return trim( (string) file_get_contents( $file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a file of this plugin.
}

/**
 * Whether the fixed parts of a bar leave less than about 120 px for the moving text on a phone (390 px).
 * A rough measure from the texts, the same in render.js — so the layout is decided before the page shows.
 *
 * @param array $settings Bar settings.
 * @param int   $end      End of the countdown (0 = none).
 */
function runline_mobile_crowded( $settings, $end ) {
	if ( $settings['signup']['on'] ) {
		return true;
	}
	$char  = $settings['font_size_mobile'] * ( $settings['uppercase'] ? 0.72 : 0.6 );
	$width = 0;
	$timer = $end && 'text' !== $settings['countdown']['place'];
	if ( '' !== $settings['label'] && ! $timer ) {
		$width += mb_strlen( $settings['label'] ) * $char + 32;
	}
	if ( $timer ) {
		$width += 11 * $char + 20;
	}
	if ( $settings['coupon']['on'] && '' !== $settings['coupon']['code'] ) {
		$width += ( mb_strlen( $settings['coupon']['code'] ) + mb_strlen( $settings['coupon']['copy'] ) ) * $char + 56;
	}
	if ( $settings['button']['on'] && '' !== $settings['button']['text'] && '' !== $settings['button']['url'] ) {
		$width += mb_strlen( $settings['button']['text'] ) * $char + 32;
	}
	if ( $settings['closable'] ) {
		$width += 40;
	}
	$width += 40 * runline_contact_count( $settings['contact'] );
	return $width > 390 - 120;
}

/**
 * How many contact buttons the bar shows.
 *
 * @param array $contact Contact settings.
 */
function runline_contact_count( $contact ) {
	return empty( $contact['on'] ) ? 0 : count( array_filter( array( $contact['whatsapp'], $contact['phone'], $contact['messenger'] ), 'strlen' ) );
}

/**
 * Whether a message of the bar (or of its A/B variant) uses one of these text variables.
 *
 * @param array    $settings Bar settings.
 * @param string[] $vars     Variables, e.g. "{cart_total}".
 */
function runline_uses_var( $settings, $vars ) {
	foreach ( array_merge( $settings['items'], $settings['ab']['items'] ) as $item ) {
		foreach ( $vars as $var ) {
			if ( false !== strpos( (string) $item['text'], $var ) ) {
				return true;
			}
		}
	}
	return false;
}

/**
 * One copy of the items. Copies are hidden from screen readers and from the Tab key.
 *
 * @param array  $items     Items.
 * @param string $separator Separator between items.
 * @param bool   $copy      A copy for the loop.
 * @param array  $vars      Text variables: "{name}" => HTML.
 * @return string
 */
function runline_render_group( $items, $separator, $copy, $vars = array() ) {
	$html = $copy ? '<ul class="runline__group" aria-hidden="true">' : '<ul class="runline__group">';
	foreach ( $items as $item ) {
		$inner = '';
		if ( '' !== $item['icon'] ) {
			$inner .= '<span class="runline__icon" aria-hidden="true">' . esc_html( $item['icon'] ) . '</span>';
		}
		$text = strtr( wp_kses( $item['text'], runline_allowed_html() ), $vars );
		if ( ! empty( $item['image'] ) ) {
			$alt  = trim( wp_strip_all_tags( '' !== $item['text'] ? $item['text'] : ( isset( $item['author'] ) ? $item['author'] : '' ) ) );
			$text = '<img class="runline__img" src="' . esc_url( $item['image'] ) . '" alt="' . esc_attr( '' === $text ? $alt : '' ) . '" decoding="async">' . $text;
		}
		if ( '' !== $item['url'] ) {
			$attrs = ' href="' . esc_url( $item['url'] ) . '"';
			if ( $item['new_tab'] ) {
				$attrs .= ' target="_blank" rel="noopener"';
			}
			if ( $copy ) {
				$attrs .= ' tabindex="-1"';
			}
			$text = '<a' . $attrs . '>' . $text . '</a>';
		}
		$text = '<span class="runline__text">' . $text . '</span>';
		if ( ! empty( $item['author'] ) ) {
			$text = '<span class="runline__body">' . $text . '<span class="runline__author">' . esc_html( $item['author'] ) . '</span></span>';
		}
		$dates = ( ! empty( $item['from'] ) ? ' data-from="' . esc_attr( $item['from'] ) . '"' : '' ) . ( ! empty( $item['to'] ) ? ' data-to="' . esc_attr( $item['to'] ) . '"' : '' );
		$html .= '<li class="runline__item"' . $dates . '>' . $inner . $text . '</li>';
		if ( '' !== $separator ) {
			$html .= '<li class="runline__sep" aria-hidden="true">' . esc_html( $separator ) . '</li>';
		}
	}
	return $html . '</ul>';
}

/**
 * Free shipping parts of a bar: the text block, data for the browser, the amount left. Null when off or unknown.
 * Before the browser knows the cart, the whole threshold is "left".
 *
 * @param array $settings Bar settings.
 * @param bool  $preview  Editor preview (example: a third of the threshold is in the cart).
 */
function runline_shipping_parts( $settings, $preview ) {
	$ship = $settings['shipping'];
	if ( ! $ship['on'] ) {
		return null;
	}
	$threshold = runline_free_shipping_threshold( $settings );
	if ( $threshold <= 0 ) {
		return null;
	}
	$in_cart = $preview ? round( $threshold / 3, 2 ) : 0;
	$left    = runline_shipping_price( $threshold - $in_cart );
	$span    = '<span class="runline__fsleft">' . esc_html( $left ) . '</span>';
	return array(
		'left'    => $span,
		'percent' => round( 100 * $in_cart / $threshold ),
		'block'   => '<div class="runline__shipping" aria-live="polite"><span class="runline__ship-text">' . str_replace( '{free_shipping_left}', $span, esc_html( $ship['before'] ) ) . '</span></div>',
		'data'    => array(
			't'      => $threshold,
			'before' => $ship['before'],
			'after'  => $ship['after'],
			'fmt'    => runline_price_format(),
			'cart'   => esc_url_raw( rest_url( 'wc/store/v1/cart' ) ),
		),
	);
}

/**
 * A price as plain text in the format of the shop ("66,67 zł"), or a plain number without WooCommerce.
 */
function runline_shipping_price( $amount ) {
	if ( function_exists( 'wc_price' ) ) {
		return html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES, 'UTF-8' );
	}
	return number_format_i18n( $amount, 2 );
}
